# Panduan Cepat - AI Gateway Enhanced Custom

## 🚀 Instalasi & Setup

### 1. Install dan Jalankan

```bash
# Berikan permission untuk install script
chmod +x install-custom.sh

# Jalankan installer
./install-custom.sh

# Start server
npm start
```

### 2. Login Admin

Akses: `http://localhost:422/admin.html`

```
Username: admin
Password: admin123
```

**⚠️ SEGERA GANTI PASSWORD!**

## 📋 Fitur-Fitur Custom

### 1. Mengatur Allowed Domains per Group

#### Via API:
```bash
# Login sebagai admin
curl -X POST http://localhost:422/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "admin123"
  }'

# Update group dengan allowed domains
curl -X PUT http://localhost:422/admin/groups/1 \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Basic",
    "description": "Basic tier",
    "allowed_domains": "localhost:3000,app.example.com,*.myapp.com"
  }'
```

#### Format allowed_domains:
- `*` = Semua domain diizinkan
- `example.com` = Hanya domain spesifik
- `*.example.com` = Semua subdomain
- `domain1.com,domain2.com` = Multiple domains (pisahkan dengan koma)

### 2. Admin Login Sebagai User

```bash
# Get user ID terlebih dahulu
curl -X GET http://localhost:422/admin/users \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"

# Login sebagai user (misalnya user ID 5)
curl -X POST http://localhost:422/admin/users/5/impersonate \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"

# Response akan memberikan token baru
# {
#   "token": "NEW_TOKEN_AS_USER",
#   "user": {
#     "id": 5,
#     "username": "john",
#     "impersonated_by": "admin"
#   }
# }

# Gunakan token baru untuk bertindak sebagai user tersebut
curl -X GET http://localhost:422/user/profile \
  -H "Authorization: Bearer NEW_TOKEN_AS_USER"
```

**Tracking Impersonation:**
```bash
# Lihat log impersonation
curl -X GET http://localhost:422/admin/impersonation-logs \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"
```

### 3. Mengatur Model Rules

```bash
# Buat rule untuk model GPT-4
curl -X POST http://localhost:422/admin/model-rules \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "model_alias": "gpt-4",
    "system_prompt": "Anda adalah asisten AI yang ahli dalam pemrograman. Selalu berikan solusi yang detail dan production-ready.",
    "temperature": 0.7,
    "max_tokens": 4000,
    "top_p": 0.9
  }'

# Lihat semua model rules
curl -X GET http://localhost:422/admin/model-rules \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"

# Update model rule
curl -X PUT http://localhost:422/admin/model-rules/gpt-4 \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "temperature": 0.5,
    "system_prompt": "Anda adalah code reviewer profesional."
  }'

# Hapus model rule
curl -X DELETE http://localhost:422/admin/model-rules/gpt-4 \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"
```

### 4. User Membuat Knowledge Base

```bash
# Login sebagai user
curl -X POST http://localhost:422/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "john",
    "password": "password123"
  }'

# Buat knowledge base entry
curl -X POST http://localhost:422/user/knowledge-base \
  -H "Authorization: Bearer YOUR_USER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Tech Stack Project",
    "content": "Project kami menggunakan:\n- Frontend: React 18 dengan TypeScript\n- Backend: Node.js dengan Express\n- Database: PostgreSQL\n- Deployment: AWS ECS\n\nCode style: Kami mengikuti Airbnb style guide",
    "is_active": true
  }'

# Lihat semua knowledge base
curl -X GET http://localhost:422/user/knowledge-base \
  -H "Authorization: Bearer YOUR_USER_TOKEN"

# Update knowledge base
curl -X PUT http://localhost:422/user/knowledge-base/1 \
  -H "Authorization: Bearer YOUR_USER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Updated Tech Stack",
    "content": "Konten baru...",
    "is_active": true
  }'

# Hapus knowledge base
curl -X DELETE http://localhost:422/user/knowledge-base/1 \
  -H "Authorization: Bearer YOUR_USER_TOKEN"
```

### 5. Request AI dengan Model Rules & Knowledge Base

```bash
# Request ke AI
curl -X POST http://localhost:422/api/gpt-4 \
  -H "Authorization: Bearer YOUR_USER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Bagaimana cara struktur React components yang baik?",
    "stream": false
  }'

# System akan otomatis:
# 1. Apply system_prompt dari model rules
# 2. Inject user's knowledge base
# 3. Gabungkan dengan user prompt
# 4. Forward ke Ollama
```

**Yang Terjadi di Backend:**
```
Final Prompt yang dikirim ke Ollama:

[System Prompt dari Model Rule]
Anda adalah asisten AI yang ahli dalam pemrograman...

## User Context and Knowledge Base:
[Tech Stack Project]
Project kami menggunakan:
- Frontend: React 18 dengan TypeScript
- Backend: Node.js dengan Express
...

---

[User Question]
Bagaimana cara struktur React components yang baik?
```

## 📊 Workflow Lengkap

### Setup Admin (Pertama Kali)

1. **Login Admin**
   ```bash
   POST /auth/login
   { "username": "admin", "password": "admin123" }
   ```

2. **Ganti Password Admin**
   ```bash
   POST /auth/change-password
   { 
     "current_password": "admin123",
     "new_password": "NewSecurePassword123!"
   }
   ```

3. **Buat Groups dengan CORS**
   ```bash
   POST /admin/groups
   {
     "name": "Premium",
     "description": "Premium users",
     "allowed_domains": "app.company.com,*.dev.company.com"
   }
   ```

4. **Tambah Models ke Group**
   ```bash
   POST /admin/groups/1/models
   {
     "model_alias": "gpt-4",
     "model_name": "llama3.2:latest"
   }
   ```

5. **Setup Model Rules**
   ```bash
   POST /admin/model-rules
   {
     "model_alias": "gpt-4",
     "system_prompt": "Anda adalah AI assistant yang profesional...",
     "temperature": 0.7,
     "max_tokens": 4000
   }
   ```

6. **Buat User Baru**
   ```bash
   POST /admin/users
   {
     "username": "john",
     "email": "john@example.com",
     "password": "SecurePass123",
     "group_id": 1
   }
   ```

### Setup User

1. **Login User**
   ```bash
   POST /auth/login
   { "username": "john", "password": "SecurePass123" }
   ```

2. **Buat API Key**
   ```bash
   POST /user/api-keys
   { 
     "name": "My App Key",
     "expires_in_days": 90
   }
   ```

3. **Tambah Domain (Optional)**
   ```bash
   POST /user/domains
   { "domain": "myapp.localhost" }
   ```

4. **Setup Knowledge Base**
   ```bash
   POST /user/knowledge-base
   {
     "name": "Project Context",
     "content": "...",
     "is_active": true
   }
   ```

5. **Test AI Request**
   ```bash
   POST /api/gpt-4
   {
     "prompt": "Hello, how are you?",
     "stream": false
   }
   ```

## 🔍 Debugging & Troubleshooting

### Check CORS Issues

```bash
# Check group allowed domains
curl -X GET http://localhost:422/admin/groups/1 \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"

# Check user domains
curl -X GET http://localhost:422/user/domains \
  -H "Authorization: Bearer YOUR_USER_TOKEN"
```

### Check Model Configuration

```bash
# List model rules
curl -X GET http://localhost:422/admin/model-rules \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"

# Check specific model
curl -X GET http://localhost:422/api/models/gpt-4/rules \
  -H "Authorization: Bearer YOUR_USER_TOKEN"
```

### Check Knowledge Base

```bash
# List all knowledge base
curl -X GET http://localhost:422/user/knowledge-base \
  -H "Authorization: Bearer YOUR_USER_TOKEN"

# Response akan show is_active status
```

### View Logs

```bash
# Usage logs
curl -X GET http://localhost:422/user/usage/history?limit=50 \
  -H "Authorization: Bearer YOUR_USER_TOKEN"

# Audit logs (admin only)
curl -X GET http://localhost:422/admin/audit-logs?limit=100 \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"

# Impersonation logs (admin only)
curl -X GET http://localhost:422/admin/impersonation-logs \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"
```

## 💡 Tips & Best Practices

### Untuk Admin:

1. **CORS Setup**
   - Gunakan wildcard (*.domain.com) untuk development
   - Specific domains untuk production
   - Test dengan different origins

2. **Model Rules**
   - Set reasonable max_tokens
   - Adjust temperature berdasarkan use case
   - Document system prompts

3. **Impersonation**
   - Gunakan hanya untuk debugging
   - Always review impersonation logs
   - Inform users jika perlu

### Untuk User:

1. **Knowledge Base**
   - Keep entries focused dan relevant
   - Use clear names
   - Toggle is_active sesuai kebutuhan
   - Update regularly

2. **API Keys**
   - Set expiry dates
   - Rotate keys regularly
   - Use different keys untuk different apps

3. **Domains**
   - Add semua domains yang akan digunakan
   - Include localhost untuk development

## 🔒 Security Checklist

- [ ] Ganti JWT_SECRET di .env
- [ ] Ganti password admin default
- [ ] Setup CORS allowed domains
- [ ] Enable HTTPS di production
- [ ] Regular backup database
- [ ] Monitor impersonation logs
- [ ] Rotate API keys regularly
- [ ] Review audit logs

## 📞 Bantuan

Jika ada pertanyaan atau issues, silakan:
1. Check README-CUSTOM.md untuk dokumentasi lengkap
2. Review logs di console
3. Check database di data/gateway.db
4. Contact support team

## 🎯 Next Steps

1. Customize model rules sesuai kebutuhan
2. Setup knowledge base untuk common contexts
3. Configure CORS untuk production domains
4. Monitor usage patterns
5. Optimize berdasarkan analytics

---

**Selamat menggunakan AI Gateway Enhanced Custom Edition!** 🚀
