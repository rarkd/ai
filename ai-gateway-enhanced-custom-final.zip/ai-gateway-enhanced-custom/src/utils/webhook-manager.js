const axios = require('axios');
const crypto = require('crypto');
const db = require('../database/db');

/**
 * Webhook Manager
 * Handles webhook creation, triggering, and logging
 */
class WebhookManager {

  /**
   * Available webhook events
   */
  static EVENTS = {
    USER_CREATED: 'user.created',
    USER_UPDATED: 'user.updated',
    USER_DELETED: 'user.deleted',
    USER_BANNED: 'user.banned',
    QUOTA_WARNING: 'quota.warning',
    QUOTA_EXCEEDED: 'quota.exceeded',
    RATE_LIMIT_EXCEEDED: 'rate_limit.exceeded',
    API_KEY_CREATED: 'api_key.created',
    API_KEY_DELETED: 'api_key.deleted',
    SECURITY_ALERT: 'security.alert',
    MONTHLY_REPORT: 'report.monthly'
  };

  /**
   * Create a webhook
   */
  static async create(userId, name, url, events, secret = null) {
    return new Promise((resolve, reject) => {
      // Generate secret if not provided
      const webhookSecret = secret || crypto.randomBytes(32).toString('hex');
      const eventsJson = JSON.stringify(events);

      const query = `
        INSERT INTO webhooks (user_id, name, url, secret, events)
        VALUES (?, ?, ?, ?, ?)
      `;

      db.run(query, [userId, name, url, webhookSecret, eventsJson], function(err) {
        if (err) {
          reject(err);
        } else {
          resolve({
            id: this.lastID,
            name,
            url,
            secret: webhookSecret,
            events
          });
        }
      });
    });
  }

  /**
   * Get webhooks for a user
   */
  static async getUserWebhooks(userId) {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT id, name, url, events, is_active, last_triggered, failure_count, created_at
        FROM webhooks
        WHERE user_id = ?
        ORDER BY created_at DESC
      `;

      db.all(query, [userId], (err, rows) => {
        if (err) {
          reject(err);
        } else {
          const webhooks = rows.map(row => ({
            ...row,
            events: JSON.parse(row.events)
          }));
          resolve(webhooks);
        }
      });
    });
  }

  /**
   * Get a specific webhook
   */
  static async getWebhook(webhookId, userId = null) {
    return new Promise((resolve, reject) => {
      let query = 'SELECT * FROM webhooks WHERE id = ?';
      const params = [webhookId];

      if (userId) {
        query += ' AND user_id = ?';
        params.push(userId);
      }

      db.get(query, params, (err, row) => {
        if (err) {
          reject(err);
        } else if (!row) {
          resolve(null);
        } else {
          resolve({
            ...row,
            events: JSON.parse(row.events)
          });
        }
      });
    });
  }

  /**
   * Update a webhook
   */
  static async update(webhookId, userId, updates) {
    return new Promise((resolve, reject) => {
      const fields = [];
      const params = [];

      if (updates.name) {
        fields.push('name = ?');
        params.push(updates.name);
      }

      if (updates.url) {
        fields.push('url = ?');
        params.push(updates.url);
      }

      if (updates.events) {
        fields.push('events = ?');
        params.push(JSON.stringify(updates.events));
      }

      if (updates.is_active !== undefined) {
        fields.push('is_active = ?');
        params.push(updates.is_active ? 1 : 0);
      }

      fields.push('updated_at = CURRENT_TIMESTAMP');
      params.push(webhookId, userId);

      const query = `
        UPDATE webhooks
        SET ${fields.join(', ')}
        WHERE id = ? AND user_id = ?
      `;

      db.run(query, params, function(err) {
        if (err) {
          reject(err);
        } else {
          resolve(this.changes > 0);
        }
      });
    });
  }

  /**
   * Delete a webhook
   */
  static async delete(webhookId, userId) {
    return new Promise((resolve, reject) => {
      const query = 'DELETE FROM webhooks WHERE id = ? AND user_id = ?';

      db.run(query, [webhookId, userId], function(err) {
        if (err) {
          reject(err);
        } else {
          resolve(this.changes > 0);
        }
      });
    });
  }

  /**
   * Trigger webhooks for an event
   */
  static async trigger(eventType, payload, userId = null) {
    try {
      // Get all webhooks that listen to this event
      let query = `
        SELECT id, user_id, url, secret, events, failure_count
        FROM webhooks
        WHERE is_active = 1
        AND json_extract(events, '$') LIKE ?
      `;
      const params = [`%${eventType}%`];

      if (userId) {
        query += ' AND user_id = ?';
        params.push(userId);
      }

      const webhooks = await new Promise((resolve, reject) => {
        db.all(query, params, (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
      });

      // Trigger each webhook
      const promises = webhooks.map(webhook => 
        this.sendWebhook(webhook.id, webhook.url, webhook.secret, eventType, payload)
      );

      await Promise.allSettled(promises);
      
      console.log(`[Webhook] Triggered ${webhooks.length} webhooks for event: ${eventType}`);
    } catch (error) {
      console.error('[Webhook] Error triggering webhooks:', error);
    }
  }

  /**
   * Send a webhook HTTP request
   */
  static async sendWebhook(webhookId, url, secret, eventType, payload) {
    const startTime = Date.now();
    let responseStatus = null;
    let responseBody = null;
    let errorMessage = null;

    try {
      // Create webhook payload
      const webhookPayload = {
        event: eventType,
        timestamp: new Date().toISOString(),
        data: payload
      };

      // Create signature
      const signature = this.createSignature(JSON.stringify(webhookPayload), secret);

      // Send webhook
      const response = await axios.post(url, webhookPayload, {
        headers: {
          'Content-Type': 'application/json',
          'X-Webhook-Signature': signature,
          'X-Webhook-Event': eventType
        },
        timeout: parseInt(process.env.WEBHOOK_TIMEOUT) || 5000
      });

      responseStatus = response.status;
      responseBody = JSON.stringify(response.data).substring(0, 1000); // Limit size

      // Update webhook success
      await this.updateWebhookStatus(webhookId, true);

      // Log success
      await this.logWebhook(webhookId, eventType, webhookPayload, responseStatus, responseBody, null);

      console.log(`[Webhook] Successfully sent to ${url} (${eventType})`);

    } catch (error) {
      errorMessage = error.message;
      responseStatus = error.response ? error.response.status : 0;

      // Update webhook failure
      await this.updateWebhookStatus(webhookId, false);

      // Log failure
      await this.logWebhook(webhookId, eventType, payload, responseStatus, null, errorMessage);

      console.error(`[Webhook] Failed to send to ${url}:`, errorMessage);
    }
  }

  /**
   * Create webhook signature
   */
  static createSignature(payload, secret) {
    return crypto
      .createHmac('sha256', secret)
      .update(payload)
      .digest('hex');
  }

  /**
   * Verify webhook signature
   */
  static verifySignature(payload, signature, secret) {
    const expectedSignature = this.createSignature(payload, secret);
    return crypto.timingSafeEqual(
      Buffer.from(signature),
      Buffer.from(expectedSignature)
    );
  }

  /**
   * Update webhook status after send attempt
   */
  static async updateWebhookStatus(webhookId, success) {
    return new Promise((resolve, reject) => {
      let query;
      
      if (success) {
        query = `
          UPDATE webhooks
          SET last_triggered = CURRENT_TIMESTAMP,
              failure_count = 0
          WHERE id = ?
        `;
      } else {
        query = `
          UPDATE webhooks
          SET failure_count = failure_count + 1,
              is_active = CASE 
                WHEN failure_count >= 10 THEN 0 
                ELSE is_active 
              END
          WHERE id = ?
        `;
      }

      db.run(query, [webhookId], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  }

  /**
   * Log webhook delivery
   */
  static async logWebhook(webhookId, eventType, payload, responseStatus, responseBody, errorMessage) {
    return new Promise((resolve) => {
      const query = `
        INSERT INTO webhook_logs (webhook_id, event_type, payload, response_status, response_body, error_message)
        VALUES (?, ?, ?, ?, ?, ?)
      `;

      const payloadJson = JSON.stringify(payload).substring(0, 5000); // Limit size

      db.run(query, [webhookId, eventType, payloadJson, responseStatus, responseBody, errorMessage], (err) => {
        if (err) {
          console.error('[Webhook] Error logging webhook:', err);
        }
        resolve();
      });
    });
  }

  /**
   * Get webhook logs
   */
  static async getLogs(webhookId, limit = 50) {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT event_type, response_status, error_message, created_at
        FROM webhook_logs
        WHERE webhook_id = ?
        ORDER BY created_at DESC
        LIMIT ?
      `;

      db.all(query, [webhookId, limit], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  /**
   * Test a webhook
   */
  static async test(webhookId, userId) {
    const webhook = await this.getWebhook(webhookId, userId);
    
    if (!webhook) {
      throw new Error('Webhook not found');
    }

    const testPayload = {
      test: true,
      message: 'This is a test webhook',
      timestamp: new Date().toISOString()
    };

    await this.sendWebhook(
      webhook.id,
      webhook.url,
      webhook.secret,
      'webhook.test',
      testPayload
    );

    return { success: true, message: 'Test webhook sent' };
  }

  /**
   * Clean up old webhook logs
   */
  static async cleanupLogs(daysToKeep = 30) {
    return new Promise((resolve, reject) => {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

      const query = `
        DELETE FROM webhook_logs
        WHERE created_at < ?
      `;

      db.run(query, [cutoffDate.toISOString()], function(err) {
        if (err) {
          reject(err);
        } else {
          console.log(`[Webhook] Cleaned up ${this.changes} old webhook logs`);
          resolve(this.changes);
        }
      });
    });
  }
}

module.exports = WebhookManager;
