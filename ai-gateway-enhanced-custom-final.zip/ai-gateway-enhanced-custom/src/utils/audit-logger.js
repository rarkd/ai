const db = require('../database/db');

/**
 * Audit Logger
 * Tracks all important actions in the system
 */
class AuditLogger {

  /**
   * Log an audit event
   */
  static async log(userId, action, resourceType, resourceId, details, req) {
    return new Promise((resolve, reject) => {
      const ipAddress = req ? (req.ip || req.connection.remoteAddress) : null;
      const userAgent = req ? req.get('user-agent') : null;
      const detailsJson = typeof details === 'object' ? JSON.stringify(details) : details;

      const query = `
        INSERT INTO audit_logs (user_id, action, resource_type, resource_id, details, ip_address, user_agent)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `;

      db.run(query, [userId, action, resourceType, resourceId, detailsJson, ipAddress, userAgent], function(err) {
        if (err) {
          console.error('[Audit Logger] Error logging audit:', err);
          reject(err);
        } else {
          resolve(this.lastID);
        }
      });
    });
  }

  /**
   * Specific audit log methods for common actions
   */

  static async logLogin(userId, success, req) {
    return this.log(
      userId,
      success ? 'login_success' : 'login_failed',
      'auth',
      null,
      { success },
      req
    );
  }

  static async logLogout(userId, req) {
    return this.log(userId, 'logout', 'auth', null, {}, req);
  }

  static async logUserCreate(adminId, newUserId, userDetails, req) {
    return this.log(
      adminId,
      'user_create',
      'user',
      newUserId,
      { username: userDetails.username, email: userDetails.email, role: userDetails.role },
      req
    );
  }

  static async logUserUpdate(adminId, userId, changes, req) {
    return this.log(
      adminId,
      'user_update',
      'user',
      userId,
      changes,
      req
    );
  }

  static async logUserDelete(adminId, userId, req) {
    return this.log(adminId, 'user_delete', 'user', userId, {}, req);
  }

  static async logUserBan(adminId, userId, isBanned, req) {
    return this.log(
      adminId,
      isBanned ? 'user_ban' : 'user_unban',
      'user',
      userId,
      { is_banned: isBanned },
      req
    );
  }

  static async logPasswordChange(userId, isReset, req) {
    return this.log(
      userId,
      isReset ? 'password_reset' : 'password_change',
      'user',
      userId,
      {},
      req
    );
  }

  static async logGroupCreate(adminId, groupId, groupDetails, req) {
    return this.log(
      adminId,
      'group_create',
      'group',
      groupId,
      { name: groupDetails.name },
      req
    );
  }

  static async logGroupUpdate(adminId, groupId, changes, req) {
    return this.log(
      adminId,
      'group_update',
      'group',
      groupId,
      changes,
      req
    );
  }

  static async logGroupDelete(adminId, groupId, req) {
    return this.log(adminId, 'group_delete', 'group', groupId, {}, req);
  }

  static async logModelAssign(adminId, groupId, modelAlias, req) {
    return this.log(
      adminId,
      'model_assign',
      'group',
      groupId,
      { model_alias: modelAlias },
      req
    );
  }

  static async logModelRemove(adminId, groupId, modelAlias, req) {
    return this.log(
      adminId,
      'model_remove',
      'group',
      groupId,
      { model_alias: modelAlias },
      req
    );
  }

  static async logDomainAdd(userId, domain, req) {
    return this.log(
      userId,
      'domain_add',
      'domain',
      null,
      { domain },
      req
    );
  }

  static async logDomainRemove(userId, domainId, domain, req) {
    return this.log(
      userId,
      'domain_remove',
      'domain',
      domainId,
      { domain },
      req
    );
  }

  static async logApiKeyCreate(userId, keyName, req) {
    return this.log(
      userId,
      'api_key_create',
      'api_key',
      null,
      { name: keyName },
      req
    );
  }

  static async logApiKeyDelete(userId, keyId, keyName, req) {
    return this.log(
      userId,
      'api_key_delete',
      'api_key',
      keyId,
      { name: keyName },
      req
    );
  }

  static async logApiRequest(userId, modelAlias, success, responseTime, tokens, req) {
    return this.log(
      userId,
      success ? 'api_request_success' : 'api_request_failed',
      'api',
      null,
      {
        model: modelAlias,
        response_time: responseTime,
        tokens
      },
      req
    );
  }

  static async logWebhookTrigger(userId, webhookId, event, success, req) {
    return this.log(
      userId,
      success ? 'webhook_success' : 'webhook_failed',
      'webhook',
      webhookId,
      { event },
      req
    );
  }

  static async log2FAEnable(userId, req) {
    return this.log(userId, '2fa_enabled', 'auth', userId, {}, req);
  }

  static async log2FADisable(userId, req) {
    return this.log(userId, '2fa_disabled', 'auth', userId, {}, req);
  }

  static async logSecurityEvent(userId, eventType, severity, description, req) {
    return this.log(
      userId,
      eventType,
      'security',
      null,
      { severity, description },
      req
    );
  }

  /**
   * Get audit logs with filtering
   */
  static async getLogs(filters = {}, limit = 100, offset = 0) {
    return new Promise((resolve, reject) => {
      let query = `
        SELECT 
          al.*,
          u.username,
          u.email
        FROM audit_logs al
        LEFT JOIN users u ON al.user_id = u.id
        WHERE 1=1
      `;
      const params = [];

      if (filters.userId) {
        query += ' AND al.user_id = ?';
        params.push(filters.userId);
      }

      if (filters.action) {
        query += ' AND al.action = ?';
        params.push(filters.action);
      }

      if (filters.resourceType) {
        query += ' AND al.resource_type = ?';
        params.push(filters.resourceType);
      }

      if (filters.dateFrom) {
        query += ' AND al.created_at >= ?';
        params.push(filters.dateFrom);
      }

      if (filters.dateTo) {
        query += ' AND al.created_at <= ?';
        params.push(filters.dateTo);
      }

      query += ' ORDER BY al.created_at DESC LIMIT ? OFFSET ?';
      params.push(limit, offset);

      db.all(query, params, (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }

  /**
   * Get audit log count
   */
  static async getLogCount(filters = {}) {
    return new Promise((resolve, reject) => {
      let query = 'SELECT COUNT(*) as count FROM audit_logs WHERE 1=1';
      const params = [];

      if (filters.userId) {
        query += ' AND user_id = ?';
        params.push(filters.userId);
      }

      if (filters.action) {
        query += ' AND action = ?';
        params.push(filters.action);
      }

      if (filters.resourceType) {
        query += ' AND resource_type = ?';
        params.push(filters.resourceType);
      }

      if (filters.dateFrom) {
        query += ' AND created_at >= ?';
        params.push(filters.dateFrom);
      }

      if (filters.dateTo) {
        query += ' AND created_at <= ?';
        params.push(filters.dateTo);
      }

      db.get(query, params, (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve(row.count);
        }
      });
    });
  }

  /**
   * Get audit statistics
   */
  static async getStats(days = 7) {
    return new Promise((resolve, reject) => {
      const dateFrom = new Date();
      dateFrom.setDate(dateFrom.getDate() - days);

      const query = `
        SELECT 
          action,
          COUNT(*) as count,
          DATE(created_at) as date
        FROM audit_logs
        WHERE created_at >= ?
        GROUP BY action, DATE(created_at)
        ORDER BY date DESC, count DESC
      `;

      db.all(query, [dateFrom.toISOString()], (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }

  /**
   * Get user activity summary
   */
  static async getUserActivity(userId, days = 30) {
    return new Promise((resolve, reject) => {
      const dateFrom = new Date();
      dateFrom.setDate(dateFrom.getDate() - days);

      const query = `
        SELECT 
          action,
          resource_type,
          COUNT(*) as count
        FROM audit_logs
        WHERE user_id = ? AND created_at >= ?
        GROUP BY action, resource_type
        ORDER BY count DESC
      `;

      db.all(query, [userId, dateFrom.toISOString()], (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }

  /**
   * Clean up old audit logs
   */
  static async cleanup(daysToKeep = 90) {
    return new Promise((resolve, reject) => {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

      const query = `
        DELETE FROM audit_logs
        WHERE created_at < ?
      `;

      db.run(query, [cutoffDate.toISOString()], function(err) {
        if (err) {
          reject(err);
        } else {
          console.log(`[Audit Logger] Cleaned up ${this.changes} old audit logs`);
          resolve(this.changes);
        }
      });
    });
  }

  /**
   * Export audit logs to JSON
   */
  static async exportToJson(filters = {}) {
    const logs = await this.getLogs(filters, 10000, 0);
    return {
      exportDate: new Date().toISOString(),
      filters,
      totalRecords: logs.length,
      logs
    };
  }
}

module.exports = AuditLogger;
