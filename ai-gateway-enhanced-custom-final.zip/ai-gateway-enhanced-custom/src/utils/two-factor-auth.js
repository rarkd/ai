const speakeasy = require('speakeasy');
const QRCode = require('qrcode');
const db = require('../database/db');
const AuditLogger = require('./audit-logger');

/**
 * Two-Factor Authentication Manager
 * Handles 2FA setup, verification, and management
 */
class TwoFactorAuth {

  /**
   * Generate 2FA secret for a user
   */
  static async generateSecret(userId, userEmail) {
    try {
      const secret = speakeasy.generateSecret({
        name: `AI Gateway (${userEmail})`,
        issuer: 'AI Gateway Enhanced'
      });

      return {
        secret: secret.base32,
        otpauth_url: secret.otpauth_url
      };
    } catch (error) {
      console.error('[2FA] Error generating secret:', error);
      throw error;
    }
  }

  /**
   * Generate QR code for 2FA setup
   */
  static async generateQRCode(otpauthUrl) {
    try {
      const qrCode = await QRCode.toDataURL(otpauthUrl);
      return qrCode;
    } catch (error) {
      console.error('[2FA] Error generating QR code:', error);
      throw error;
    }
  }

  /**
   * Enable 2FA for a user
   */
  static async enable(userId, secret, token, req) {
    try {
      // Verify the token first
      const isValid = this.verifyToken(secret, token);
      
      if (!isValid) {
        return {
          success: false,
          message: 'Invalid verification code'
        };
      }

      // Store the secret in database
      await new Promise((resolve, reject) => {
        const query = `
          UPDATE users
          SET two_factor_secret = ?,
              two_factor_enabled = 1,
              updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `;

        db.run(query, [secret, userId], (err) => {
          if (err) reject(err);
          else resolve();
        });
      });

      // Log audit
      await AuditLogger.log2FAEnable(userId, req);

      return {
        success: true,
        message: '2FA enabled successfully'
      };
    } catch (error) {
      console.error('[2FA] Error enabling 2FA:', error);
      throw error;
    }
  }

  /**
   * Disable 2FA for a user
   */
  static async disable(userId, token, req) {
    try {
      // Get user's secret
      const user = await this.getUserSecret(userId);
      
      if (!user || !user.two_factor_enabled) {
        return {
          success: false,
          message: '2FA is not enabled'
        };
      }

      // Verify the token
      const isValid = this.verifyToken(user.two_factor_secret, token);
      
      if (!isValid) {
        return {
          success: false,
          message: 'Invalid verification code'
        };
      }

      // Disable 2FA
      await new Promise((resolve, reject) => {
        const query = `
          UPDATE users
          SET two_factor_secret = NULL,
              two_factor_enabled = 0,
              updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `;

        db.run(query, [userId], (err) => {
          if (err) reject(err);
          else resolve();
        });
      });

      // Log audit
      await AuditLogger.log2FADisable(userId, req);

      return {
        success: true,
        message: '2FA disabled successfully'
      };
    } catch (error) {
      console.error('[2FA] Error disabling 2FA:', error);
      throw error;
    }
  }

  /**
   * Verify a 2FA token
   */
  static verifyToken(secret, token) {
    try {
      return speakeasy.totp.verify({
        secret: secret,
        encoding: 'base32',
        token: token,
        window: 2 // Allow 2 time steps before and after
      });
    } catch (error) {
      console.error('[2FA] Error verifying token:', error);
      return false;
    }
  }

  /**
   * Get user's 2FA secret
   */
  static async getUserSecret(userId) {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT id, email, two_factor_secret, two_factor_enabled
        FROM users
        WHERE id = ?
      `;

      db.get(query, [userId], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  /**
   * Check if user has 2FA enabled
   */
  static async isEnabled(userId) {
    const user = await this.getUserSecret(userId);
    return user && user.two_factor_enabled === 1;
  }

  /**
   * Verify user's 2FA during login
   */
  static async verifyLogin(userId, token) {
    try {
      const user = await this.getUserSecret(userId);
      
      if (!user || !user.two_factor_enabled) {
        return {
          required: false,
          valid: true // 2FA not required
        };
      }

      if (!token) {
        return {
          required: true,
          valid: false,
          message: '2FA code required'
        };
      }

      const isValid = this.verifyToken(user.two_factor_secret, token);

      return {
        required: true,
        valid: isValid,
        message: isValid ? '2FA verified' : 'Invalid 2FA code'
      };
    } catch (error) {
      console.error('[2FA] Error verifying login:', error);
      throw error;
    }
  }

  /**
   * Generate backup codes for 2FA
   */
  static generateBackupCodes(count = 8) {
    const codes = [];
    for (let i = 0; i < count; i++) {
      const code = speakeasy.generateSecret({ length: 10 }).base32.substring(0, 8);
      codes.push(code);
    }
    return codes;
  }

  /**
   * Middleware to enforce 2FA on protected routes
   */
  static middleware() {
    return async (req, res, next) => {
      try {
        if (!req.user || !req.user.id) {
          return res.status(401).json({ error: 'Authentication required' });
        }

        const isEnabled = await this.isEnabled(req.user.id);

        if (isEnabled) {
          const token = req.headers['x-2fa-token'] || req.body.twoFactorToken;
          
          if (!token) {
            return res.status(403).json({
              error: '2FA verification required',
              twoFactorRequired: true
            });
          }

          const user = await this.getUserSecret(req.user.id);
          const isValid = this.verifyToken(user.two_factor_secret, token);

          if (!isValid) {
            return res.status(403).json({
              error: 'Invalid 2FA code',
              twoFactorRequired: true
            });
          }
        }

        next();
      } catch (error) {
        console.error('[2FA Middleware] Error:', error);
        next(error);
      }
    };
  }

  /**
   * Get 2FA status for a user
   */
  static async getStatus(userId) {
    try {
      const user = await this.getUserSecret(userId);
      
      return {
        enabled: user && user.two_factor_enabled === 1,
        email: user ? user.email : null
      };
    } catch (error) {
      console.error('[2FA] Error getting status:', error);
      throw error;
    }
  }
}

module.exports = TwoFactorAuth;
