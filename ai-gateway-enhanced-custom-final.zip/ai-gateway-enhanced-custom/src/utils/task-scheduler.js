const cron = require('cron');
const RateLimiter = require('../middleware/ratelimit.middleware');
const QuotaManager = require('../middleware/quota.middleware');
const AuditLogger = require('./audit-logger');
const EmailManager = require('./email-manager');
const WebhookManager = require('./webhook-manager');

/**
 * Task Scheduler
 * Handles periodic maintenance tasks
 */
class TaskScheduler {
  
  constructor() {
    this.jobs = [];
  }

  /**
   * Start all scheduled tasks
   */
  start() {
    console.log('[Scheduler] Starting periodic tasks...');

    // Clean up rate limit tracking every hour
    this.jobs.push(new cron.CronJob(
      '0 * * * *', // Every hour
      async () => {
        console.log('[Scheduler] Running rate limit cleanup...');
        try {
          await RateLimiter.cleanup();
        } catch (error) {
          console.error('[Scheduler] Rate limit cleanup failed:', error);
        }
      },
      null,
      true,
      'UTC'
    ));

    // Process email queue every 5 minutes
    this.jobs.push(new cron.CronJob(
      '*/5 * * * *', // Every 5 minutes
      async () => {
        console.log('[Scheduler] Processing email queue...');
        try {
          await EmailManager.processQueue();
        } catch (error) {
          console.error('[Scheduler] Email queue processing failed:', error);
        }
      },
      null,
      true,
      'UTC'
    ));

    // Check quota warnings daily at 9 AM
    this.jobs.push(new cron.CronJob(
      '0 9 * * *', // Daily at 9 AM UTC
      async () => {
        console.log('[Scheduler] Checking quota warnings...');
        try {
          await this.checkQuotaWarnings();
        } catch (error) {
          console.error('[Scheduler] Quota warning check failed:', error);
        }
      },
      null,
      true,
      'UTC'
    ));

    // Clean up old audit logs weekly
    this.jobs.push(new cron.CronJob(
      '0 2 * * 0', // Every Sunday at 2 AM UTC
      async () => {
        console.log('[Scheduler] Running audit log cleanup...');
        try {
          await AuditLogger.cleanup(90); // Keep 90 days
        } catch (error) {
          console.error('[Scheduler] Audit log cleanup failed:', error);
        }
      },
      null,
      true,
      'UTC'
    ));

    // Clean up old webhook logs weekly
    this.jobs.push(new cron.CronJob(
      '0 3 * * 0', // Every Sunday at 3 AM UTC
      async () => {
        console.log('[Scheduler] Running webhook log cleanup...');
        try {
          await WebhookManager.cleanupLogs(30); // Keep 30 days
        } catch (error) {
          console.error('[Scheduler] Webhook log cleanup failed:', error);
        }
      },
      null,
      true,
      'UTC'
    ));

    // Clean up old quota records monthly
    this.jobs.push(new cron.CronJob(
      '0 4 1 * *', // First day of month at 4 AM UTC
      async () => {
        console.log('[Scheduler] Running quota record cleanup...');
        try {
          await QuotaManager.cleanupOldRecords(12); // Keep 12 months
        } catch (error) {
          console.error('[Scheduler] Quota cleanup failed:', error);
        }
      },
      null,
      true,
      'UTC'
    ));

    // Clean up old email queue monthly
    this.jobs.push(new cron.CronJob(
      '0 5 1 * *', // First day of month at 5 AM UTC
      async () => {
        console.log('[Scheduler] Running email queue cleanup...');
        try {
          await EmailManager.cleanup(30); // Keep 30 days
        } catch (error) {
          console.error('[Scheduler] Email cleanup failed:', error);
        }
      },
      null,
      true,
      'UTC'
    ));

    // Monthly report on first day of month
    this.jobs.push(new cron.CronJob(
      '0 10 1 * *', // First day of month at 10 AM UTC
      async () => {
        console.log('[Scheduler] Generating monthly reports...');
        try {
          await this.sendMonthlyReports();
        } catch (error) {
          console.error('[Scheduler] Monthly report generation failed:', error);
        }
      },
      null,
      true,
      'UTC'
    ));

    console.log(`[Scheduler] Started ${this.jobs.length} scheduled tasks`);
  }

  /**
   * Stop all scheduled tasks
   */
  stop() {
    console.log('[Scheduler] Stopping all scheduled tasks...');
    this.jobs.forEach(job => job.stop());
    this.jobs = [];
    console.log('[Scheduler] All tasks stopped');
  }

  /**
   * Check and send quota warnings
   */
  async checkQuotaWarnings() {
    try {
      // Get users at 80% quota
      const users = await QuotaManager.getUsersApproachingQuota(80);

      console.log(`[Scheduler] Found ${users.length} users approaching quota limit`);

      for (const user of users) {
        const percentUsed = Math.round(user.percent_used);
        
        // Send email warning
        await EmailManager.sendQuotaWarningEmail(
          user.id,
          user.email,
          user.username,
          percentUsed,
          user.quota_limit,
          user.total_tokens
        );

        // Trigger webhook
        await WebhookManager.trigger(
          WebhookManager.EVENTS.QUOTA_WARNING,
          {
            userId: user.id,
            username: user.username,
            email: user.email,
            percentUsed,
            limit: user.quota_limit,
            used: user.total_tokens
          },
          user.id
        );

        console.log(`[Scheduler] Sent quota warning to ${user.username} (${percentUsed}%)`);
      }

    } catch (error) {
      console.error('[Scheduler] Error checking quota warnings:', error);
      throw error;
    }
  }

  /**
   * Send monthly reports to all users
   */
  async sendMonthlyReports() {
    const db = require('../database/db');

    try {
      // Get all active users
      const users = await new Promise((resolve, reject) => {
        const query = `
          SELECT id, username, email
          FROM users
          WHERE is_banned = 0 AND role = 'user'
        `;

        db.all(query, [], (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
      });

      console.log(`[Scheduler] Generating monthly reports for ${users.length} users`);

      for (const user of users) {
        // Get usage stats for the previous month
        const stats = await this.getUserMonthlyStats(user.id);

        if (stats.totalRequests > 0) {
          // Send email report
          await EmailManager.sendMonthlyReport(
            user.id,
            user.email,
            user.username,
            stats
          );

          // Trigger webhook
          await WebhookManager.trigger(
            WebhookManager.EVENTS.MONTHLY_REPORT,
            {
              userId: user.id,
              username: user.username,
              stats
            },
            user.id
          );

          console.log(`[Scheduler] Sent monthly report to ${user.username}`);
        }
      }

    } catch (error) {
      console.error('[Scheduler] Error sending monthly reports:', error);
      throw error;
    }
  }

  /**
   * Get user's monthly statistics
   */
  async getUserMonthlyStats(userId) {
    const db = require('../database/db');

    return new Promise((resolve, reject) => {
      // Get last month's date range
      const now = new Date();
      const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const lastMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0);

      const query = `
        SELECT 
          COUNT(*) as totalRequests,
          SUM(total_tokens) as totalTokens,
          model_alias
        FROM usage_logs
        WHERE user_id = ?
        AND created_at >= ?
        AND created_at <= ?
        GROUP BY model_alias
        ORDER BY COUNT(*) DESC
      `;

      db.all(query, [userId, lastMonth.toISOString(), lastMonthEnd.toISOString()], (err, rows) => {
        if (err) {
          reject(err);
        } else {
          const totalRequests = rows.reduce((sum, row) => sum + row.totalRequests, 0);
          const totalTokens = rows.reduce((sum, row) => sum + (row.totalTokens || 0), 0);
          const mostUsedModel = rows.length > 0 ? rows[0].model_alias : 'N/A';

          // Get quota info
          QuotaManager.checkQuota(userId).then(quota => {
            resolve({
              totalRequests,
              totalTokens,
              mostUsedModel,
              percentUsed: quota.percentUsed
            });
          }).catch(reject);
        }
      });
    });
  }

  /**
   * Manual trigger for testing
   */
  async runTask(taskName) {
    console.log(`[Scheduler] Manually running task: ${taskName}`);

    switch (taskName) {
      case 'rate-limit-cleanup':
        await RateLimiter.cleanup();
        break;
      case 'email-queue':
        await EmailManager.processQueue();
        break;
      case 'quota-warnings':
        await this.checkQuotaWarnings();
        break;
      case 'audit-cleanup':
        await AuditLogger.cleanup(90);
        break;
      case 'webhook-cleanup':
        await WebhookManager.cleanupLogs(30);
        break;
      case 'quota-cleanup':
        await QuotaManager.cleanupOldRecords(12);
        break;
      case 'email-cleanup':
        await EmailManager.cleanup(30);
        break;
      case 'monthly-reports':
        await this.sendMonthlyReports();
        break;
      default:
        console.log(`[Scheduler] Unknown task: ${taskName}`);
    }
  }

  /**
   * Get scheduler status
   */
  getStatus() {
    return {
      running: this.jobs.length > 0,
      jobCount: this.jobs.length,
      jobs: this.jobs.map((job, index) => ({
        index,
        running: job.running,
        lastDate: job.lastDate()
      }))
    };
  }
}

// Create singleton instance
const scheduler = new TaskScheduler();

module.exports = scheduler;
