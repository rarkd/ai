const nodemailer = require('nodemailer');
const db = require('../database/db');

/**
 * Email Notification Manager
 * Handles sending email notifications
 */
class EmailManager {

  /**
   * Create email transporter
   */
  static createTransporter() {
    // Get settings from database or environment
    const config = {
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT) || 587,
      secure: process.env.SMTP_SECURE === 'true',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      }
    };

    return nodemailer.createTransporter(config);
  }

  /**
   * Check if email is enabled
   */
  static async isEnabled() {
    return new Promise((resolve) => {
      const query = 'SELECT value FROM system_settings WHERE key = ?';
      
      db.get(query, ['SMTP_ENABLED'], (err, row) => {
        if (err || !row) {
          resolve(false);
        } else {
          resolve(row.value === 'true');
        }
      });
    });
  }

  /**
   * Queue an email
   */
  static async queueEmail(userId, toEmail, subject, body) {
    return new Promise((resolve, reject) => {
      const query = `
        INSERT INTO email_queue (user_id, to_email, subject, body, status)
        VALUES (?, ?, ?, ?, 'pending')
      `;

      db.run(query, [userId, toEmail, subject, body], function(err) {
        if (err) {
          reject(err);
        } else {
          resolve(this.lastID);
        }
      });
    });
  }

  /**
   * Send an email directly
   */
  static async sendEmail(toEmail, subject, html, text = null) {
    try {
      const enabled = await this.isEnabled();
      
      if (!enabled) {
        console.log('[Email] SMTP not enabled, email not sent');
        return { success: false, message: 'SMTP not enabled' };
      }

      const transporter = this.createTransporter();
      const fromEmail = process.env.SMTP_FROM || 'noreply@gateway.local';

      const mailOptions = {
        from: fromEmail,
        to: toEmail,
        subject: subject,
        html: html,
        text: text || this.stripHtml(html)
      };

      const info = await transporter.sendMail(mailOptions);

      console.log(`[Email] Sent to ${toEmail}: ${subject}`);
      return { success: true, messageId: info.messageId };
      
    } catch (error) {
      console.error('[Email] Error sending:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Send queued emails
   */
  static async processQueue() {
    try {
      const enabled = await this.isEnabled();
      
      if (!enabled) {
        return;
      }

      // Get pending emails
      const emails = await new Promise((resolve, reject) => {
        const query = `
          SELECT id, to_email, subject, body, attempts
          FROM email_queue
          WHERE status = 'pending' AND attempts < 3
          ORDER BY created_at ASC
          LIMIT 10
        `;

        db.all(query, [], (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
      });

      if (emails.length === 0) {
        return;
      }

      console.log(`[Email] Processing ${emails.length} queued emails`);

      // Send each email
      for (const email of emails) {
        const result = await this.sendEmail(email.to_email, email.subject, email.body);
        
        if (result.success) {
          await this.markEmailSent(email.id);
        } else {
          await this.markEmailFailed(email.id, result.error);
        }
      }
    } catch (error) {
      console.error('[Email] Error processing queue:', error);
    }
  }

  /**
   * Mark email as sent
   */
  static async markEmailSent(emailId) {
    return new Promise((resolve) => {
      const query = `
        UPDATE email_queue
        SET status = 'sent',
            sent_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `;

      db.run(query, [emailId], (err) => {
        if (err) {
          console.error('[Email] Error marking as sent:', err);
        }
        resolve();
      });
    });
  }

  /**
   * Mark email as failed
   */
  static async markEmailFailed(emailId, errorMessage) {
    return new Promise((resolve) => {
      const query = `
        UPDATE email_queue
        SET attempts = attempts + 1,
            error_message = ?,
            status = CASE WHEN attempts >= 2 THEN 'failed' ELSE 'pending' END
        WHERE id = ?
      `;

      db.run(query, [errorMessage, emailId], (err) => {
        if (err) {
          console.error('[Email] Error marking as failed:', err);
        }
        resolve();
      });
    });
  }

  /**
   * Email templates
   */

  static welcomeEmail(username) {
    return {
      subject: 'Welcome to AI Gateway',
      html: `
        <h2>Welcome to AI Gateway, ${username}!</h2>
        <p>Your account has been created successfully.</p>
        <p>You can now:</p>
        <ul>
          <li>Access AI models based on your group</li>
          <li>Manage your CORS domains</li>
          <li>Generate API keys</li>
          <li>View usage statistics</li>
        </ul>
        <p>Visit your dashboard to get started.</p>
        <p>Best regards,<br>AI Gateway Team</p>
      `
    };
  }

  static passwordResetEmail(username, resetToken) {
    return {
      subject: 'Password Reset Request',
      html: `
        <h2>Password Reset Request</h2>
        <p>Hello ${username},</p>
        <p>You have requested to reset your password.</p>
        <p>Your temporary password is: <strong>${resetToken}</strong></p>
        <p>Please log in and change your password immediately.</p>
        <p>If you didn't request this, please contact an administrator.</p>
        <p>Best regards,<br>AI Gateway Team</p>
      `
    };
  }

  static quotaWarningEmail(username, percentUsed, limit, used) {
    return {
      subject: 'Quota Warning - Usage at ' + percentUsed + '%',
      html: `
        <h2>Quota Warning</h2>
        <p>Hello ${username},</p>
        <p>Your usage has reached <strong>${percentUsed}%</strong> of your monthly quota.</p>
        <p>Current usage: <strong>${used.toLocaleString()}</strong> / ${limit.toLocaleString()} tokens</p>
        <p>Please monitor your usage to avoid service interruption.</p>
        <p>Visit your dashboard to see detailed statistics.</p>
        <p>Best regards,<br>AI Gateway Team</p>
      `
    };
  }

  static quotaExceededEmail(username, limit) {
    return {
      subject: 'Quota Exceeded - Service Suspended',
      html: `
        <h2>Quota Exceeded</h2>
        <p>Hello ${username},</p>
        <p>You have exceeded your monthly quota of <strong>${limit.toLocaleString()}</strong> tokens.</p>
        <p>Your service has been temporarily suspended until the next billing cycle.</p>
        <p>Please contact support to upgrade your plan or wait for quota reset.</p>
        <p>Best regards,<br>AI Gateway Team</p>
      `
    };
  }

  static apiKeyCreatedEmail(username, keyName, keyPrefix) {
    return {
      subject: 'New API Key Created',
      html: `
        <h2>API Key Created</h2>
        <p>Hello ${username},</p>
        <p>A new API key has been created for your account.</p>
        <p>Key name: <strong>${keyName}</strong></p>
        <p>Key prefix: <strong>${keyPrefix}...</strong></p>
        <p>If you didn't create this key, please delete it immediately from your dashboard.</p>
        <p>Best regards,<br>AI Gateway Team</p>
      `
    };
  }

  static monthlyReportEmail(username, stats) {
    return {
      subject: 'Monthly Usage Report',
      html: `
        <h2>Monthly Usage Report</h2>
        <p>Hello ${username},</p>
        <p>Here's your usage summary for this month:</p>
        <ul>
          <li>Total Requests: <strong>${stats.totalRequests.toLocaleString()}</strong></li>
          <li>Total Tokens: <strong>${stats.totalTokens.toLocaleString()}</strong></li>
          <li>Most Used Model: <strong>${stats.mostUsedModel}</strong></li>
          <li>Quota Used: <strong>${stats.percentUsed}%</strong></li>
        </ul>
        <p>Visit your dashboard for detailed analytics.</p>
        <p>Best regards,<br>AI Gateway Team</p>
      `
    };
  }

  static securityAlertEmail(username, eventType, details) {
    return {
      subject: 'Security Alert - ' + eventType,
      html: `
        <h2>Security Alert</h2>
        <p>Hello ${username},</p>
        <p>A security event has been detected on your account:</p>
        <p><strong>Event:</strong> ${eventType}</p>
        <p><strong>Details:</strong> ${details}</p>
        <p>If this wasn't you, please change your password immediately and contact support.</p>
        <p>Best regards,<br>AI Gateway Team</p>
      `
    };
  }

  /**
   * Send welcome email
   */
  static async sendWelcomeEmail(userId, userEmail, username) {
    const template = this.welcomeEmail(username);
    await this.queueEmail(userId, userEmail, template.subject, template.html);
  }

  /**
   * Send password reset email
   */
  static async sendPasswordResetEmail(userId, userEmail, username, resetToken) {
    const template = this.passwordResetEmail(username, resetToken);
    await this.queueEmail(userId, userEmail, template.subject, template.html);
  }

  /**
   * Send quota warning email
   */
  static async sendQuotaWarningEmail(userId, userEmail, username, percentUsed, limit, used) {
    const template = this.quotaWarningEmail(username, percentUsed, limit, used);
    await this.queueEmail(userId, userEmail, template.subject, template.html);
  }

  /**
   * Send quota exceeded email
   */
  static async sendQuotaExceededEmail(userId, userEmail, username, limit) {
    const template = this.quotaExceededEmail(username, limit);
    await this.queueEmail(userId, userEmail, template.subject, template.html);
  }

  /**
   * Utility: Strip HTML tags
   */
  static stripHtml(html) {
    return html.replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim();
  }

  /**
   * Clean up old emails
   */
  static async cleanup(daysToKeep = 30) {
    return new Promise((resolve, reject) => {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

      const query = `
        DELETE FROM email_queue
        WHERE created_at < ? AND status = 'sent'
      `;

      db.run(query, [cutoffDate.toISOString()], function(err) {
        if (err) {
          reject(err);
        } else {
          console.log(`[Email] Cleaned up ${this.changes} old emails`);
          resolve(this.changes);
        }
      });
    });
  }
}

module.exports = EmailManager;
