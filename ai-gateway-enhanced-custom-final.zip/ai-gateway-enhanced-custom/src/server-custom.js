const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
require('dotenv').config();

const db = require('./database/db');
const corsMiddleware = require('./middleware/cors-custom.middleware');

// Import routes - using CUSTOM routes
const authRoutes = require('./routes/auth.routes');
const adminRoutes = require('./routes/admin-custom.routes');
const userRoutes = require('./routes/user-custom.routes');
const gatewayRoutes = require('./routes/gateway-custom.routes');

const app = express();
const PORT = process.env.PORT || 422;

// Connect to database
db.connect()
  .then(() => console.log('[Server Custom] Database connected'))
  .catch(err => {
    console.error('[Server Custom] Database connection failed:', err);
    process.exit(1);
  });

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Logging middleware
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${req.method} ${req.path}`);
  next();
});

// Basic CORS for auth and health endpoints (allow all)
app.use(['/auth', '/health'], (req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// Serve static files (Web UI) - Admin and User dashboards
app.use(express.static(path.join(__dirname, '../public')));

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'AI Gateway Enhanced - Custom Edition',
    timestamp: new Date().toISOString(),
    version: '3.0.0-custom',
    features: {
      rate_limiting: false,
      quota_management: false,
      group_cors: true,
      admin_impersonation: true,
      model_rules: true,
      user_knowledge_base: true
    }
  });
});

// API Routes
app.use('/auth', authRoutes);         // Authentication endpoints
app.use('/admin', adminRoutes);        // Admin management endpoints (CUSTOM)
app.use('/user', userRoutes);          // User self-service endpoints (CUSTOM)
app.use('/api', gatewayRoutes);        // AI Gateway endpoints (CUSTOM)

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Endpoint not found',
    path: req.path,
    method: req.method
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error('[Server Error]:', err);
  res.status(500).json({
    error: 'Internal server error',
    message: err.message
  });
});

// Start server
app.listen(PORT, () => {
  console.log('=================================');
  console.log('🚀 AI Gateway Enhanced - CUSTOM EDITION');
  console.log('=================================');
  console.log(`📡 Server running on: http://localhost:${PORT}`);
  console.log(`🌐 Admin Dashboard: http://localhost:${PORT}/admin.html`);
  console.log(`👤 User Dashboard: http://localhost:${PORT}/user.html`);
  console.log(`🔗 Ollama endpoint: ${process.env.OLLAMA_BASE_URL || 'https://aiapi.awwlk.my.id'}`);
  console.log('=================================');
  console.log('');
  console.log('✨ CUSTOM FEATURES:');
  console.log('  ✅ Group-based CORS (Allowed Domains)');
  console.log('  ✅ Admin Login as User (Impersonation)');
  console.log('  ✅ Model Rules (Admin-configured)');
  console.log('  ✅ User Knowledge Base');
  console.log('  ❌ NO Rate Limiting');
  console.log('  ❌ NO Monthly Quotas');
  console.log('=================================');
  console.log('');
  console.log('🔐 Authentication Endpoints:');
  console.log(`  POST /auth/login              - Login`);
  console.log(`  POST /auth/register           - Register (admin only)`);
  console.log(`  GET  /auth/me                 - Get current user`);
  console.log(`  POST /auth/change-password    - Change password`);
  console.log('');
  console.log('👨‍💼 Admin Endpoints:');
  console.log(`  GET  /admin/users             - List users`);
  console.log(`  POST /admin/users             - Create user`);
  console.log(`  PUT  /admin/users/:id         - Update user`);
  console.log(`  DELETE /admin/users/:id       - Delete user`);
  console.log(`  POST /admin/users/:id/impersonate - Login as user 🆕`);
  console.log(`  GET  /admin/impersonation-logs    - View impersonation logs 🆕`);
  console.log(`  GET  /admin/groups            - List groups`);
  console.log(`  POST /admin/groups            - Create group`);
  console.log(`  PUT  /admin/groups/:id        - Update group (with CORS domains) 🆕`);
  console.log(`  GET  /admin/model-rules       - List model rules 🆕`);
  console.log(`  POST /admin/model-rules       - Create model rule 🆕`);
  console.log(`  PUT  /admin/model-rules/:alias - Update model rule 🆕`);
  console.log(`  DELETE /admin/model-rules/:alias - Delete model rule 🆕`);
  console.log(`  GET  /admin/stats             - Dashboard stats`);
  console.log('');
  console.log('👤 User Endpoints:');
  console.log(`  GET  /user/profile            - Get profile`);
  console.log(`  GET  /user/models             - Get available models`);
  console.log(`  GET  /user/domains            - Get allowed domains`);
  console.log(`  POST /user/domains            - Add domain`);
  console.log(`  GET  /user/api-keys           - Get API keys`);
  console.log(`  POST /user/api-keys           - Create API key`);
  console.log(`  GET  /user/knowledge-base     - List knowledge base 🆕`);
  console.log(`  POST /user/knowledge-base     - Create knowledge entry 🆕`);
  console.log(`  PUT  /user/knowledge-base/:id - Update knowledge entry 🆕`);
  console.log(`  DELETE /user/knowledge-base/:id - Delete knowledge entry 🆕`);
  console.log('');
  console.log('🤖 AI Gateway:');
  console.log(`  POST /api/:model              - AI request (with model rules & KB) 🆕`);
  console.log(`  GET  /api/models/available    - List available models`);
  console.log(`  GET  /api/models/:model/rules - Get model rules 🆕`);
  console.log('=================================');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully...');
  db.close().then(() => {
    console.log('Database connection closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('\nSIGINT received, shutting down gracefully...');
  db.close().then(() => {
    console.log('Database connection closed');
    process.exit(0);
  });
});

module.exports = app;
