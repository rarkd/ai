const express = require('express');
const axios = require('axios');
const db = require('../database/db');
const { authenticate, requireGroup } = require('../middleware/auth.middleware');
const corsMiddleware = require('../middleware/cors-custom.middleware');

const router = express.Router();

const OLLAMA_BASE_URL = process.env.OLLAMA_BASE_URL || 'https://aiapi.awwlk.my.id';
const OLLAMA_GENERATE_ENDPOINT = process.env.OLLAMA_GENERATE_ENDPOINT || '/api/generate';

// Helper function to get model rules
async function getModelRules(modelAlias) {
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM model_rules WHERE model_alias = ?', [modelAlias], (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

// Helper function to get user's active knowledge base
async function getUserKnowledgeBase(userId) {
  return new Promise((resolve, reject) => {
    db.all(
      'SELECT name, content FROM user_knowledge_base WHERE user_id = ? AND is_active = 1',
      [userId],
      (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      }
    );
  });
}

// Gateway endpoint - handles AI requests with model rules and knowledge base
router.post('/:model', authenticate, requireGroup, corsMiddleware, async (req, res) => {
  const startTime = Date.now();
  
  try {
    const requestedModel = req.params.model;
    const userId = req.user.id;
    const groupId = req.user.group_id;

    // Check if user has access to this model through their group
    const allowedModel = await new Promise((resolve, reject) => {
      db.get(
        'SELECT model_alias, model_name FROM group_models WHERE group_id = ? AND model_alias = ?',
        [groupId, requestedModel],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!allowedModel) {
      return res.status(403).json({
        error: 'Model not allowed',
        message: `You don't have access to the model '${requestedModel}'. Check your group permissions.`
      });
    }

    // Get the actual Ollama model name
    const ollamaModel = allowedModel.model_name;

    console.log(`[Gateway Custom] User ${req.user.username} requesting ${requestedModel} -> ${ollamaModel}`);

    // Get model rules (admin-configured)
    const modelRules = await getModelRules(requestedModel);
    
    // Get user's knowledge base
    const userKnowledge = await getUserKnowledgeBase(userId);

    // Build enhanced prompt with system instructions and knowledge base
    let enhancedPrompt = '';
    let systemPrompt = '';

    // Add system prompt from model rules
    if (modelRules && modelRules.system_prompt) {
      systemPrompt = modelRules.system_prompt;
    }

    // Add user's knowledge base context
    if (userKnowledge && userKnowledge.length > 0) {
      const knowledgeContext = userKnowledge
        .map(kb => `[${kb.name}]\n${kb.content}`)
        .join('\n\n---\n\n');
      
      systemPrompt += `\n\n## User Context and Knowledge Base:\n${knowledgeContext}`;
    }

    // Get user's prompt
    let userPrompt = req.body.prompt || '';
    
    // Handle OpenAI-style messages format
    if (req.body.messages && Array.isArray(req.body.messages)) {
      const messages = req.body.messages;
      
      // Extract system message if present
      const systemMessage = messages.find(m => m.role === 'system');
      if (systemMessage && !systemPrompt) {
        systemPrompt = systemMessage.content;
      }
      
      // Get user messages
      const userMessages = messages.filter(m => m.role === 'user');
      if (userMessages.length > 0) {
        userPrompt = userMessages.map(m => m.content).join('\n');
      }
    }

    // Combine system prompt and user prompt
    if (systemPrompt) {
      enhancedPrompt = `${systemPrompt}\n\n---\n\n${userPrompt}`;
    } else {
      enhancedPrompt = userPrompt;
    }

    // Prepare request to Ollama with model rules
    const ollamaRequest = {
      model: ollamaModel,
      prompt: enhancedPrompt,
      stream: req.body.stream || false,
    };

    // Apply model rules parameters
    if (modelRules) {
      if (modelRules.temperature !== null) {
        ollamaRequest.temperature = modelRules.temperature;
      }
      if (modelRules.max_tokens !== null) {
        ollamaRequest.options = ollamaRequest.options || {};
        ollamaRequest.options.num_predict = modelRules.max_tokens;
      }
      if (modelRules.top_p !== null) {
        ollamaRequest.options = ollamaRequest.options || {};
        ollamaRequest.options.top_p = modelRules.top_p;
      }
      if (modelRules.frequency_penalty !== null) {
        ollamaRequest.options = ollamaRequest.options || {};
        ollamaRequest.options.frequency_penalty = modelRules.frequency_penalty;
      }
      if (modelRules.presence_penalty !== null) {
        ollamaRequest.options = ollamaRequest.options || {};
        ollamaRequest.options.presence_penalty = modelRules.presence_penalty;
      }
      if (modelRules.stop_sequences) {
        try {
          ollamaRequest.stop = JSON.parse(modelRules.stop_sequences);
        } catch (e) {
          console.error('[Gateway Custom] Error parsing stop sequences:', e);
        }
      }
      if (modelRules.other_params) {
        try {
          const otherParams = JSON.parse(modelRules.other_params);
          ollamaRequest.options = { ...ollamaRequest.options, ...otherParams };
        } catch (e) {
          console.error('[Gateway Custom] Error parsing other params:', e);
        }
      }
    }

    // Allow user to override some parameters
    if (req.body.temperature !== undefined) {
      ollamaRequest.temperature = req.body.temperature;
    }
    if (req.body.max_tokens !== undefined) {
      ollamaRequest.options = ollamaRequest.options || {};
      ollamaRequest.options.num_predict = req.body.max_tokens;
    }

    // Forward request to Ollama
    const ollamaResponse = await axios.post(
      `${OLLAMA_BASE_URL}${OLLAMA_GENERATE_ENDPOINT}`,
      ollamaRequest,
      {
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 120000 // 2 minutes timeout
      }
    );

    const endTime = Date.now();
    const duration = endTime - startTime;

    // Log usage (without rate limiting or quota checks)
    try {
      const requestTokens = enhancedPrompt.length || 0;
      const responseTokens = ollamaResponse.data.response?.length || 0;
      const totalTokens = requestTokens + responseTokens;

      await new Promise((resolve, reject) => {
        db.run(
          `INSERT INTO usage_logs (
            user_id, model_alias, request_tokens, response_tokens, 
            total_tokens, request_duration_ms, status_code, 
            ip_address, user_agent
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            userId,
            requestedModel,
            requestTokens,
            responseTokens,
            totalTokens,
            duration,
            200,
            req.ip,
            req.get('user-agent')
          ],
          (err) => {
            if (err) reject(err);
            else resolve();
          }
        );
      });
    } catch (logError) {
      console.error('[Gateway Custom] Error logging usage:', logError);
      // Don't fail the request if logging fails
    }

    // Return response
    res.json(ollamaResponse.data);

  } catch (error) {
    const endTime = Date.now();
    const duration = endTime - startTime;

    console.error('[Gateway Custom] Error:', error.message);
    
    // Log error
    try {
      await new Promise((resolve, reject) => {
        db.run(
          `INSERT INTO usage_logs (
            user_id, model_alias, request_duration_ms, 
            status_code, error_message, ip_address, user_agent
          ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [
            req.user?.id,
            req.params.model,
            duration,
            error.response?.status || 500,
            error.message,
            req.ip,
            req.get('user-agent')
          ],
          (err) => {
            if (err) reject(err);
            else resolve();
          }
        );
      });
    } catch (logError) {
      console.error('[Gateway Custom] Error logging error:', logError);
    }
    
    if (error.response) {
      // Ollama returned an error
      return res.status(error.response.status).json({
        error: 'Ollama error',
        message: error.response.data?.error || error.message
      });
    }

    if (error.code === 'ECONNREFUSED') {
      return res.status(503).json({
        error: 'Service unavailable',
        message: 'Cannot connect to Ollama service'
      });
    }

    if (error.code === 'ETIMEDOUT') {
      return res.status(504).json({
        error: 'Gateway timeout',
        message: 'Request to Ollama timed out'
      });
    }

    res.status(500).json({
      error: 'Gateway error',
      message: error.message
    });
  }
});

// List available models for the authenticated user
router.get('/models/available', authenticate, async (req, res) => {
  try {
    if (!req.user.group_id) {
      return res.json({
        models: [],
        message: 'You are not assigned to any group. Please contact administrator.'
      });
    }

    const models = await new Promise((resolve, reject) => {
      db.all(
        'SELECT model_alias, model_name FROM group_models WHERE group_id = ?',
        [req.user.group_id],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });

    res.json({ models });
  } catch (error) {
    console.error('[Gateway Custom] Error getting models:', error);
    res.status(500).json({
      error: 'Failed to get models',
      message: error.message
    });
  }
});

// Get model rules for a specific model (useful for clients)
router.get('/models/:model/rules', authenticate, async (req, res) => {
  try {
    const modelAlias = req.params.model;
    
    // Check if user has access to this model
    const allowedModel = await new Promise((resolve, reject) => {
      db.get(
        'SELECT model_alias FROM group_models WHERE group_id = ? AND model_alias = ?',
        [req.user.group_id, modelAlias],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!allowedModel) {
      return res.status(403).json({
        error: 'Model not allowed',
        message: `You don't have access to the model '${modelAlias}'.`
      });
    }

    // Get model rules
    const rules = await getModelRules(modelAlias);

    if (!rules) {
      return res.json({
        message: 'No custom rules configured for this model',
        model_alias: modelAlias,
        rules: null
      });
    }

    // Return rules (but hide sensitive info if needed)
    res.json({
      model_alias: rules.model_alias,
      temperature: rules.temperature,
      max_tokens: rules.max_tokens,
      top_p: rules.top_p,
      frequency_penalty: rules.frequency_penalty,
      presence_penalty: rules.presence_penalty,
      // Don't expose full system_prompt to users, just indicate if it exists
      has_system_prompt: !!rules.system_prompt,
      has_stop_sequences: !!rules.stop_sequences,
      updated_at: rules.updated_at
    });
  } catch (error) {
    console.error('[Gateway Custom] Error getting model rules:', error);
    res.status(500).json({
      error: 'Failed to get model rules',
      message: error.message
    });
  }
});

module.exports = router;
