const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { body, validationResult } = require('express-validator');
const { authenticate } = require('../middleware/auth.middleware');
const db = require('../database/db');
const AuditLogger = require('../utils/audit-logger');
const TwoFactorAuth = require('../utils/two-factor-auth');

// Apply authentication to all routes
router.use(authenticate);

// ==================== USER PROFILE ====================

router.get('/profile', async (req, res) => {
  try {
    const user = await new Promise((resolve, reject) => {
      db.get(`
        SELECT 
          u.id, u.username, u.email, u.role, u.group_id,
          u.two_factor_enabled, u.created_at, u.last_login,
          g.name as group_name, g.allowed_domains
        FROM users u
        LEFT JOIN groups g ON u.group_id = g.id
        WHERE u.id = ?
      `, [req.user.id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Get user's domains
    const domains = await new Promise((resolve, reject) => {
      db.all('SELECT * FROM user_domains WHERE user_id = ?', [req.user.id], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    // Get user's models
    const models = await new Promise((resolve, reject) => {
      db.all(`
        SELECT gm.model_alias, gm.model_name
        FROM group_models gm
        WHERE gm.group_id = ?
      `, [user.group_id], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({
      user,
      domains,
      models
    });
  } catch (error) {
    console.error('[User] Error getting profile:', error);
    res.status(500).json({ error: 'Failed to get profile' });
  }
});

router.put('/profile', [
  body('email').optional().isEmail(),
  body('current_password').optional(),
  body('new_password').optional().isLength({ min: 6 })
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { email, current_password, new_password } = req.body;

    // If changing password, verify current password
    if (new_password) {
      if (!current_password) {
        return res.status(400).json({ error: 'Current password is required' });
      }

      const user = await new Promise((resolve, reject) => {
        db.get('SELECT password FROM users WHERE id = ?', [req.user.id], (err, row) => {
          if (err) reject(err);
          else resolve(row);
        });
      });

      const validPassword = await bcrypt.compare(current_password, user.password);
      if (!validPassword) {
        return res.status(400).json({ error: 'Current password is incorrect' });
      }

      const hashedPassword = await bcrypt.hash(new_password, 10);
      
      await new Promise((resolve, reject) => {
        db.run(`
          UPDATE users 
          SET password = ?, updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `, [hashedPassword, req.user.id], (err) => {
          if (err) reject(err);
          else resolve();
        });
      });

      await AuditLogger.log({
        userId: req.user.id,
        action: 'CHANGE_PASSWORD',
        resourceType: 'user',
        resourceId: req.user.id,
        details: 'User changed password',
        ip: req.ip,
        userAgent: req.get('user-agent')
      });
    }

    // Update email if provided
    if (email) {
      await new Promise((resolve, reject) => {
        db.run(`
          UPDATE users 
          SET email = ?, updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `, [email, req.user.id], (err) => {
          if (err) reject(err);
          else resolve();
        });
      });

      await AuditLogger.log({
        userId: req.user.id,
        action: 'UPDATE_PROFILE',
        resourceType: 'user',
        resourceId: req.user.id,
        details: 'User updated email',
        ip: req.ip,
        userAgent: req.get('user-agent')
      });
    }

    res.json({ message: 'Profile updated successfully' });
  } catch (error) {
    console.error('[User] Error updating profile:', error);
    if (error.code === 'SQLITE_CONSTRAINT') {
      res.status(400).json({ error: 'Email already exists' });
    } else {
      res.status(500).json({ error: 'Failed to update profile' });
    }
  }
});

// ==================== API KEY MANAGEMENT ====================

router.get('/api-keys', async (req, res) => {
  try {
    const keys = await new Promise((resolve, reject) => {
      db.all(`
        SELECT id, key_prefix, name, expires_at, created_at, last_used, is_active
        FROM api_keys
        WHERE user_id = ?
        ORDER BY created_at DESC
      `, [req.user.id], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ keys });
  } catch (error) {
    console.error('[User] Error getting API keys:', error);
    res.status(500).json({ error: 'Failed to get API keys' });
  }
});

router.post('/api-keys', [
  body('name').optional().trim(),
  body('expires_in_days').optional().isInt({ min: 1 })
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { name, expires_in_days } = req.body;
    
    // Generate API key
    const apiKey = 'sk-' + crypto.randomBytes(32).toString('hex');
    const keyHash = crypto.createHash('sha256').update(apiKey).digest('hex');
    const keyPrefix = apiKey.substring(0, 10);

    // Calculate expiry date
    let expiresAt = null;
    if (expires_in_days) {
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + expires_in_days);
      expiresAt = expiryDate.toISOString();
    }

    const result = await new Promise((resolve, reject) => {
      db.run(`
        INSERT INTO api_keys (user_id, key_hash, key_prefix, name, expires_at)
        VALUES (?, ?, ?, ?, ?)
      `, [req.user.id, keyHash, keyPrefix, name, expiresAt], function(err) {
        if (err) reject(err);
        else resolve(this.lastID);
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'CREATE_API_KEY',
      resourceType: 'api_key',
      resourceId: result,
      details: `Created API key: ${name || 'Unnamed'}`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.status(201).json({
      message: 'API key created successfully',
      apiKey: apiKey,
      keyId: result,
      warning: 'Save this key now. You will not be able to see it again.'
    });
  } catch (error) {
    console.error('[User] Error creating API key:', error);
    res.status(500).json({ error: 'Failed to create API key' });
  }
});

router.delete('/api-keys/:id', async (req, res) => {
  try {
    // Verify key belongs to user
    const key = await new Promise((resolve, reject) => {
      db.get('SELECT id FROM api_keys WHERE id = ? AND user_id = ?', 
        [req.params.id, req.user.id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!key) {
      return res.status(404).json({ error: 'API key not found' });
    }

    await new Promise((resolve, reject) => {
      db.run('DELETE FROM api_keys WHERE id = ?', [req.params.id], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'DELETE_API_KEY',
      resourceType: 'api_key',
      resourceId: parseInt(req.params.id),
      details: 'Deleted API key',
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({ message: 'API key deleted successfully' });
  } catch (error) {
    console.error('[User] Error deleting API key:', error);
    res.status(500).json({ error: 'Failed to delete API key' });
  }
});

// ==================== DOMAIN MANAGEMENT ====================

router.get('/domains', async (req, res) => {
  try {
    const domains = await new Promise((resolve, reject) => {
      db.all('SELECT * FROM user_domains WHERE user_id = ? ORDER BY created_at DESC', 
        [req.user.id], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ domains });
  } catch (error) {
    console.error('[User] Error getting domains:', error);
    res.status(500).json({ error: 'Failed to get domains' });
  }
});

router.post('/domains', [
  body('domain').trim().notEmpty().withMessage('Domain is required')
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { domain } = req.body;

    const result = await new Promise((resolve, reject) => {
      db.run(`
        INSERT INTO user_domains (user_id, domain)
        VALUES (?, ?)
      `, [req.user.id, domain], function(err) {
        if (err) reject(err);
        else resolve(this.lastID);
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'ADD_DOMAIN',
      resourceType: 'domain',
      resourceId: result,
      details: `Added domain: ${domain}`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.status(201).json({
      message: 'Domain added successfully',
      domainId: result
    });
  } catch (error) {
    console.error('[User] Error adding domain:', error);
    if (error.code === 'SQLITE_CONSTRAINT') {
      res.status(400).json({ error: 'Domain already exists' });
    } else {
      res.status(500).json({ error: 'Failed to add domain' });
    }
  }
});

router.delete('/domains/:id', async (req, res) => {
  try {
    // Verify domain belongs to user
    const domain = await new Promise((resolve, reject) => {
      db.get('SELECT id FROM user_domains WHERE id = ? AND user_id = ?',
        [req.params.id, req.user.id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!domain) {
      return res.status(404).json({ error: 'Domain not found' });
    }

    await new Promise((resolve, reject) => {
      db.run('DELETE FROM user_domains WHERE id = ?', [req.params.id], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'REMOVE_DOMAIN',
      resourceType: 'domain',
      resourceId: parseInt(req.params.id),
      details: 'Removed domain',
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({ message: 'Domain removed successfully' });
  } catch (error) {
    console.error('[User] Error removing domain:', error);
    res.status(500).json({ error: 'Failed to remove domain' });
  }
});

// ==================== KNOWLEDGE BASE MANAGEMENT ====================

router.get('/knowledge-base', async (req, res) => {
  try {
    const knowledgeBase = await new Promise((resolve, reject) => {
      db.all(`
        SELECT id, name, content, is_active, created_at, updated_at
        FROM user_knowledge_base
        WHERE user_id = ?
        ORDER BY created_at DESC
      `, [req.user.id], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ knowledgeBase });
  } catch (error) {
    console.error('[User] Error getting knowledge base:', error);
    res.status(500).json({ error: 'Failed to get knowledge base' });
  }
});

router.get('/knowledge-base/:id', async (req, res) => {
  try {
    const knowledge = await new Promise((resolve, reject) => {
      db.get(`
        SELECT id, name, content, is_active, created_at, updated_at
        FROM user_knowledge_base
        WHERE id = ? AND user_id = ?
      `, [req.params.id, req.user.id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!knowledge) {
      return res.status(404).json({ error: 'Knowledge base entry not found' });
    }

    res.json({ knowledge });
  } catch (error) {
    console.error('[User] Error getting knowledge base entry:', error);
    res.status(500).json({ error: 'Failed to get knowledge base entry' });
  }
});

router.post('/knowledge-base', [
  body('name').trim().isLength({ min: 1 }).withMessage('Name is required'),
  body('content').trim().isLength({ min: 1 }).withMessage('Content is required'),
  body('is_active').optional().isBoolean()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { name, content, is_active = true } = req.body;

    const result = await new Promise((resolve, reject) => {
      db.run(`
        INSERT INTO user_knowledge_base (user_id, name, content, is_active)
        VALUES (?, ?, ?, ?)
      `, [req.user.id, name, content, is_active ? 1 : 0], function(err) {
        if (err) reject(err);
        else resolve(this.lastID);
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'CREATE_KNOWLEDGE_BASE',
      resourceType: 'knowledge_base',
      resourceId: result,
      details: `Created knowledge base: ${name}`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.status(201).json({
      message: 'Knowledge base entry created successfully',
      knowledgeId: result
    });
  } catch (error) {
    console.error('[User] Error creating knowledge base entry:', error);
    res.status(500).json({ error: 'Failed to create knowledge base entry' });
  }
});

router.put('/knowledge-base/:id', [
  body('name').optional().trim().isLength({ min: 1 }),
  body('content').optional().trim().isLength({ min: 1 }),
  body('is_active').optional().isBoolean()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { name, content, is_active } = req.body;

    // Verify knowledge base belongs to user
    const knowledge = await new Promise((resolve, reject) => {
      db.get('SELECT id FROM user_knowledge_base WHERE id = ? AND user_id = ?',
        [req.params.id, req.user.id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!knowledge) {
      return res.status(404).json({ error: 'Knowledge base entry not found' });
    }

    // Build dynamic update query
    const updates = [];
    const values = [];

    if (name !== undefined) {
      updates.push('name = ?');
      values.push(name);
    }
    if (content !== undefined) {
      updates.push('content = ?');
      values.push(content);
    }
    if (is_active !== undefined) {
      updates.push('is_active = ?');
      values.push(is_active ? 1 : 0);
    }

    updates.push('updated_at = CURRENT_TIMESTAMP');
    values.push(req.params.id);

    if (updates.length > 1) { // More than just updated_at
      await new Promise((resolve, reject) => {
        db.run(`
          UPDATE user_knowledge_base 
          SET ${updates.join(', ')}
          WHERE id = ?
        `, values, (err) => {
          if (err) reject(err);
          else resolve();
        });
      });

      await AuditLogger.log({
        userId: req.user.id,
        action: 'UPDATE_KNOWLEDGE_BASE',
        resourceType: 'knowledge_base',
        resourceId: parseInt(req.params.id),
        details: `Updated knowledge base: ${name || 'entry'}`,
        ip: req.ip,
        userAgent: req.get('user-agent')
      });
    }

    res.json({ message: 'Knowledge base entry updated successfully' });
  } catch (error) {
    console.error('[User] Error updating knowledge base entry:', error);
    res.status(500).json({ error: 'Failed to update knowledge base entry' });
  }
});

router.delete('/knowledge-base/:id', async (req, res) => {
  try {
    // Verify knowledge base belongs to user
    const knowledge = await new Promise((resolve, reject) => {
      db.get('SELECT id, name FROM user_knowledge_base WHERE id = ? AND user_id = ?',
        [req.params.id, req.user.id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!knowledge) {
      return res.status(404).json({ error: 'Knowledge base entry not found' });
    }

    await new Promise((resolve, reject) => {
      db.run('DELETE FROM user_knowledge_base WHERE id = ?', [req.params.id], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'DELETE_KNOWLEDGE_BASE',
      resourceType: 'knowledge_base',
      resourceId: parseInt(req.params.id),
      details: `Deleted knowledge base: ${knowledge.name}`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({ message: 'Knowledge base entry deleted successfully' });
  } catch (error) {
    console.error('[User] Error deleting knowledge base entry:', error);
    res.status(500).json({ error: 'Failed to delete knowledge base entry' });
  }
});

// ==================== USAGE STATISTICS ====================

router.get('/usage/stats', async (req, res) => {
  try {
    const stats = await new Promise((resolve, reject) => {
      db.get(`
        SELECT 
          COUNT(*) as total_requests,
          SUM(total_tokens) as total_tokens,
          AVG(request_duration_ms) as avg_duration,
          (SELECT COUNT(*) FROM usage_logs WHERE user_id = ? AND created_at >= datetime('now', '-24 hours')) as requests_24h,
          (SELECT COUNT(*) FROM usage_logs WHERE user_id = ? AND created_at >= datetime('now', '-7 days')) as requests_7d
        FROM usage_logs
        WHERE user_id = ?
      `, [req.user.id, req.user.id, req.user.id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    res.json({ stats });
  } catch (error) {
    console.error('[User] Error getting usage stats:', error);
    res.status(500).json({ error: 'Failed to get usage statistics' });
  }
});

router.get('/usage/history', async (req, res) => {
  try {
    const { limit = 100, offset = 0 } = req.query;
    
    const logs = await new Promise((resolve, reject) => {
      db.all(`
        SELECT 
          id, model_alias, total_tokens, request_duration_ms,
          status_code, error_message, created_at
        FROM usage_logs
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT ? OFFSET ?
      `, [req.user.id, parseInt(limit), parseInt(offset)], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ logs });
  } catch (error) {
    console.error('[User] Error getting usage history:', error);
    res.status(500).json({ error: 'Failed to get usage history' });
  }
});

// ==================== TWO-FACTOR AUTHENTICATION ====================

router.post('/2fa/enable', async (req, res) => {
  try {
    const secret = TwoFactorAuth.generateSecret(req.user.username);
    
    // Save secret to database temporarily
    await new Promise((resolve, reject) => {
      db.run(`
        UPDATE users 
        SET two_factor_secret = ?
        WHERE id = ?
      `, [secret.base32, req.user.id], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    res.json({
      secret: secret.base32,
      qrCode: secret.otpauth_url
    });
  } catch (error) {
    console.error('[User] Error enabling 2FA:', error);
    res.status(500).json({ error: 'Failed to enable 2FA' });
  }
});

router.post('/2fa/verify', [
  body('token').isLength({ min: 6, max: 6 })
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { token } = req.body;

    const user = await new Promise((resolve, reject) => {
      db.get('SELECT two_factor_secret FROM users WHERE id = ?', [req.user.id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!user.two_factor_secret) {
      return res.status(400).json({ error: '2FA not initiated' });
    }

    const verified = TwoFactorAuth.verifyToken(user.two_factor_secret, token);
    
    if (!verified) {
      return res.status(400).json({ error: 'Invalid token' });
    }

    // Enable 2FA
    await new Promise((resolve, reject) => {
      db.run(`
        UPDATE users 
        SET two_factor_enabled = 1
        WHERE id = ?
      `, [req.user.id], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'ENABLE_2FA',
      resourceType: 'user',
      resourceId: req.user.id,
      details: 'User enabled 2FA',
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({ message: '2FA enabled successfully' });
  } catch (error) {
    console.error('[User] Error verifying 2FA:', error);
    res.status(500).json({ error: 'Failed to verify 2FA' });
  }
});

router.post('/2fa/disable', [
  body('token').isLength({ min: 6, max: 6 })
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { token } = req.body;

    const user = await new Promise((resolve, reject) => {
      db.get('SELECT two_factor_secret FROM users WHERE id = ?', [req.user.id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    const verified = TwoFactorAuth.verifyToken(user.two_factor_secret, token);
    
    if (!verified) {
      return res.status(400).json({ error: 'Invalid token' });
    }

    // Disable 2FA
    await new Promise((resolve, reject) => {
      db.run(`
        UPDATE users 
        SET two_factor_enabled = 0, two_factor_secret = NULL
        WHERE id = ?
      `, [req.user.id], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'DISABLE_2FA',
      resourceType: 'user',
      resourceId: req.user.id,
      details: 'User disabled 2FA',
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({ message: '2FA disabled successfully' });
  } catch (error) {
    console.error('[User] Error disabling 2FA:', error);
    res.status(500).json({ error: 'Failed to disable 2FA' });
  }
});

module.exports = router;
