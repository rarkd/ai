const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const { authenticate, requireAdmin } = require('../middleware/auth.middleware');
const db = require('../database/db');
const AuditLogger = require('../utils/audit-logger');
const QuotaManager = require('../middleware/quota.middleware');
const WebhookManager = require('../utils/webhook-manager');
const EmailManager = require('../utils/email-manager');
const TwoFactorAuth = require('../utils/two-factor-auth');

// Apply authentication and admin requirement to all routes
router.use(authenticate);
router.use(requireAdmin);

// ==================== DASHBOARD STATS ====================

router.get('/stats', async (req, res) => {
  try {
    const stats = await new Promise((resolve, reject) => {
      db.get(`
        SELECT 
          (SELECT COUNT(*) FROM users WHERE role = 'user') as total_users,
          (SELECT COUNT(*) FROM groups) as total_groups,
          (SELECT COUNT(*) FROM users WHERE is_banned = 1) as banned_users,
          (SELECT COUNT(DISTINCT user_id) FROM usage_logs WHERE created_at >= datetime('now', '-7 days')) as active_users_7d,
          (SELECT COUNT(*) FROM usage_logs WHERE created_at >= datetime('now', '-24 hours')) as requests_24h,
          (SELECT SUM(total_tokens) FROM usage_logs WHERE created_at >= datetime('now', '-24 hours')) as tokens_24h
      `, (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    // Get quota summary
    const quotaSummary = await QuotaManager.getAllUsersQuotaSummary();

    // Get recent activity
    const recentActivity = await AuditLogger.getLogs({}, 10, 0);

    res.json({
      ...stats,
      quotaSummary: quotaSummary.slice(0, 5), // Top 5 users by usage
      recentActivity
    });
  } catch (error) {
    console.error('[Admin] Error getting stats:', error);
    res.status(500).json({ error: 'Failed to get statistics' });
  }
});

// ==================== USER MANAGEMENT ====================

router.get('/users', async (req, res) => {
  try {
    const users = await new Promise((resolve, reject) => {
      db.all(`
        SELECT 
          u.id, u.username, u.email, u.role, u.group_id, u.is_banned,
          u.two_factor_enabled, u.created_at, u.last_login,
          g.name as group_name
        FROM users u
        LEFT JOIN groups g ON u.group_id = g.id
        ORDER BY u.created_at DESC
      `, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ users });
  } catch (error) {
    console.error('[Admin] Error getting users:', error);
    res.status(500).json({ error: 'Failed to get users' });
  }
});

router.get('/users/:id', async (req, res) => {
  try {
    const user = await new Promise((resolve, reject) => {
      db.get(`
        SELECT 
          u.id, u.username, u.email, u.role, u.group_id, u.is_banned,
          u.two_factor_enabled, u.created_at, u.last_login,
          g.name as group_name
        FROM users u
        LEFT JOIN groups g ON u.group_id = g.id
        WHERE u.id = ?
      `, [req.params.id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Get user's domains
    const domains = await new Promise((resolve, reject) => {
      db.all('SELECT id, domain, created_at FROM user_domains WHERE user_id = ?', 
        [req.params.id], (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
    });

    // Get user's API keys
    const apiKeys = await new Promise((resolve, reject) => {
      db.all('SELECT id, key_prefix, name, created_at, last_used, is_active FROM api_keys WHERE user_id = ?', 
        [req.params.id], (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
    });

    // Get quota info
    const quota = await QuotaManager.checkQuota(parseInt(req.params.id));

    // Get recent activity
    const activity = await AuditLogger.getUserActivity(parseInt(req.params.id), 30);

    res.json({
      user,
      domains,
      apiKeys,
      quota,
      activity
    });
  } catch (error) {
    console.error('[Admin] Error getting user:', error);
    res.status(500).json({ error: 'Failed to get user details' });
  }
});

router.post('/users', [
  body('username').trim().isLength({ min: 3 }).withMessage('Username must be at least 3 characters'),
  body('email').isEmail().withMessage('Invalid email'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
  body('role').isIn(['admin', 'user']).withMessage('Invalid role')
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { username, email, password, role, group_id } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);

    const userId = await new Promise((resolve, reject) => {
      db.run(`
        INSERT INTO users (username, email, password, role, group_id)
        VALUES (?, ?, ?, ?, ?)
      `, [username, email, hashedPassword, role, group_id], function(err) {
        if (err) reject(err);
        else resolve(this.lastID);
      });
    });

    // Log audit
    await AuditLogger.logUserCreate(req.user.id, userId, { username, email, role }, req);

    // Send welcome email
    await EmailManager.sendWelcomeEmail(userId, email, username);

    res.status(201).json({
      message: 'User created successfully',
      userId
    });
  } catch (error) {
    console.error('[Admin] Error creating user:', error);
    res.status(500).json({ error: 'Failed to create user' });
  }
});

router.put('/users/:id', async (req, res) => {
  try {
    const { username, email, role, group_id } = req.body;
    const updates = {};

    if (username) updates.username = username;
    if (email) updates.email = email;
    if (role) updates.role = role;
    if (group_id !== undefined) updates.group_id = group_id;

    const fields = Object.keys(updates).map(key => `${key} = ?`).join(', ');
    const values = [...Object.values(updates), req.params.id];

    await new Promise((resolve, reject) => {
      db.run(`UPDATE users SET ${fields}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, 
        values, (err) => {
          if (err) reject(err);
          else resolve();
        });
    });

    // Log audit
    await AuditLogger.logUserUpdate(req.user.id, parseInt(req.params.id), updates, req);

    res.json({ message: 'User updated successfully' });
  } catch (error) {
    console.error('[Admin] Error updating user:', error);
    res.status(500).json({ error: 'Failed to update user' });
  }
});

router.delete('/users/:id', async (req, res) => {
  try {
    // Can't delete self
    if (parseInt(req.params.id) === req.user.id) {
      return res.status(400).json({ error: 'Cannot delete your own account' });
    }

    await new Promise((resolve, reject) => {
      db.run('DELETE FROM users WHERE id = ?', [req.params.id], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    // Log audit
    await AuditLogger.logUserDelete(req.user.id, parseInt(req.params.id), req);

    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    console.error('[Admin] Error deleting user:', error);
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

router.patch('/users/:id/ban', async (req, res) => {
  try {
    const { is_banned } = req.body;

    await new Promise((resolve, reject) => {
      db.run('UPDATE users SET is_banned = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', 
        [is_banned ? 1 : 0, req.params.id], (err) => {
          if (err) reject(err);
          else resolve();
        });
    });

    // Log audit
    await AuditLogger.logUserBan(req.user.id, parseInt(req.params.id), is_banned, req);

    res.json({ message: `User ${is_banned ? 'banned' : 'unbanned'} successfully` });
  } catch (error) {
    console.error('[Admin] Error banning user:', error);
    res.status(500).json({ error: 'Failed to update ban status' });
  }
});

router.post('/users/:id/reset-password', async (req, res) => {
  try {
    const newPassword = Math.random().toString(36).slice(-8);
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    await new Promise((resolve, reject) => {
      db.run('UPDATE users SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', 
        [hashedPassword, req.params.id], (err) => {
          if (err) reject(err);
          else resolve();
        });
    });

    // Get user email
    const user = await new Promise((resolve, reject) => {
      db.get('SELECT username, email FROM users WHERE id = ?', [req.params.id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    // Send email with new password
    await EmailManager.sendPasswordResetEmail(parseInt(req.params.id), user.email, user.username, newPassword);

    // Log audit
    await AuditLogger.logPasswordChange(parseInt(req.params.id), true, req);

    res.json({
      message: 'Password reset successfully',
      newPassword // In production, only send via email
    });
  } catch (error) {
    console.error('[Admin] Error resetting password:', error);
    res.status(500).json({ error: 'Failed to reset password' });
  }
});

// ==================== GROUP MANAGEMENT ====================

router.get('/groups', async (req, res) => {
  try {
    const groups = await new Promise((resolve, reject) => {
      db.all(`
        SELECT 
          g.*,
          COUNT(DISTINCT u.id) as user_count,
          COUNT(DISTINCT gm.id) as model_count
        FROM groups g
        LEFT JOIN users u ON g.id = u.group_id
        LEFT JOIN group_models gm ON g.id = gm.group_id
        GROUP BY g.id
        ORDER BY g.created_at DESC
      `, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ groups });
  } catch (error) {
    console.error('[Admin] Error getting groups:', error);
    res.status(500).json({ error: 'Failed to get groups' });
  }
});

router.get('/groups/:id', async (req, res) => {
  try {
    const group = await new Promise((resolve, reject) => {
      db.get('SELECT * FROM groups WHERE id = ?', [req.params.id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!group) {
      return res.status(404).json({ error: 'Group not found' });
    }

    const models = await new Promise((resolve, reject) => {
      db.all('SELECT * FROM group_models WHERE group_id = ?', [req.params.id], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    const users = await new Promise((resolve, reject) => {
      db.all('SELECT id, username, email FROM users WHERE group_id = ?', [req.params.id], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ group, models, users });
  } catch (error) {
    console.error('[Admin] Error getting group:', error);
    res.status(500).json({ error: 'Failed to get group details' });
  }
});

router.post('/groups', [
  body('name').trim().isLength({ min: 2 }).withMessage('Name must be at least 2 characters'),
  body('description').optional()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { name, description, max_requests_per_minute, max_requests_per_hour, max_requests_per_day, monthly_quota } = req.body;

    const groupId = await new Promise((resolve, reject) => {
      db.run(`
        INSERT INTO groups (name, description, max_requests_per_minute, max_requests_per_hour, max_requests_per_day, monthly_quota)
        VALUES (?, ?, ?, ?, ?, ?)
      `, [name, description, max_requests_per_minute || 60, max_requests_per_hour || 1000, max_requests_per_day || 10000, monthly_quota || 100000], 
      function(err) {
        if (err) reject(err);
        else resolve(this.lastID);
      });
    });

    // Log audit
    await AuditLogger.logGroupCreate(req.user.id, groupId, { name }, req);

    res.status(201).json({
      message: 'Group created successfully',
      groupId
    });
  } catch (error) {
    console.error('[Admin] Error creating group:', error);
    res.status(500).json({ error: 'Failed to create group' });
  }
});

router.put('/groups/:id', async (req, res) => {
  try {
    const { name, description, max_requests_per_minute, max_requests_per_hour, max_requests_per_day, monthly_quota } = req.body;
    const updates = {};

    if (name) updates.name = name;
    if (description !== undefined) updates.description = description;
    if (max_requests_per_minute) updates.max_requests_per_minute = max_requests_per_minute;
    if (max_requests_per_hour) updates.max_requests_per_hour = max_requests_per_hour;
    if (max_requests_per_day) updates.max_requests_per_day = max_requests_per_day;
    if (monthly_quota) updates.monthly_quota = monthly_quota;

    const fields = Object.keys(updates).map(key => `${key} = ?`).join(', ');
    const values = [...Object.values(updates), req.params.id];

    await new Promise((resolve, reject) => {
      db.run(`UPDATE groups SET ${fields}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, 
        values, (err) => {
          if (err) reject(err);
          else resolve();
        });
    });

    // Log audit
    await AuditLogger.logGroupUpdate(req.user.id, parseInt(req.params.id), updates, req);

    res.json({ message: 'Group updated successfully' });
  } catch (error) {
    console.error('[Admin] Error updating group:', error);
    res.status(500).json({ error: 'Failed to update group' });
  }
});

router.delete('/groups/:id', async (req, res) => {
  try {
    await new Promise((resolve, reject) => {
      db.run('DELETE FROM groups WHERE id = ?', [req.params.id], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    // Log audit
    await AuditLogger.logGroupDelete(req.user.id, parseInt(req.params.id), req);

    res.json({ message: 'Group deleted successfully' });
  } catch (error) {
    console.error('[Admin] Error deleting group:', error);
    res.status(500).json({ error: 'Failed to delete group' });
  }
});

router.post('/groups/:id/models', async (req, res) => {
  try {
    const { model_alias, model_name } = req.body;

    await new Promise((resolve, reject) => {
      db.run(`
        INSERT INTO group_models (group_id, model_alias, model_name)
        VALUES (?, ?, ?)
      `, [req.params.id, model_alias, model_name], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    // Log audit
    await AuditLogger.logModelAssign(req.user.id, parseInt(req.params.id), model_alias, req);

    res.json({ message: 'Model assigned to group successfully' });
  } catch (error) {
    console.error('[Admin] Error assigning model:', error);
    res.status(500).json({ error: 'Failed to assign model' });
  }
});

router.delete('/groups/:groupId/models/:modelId', async (req, res) => {
  try {
    await new Promise((resolve, reject) => {
      db.run('DELETE FROM group_models WHERE id = ? AND group_id = ?', 
        [req.params.modelId, req.params.groupId], (err) => {
          if (err) reject(err);
          else resolve();
        });
    });

    res.json({ message: 'Model removed from group successfully' });
  } catch (error) {
    console.error('[Admin] Error removing model:', error);
    res.status(500).json({ error: 'Failed to remove model' });
  }
});

// ==================== QUOTA MANAGEMENT ====================

router.get('/quota/summary', async (req, res) => {
  try {
    const summary = await QuotaManager.getAllUsersQuotaSummary();
    res.json({ summary });
  } catch (error) {
    console.error('[Admin] Error getting quota summary:', error);
    res.status(500).json({ error: 'Failed to get quota summary' });
  }
});

router.post('/users/:id/quota/reset', async (req, res) => {
  try {
    await QuotaManager.resetQuota(parseInt(req.params.id));
    
    res.json({ message: 'Quota reset successfully' });
  } catch (error) {
    console.error('[Admin] Error resetting quota:', error);
    res.status(500).json({ error: 'Failed to reset quota' });
  }
});

// ==================== AUDIT LOGS ====================

router.get('/audit-logs', async (req, res) => {
  try {
    const { userId, action, resourceType, dateFrom, dateTo, limit = 100, offset = 0 } = req.query;

    const filters = {};
    if (userId) filters.userId = parseInt(userId);
    if (action) filters.action = action;
    if (resourceType) filters.resourceType = resourceType;
    if (dateFrom) filters.dateFrom = dateFrom;
    if (dateTo) filters.dateTo = dateTo;

    const logs = await AuditLogger.getLogs(filters, parseInt(limit), parseInt(offset));
    const total = await AuditLogger.getLogCount(filters);

    res.json({
      logs,
      total,
      limit: parseInt(limit),
      offset: parseInt(offset)
    });
  } catch (error) {
    console.error('[Admin] Error getting audit logs:', error);
    res.status(500).json({ error: 'Failed to get audit logs' });
  }
});

router.get('/audit-logs/stats', async (req, res) => {
  try {
    const { days = 7 } = req.query;
    const stats = await AuditLogger.getStats(parseInt(days));

    res.json({ stats });
  } catch (error) {
    console.error('[Admin] Error getting audit stats:', error);
    res.status(500).json({ error: 'Failed to get audit statistics' });
  }
});

router.get('/audit-logs/export', async (req, res) => {
  try {
    const { userId, action, resourceType, dateFrom, dateTo } = req.query;

    const filters = {};
    if (userId) filters.userId = parseInt(userId);
    if (action) filters.action = action;
    if (resourceType) filters.resourceType = resourceType;
    if (dateFrom) filters.dateFrom = dateFrom;
    if (dateTo) filters.dateTo = dateTo;

    const data = await AuditLogger.exportToJson(filters);

    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename=audit-logs-${Date.now()}.json`);
    res.json(data);
  } catch (error) {
    console.error('[Admin] Error exporting audit logs:', error);
    res.status(500).json({ error: 'Failed to export audit logs' });
  }
});

// ==================== WEBHOOKS (ADMIN VIEW) ====================

router.get('/webhooks', async (req, res) => {
  try {
    const webhooks = await new Promise((resolve, reject) => {
      db.all(`
        SELECT 
          w.*,
          u.username,
          u.email
        FROM webhooks w
        LEFT JOIN users u ON w.user_id = u.id
        ORDER BY w.created_at DESC
      `, (err, rows) => {
        if (err) reject(err);
        else resolve(rows.map(row => ({
          ...row,
          events: JSON.parse(row.events)
        })));
      });
    });

    res.json({ webhooks });
  } catch (error) {
    console.error('[Admin] Error getting webhooks:', error);
    res.status(500).json({ error: 'Failed to get webhooks' });
  }
});

// ==================== SYSTEM SETTINGS ====================

router.get('/settings', async (req, res) => {
  try {
    const settings = await new Promise((resolve, reject) => {
      db.all('SELECT * FROM system_settings ORDER BY key', (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ settings });
  } catch (error) {
    console.error('[Admin] Error getting settings:', error);
    res.status(500).json({ error: 'Failed to get settings' });
  }
});

router.put('/settings/:key', async (req, res) => {
  try {
    const { value } = req.body;

    await new Promise((resolve, reject) => {
      db.run(`
        UPDATE system_settings
        SET value = ?, updated_at = CURRENT_TIMESTAMP
        WHERE key = ?
      `, [value, req.params.key], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    res.json({ message: 'Setting updated successfully' });
  } catch (error) {
    console.error('[Admin] Error updating setting:', error);
    res.status(500).json({ error: 'Failed to update setting' });
  }
});

module.exports = router;
