const express = require('express');
const router = express.Router();
const { authenticate } = require('../middleware/auth.middleware');
const RateLimiter = require('../middleware/ratelimit.middleware');
const QuotaManager = require('../middleware/quota.middleware');
const WebhookManager = require('../utils/webhook-manager');
const TwoFactorAuth = require('../utils/two-factor-auth');
const AuditLogger = require('../utils/audit-logger');
const db = require('../database/db');

// Apply authentication
router.use(authenticate);

// ==================== AVAILABLE MODELS ====================

router.get('/models', async (req, res) => {
  try {
    const models = await new Promise((resolve, reject) => {
      db.all(`
        SELECT DISTINCT gm.model_alias, gm.model_name
        FROM group_models gm
        WHERE gm.group_id = ?
      `, [req.user.group_id], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ models });
  } catch (error) {
    console.error('[User] Error getting models:', error);
    res.status(500).json({ error: 'Failed to get models' });
  }
});

// ==================== GROUP INFO ====================

router.get('/group', async (req, res) => {
  try {
    const group = await new Promise((resolve, reject) => {
      db.get(`
        SELECT g.*, COUNT(DISTINCT gm.id) as model_count
        FROM groups g
        LEFT JOIN group_models gm ON g.id = gm.group_id
        WHERE g.id = ?
        GROUP BY g.id
      `, [req.user.group_id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    res.json({ group });
  } catch (error) {
    console.error('[User] Error getting group:', error);
    res.status(500).json({ error: 'Failed to get group info' });
  }
});

// ==================== DOMAIN MANAGEMENT ====================

router.get('/domains', async (req, res) => {
  try {
    const domains = await new Promise((resolve, reject) => {
      db.all('SELECT * FROM user_domains WHERE user_id = ? ORDER BY created_at DESC', 
        [req.user.id], (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
    });

    res.json({ domains });
  } catch (error) {
    console.error('[User] Error getting domains:', error);
    res.status(500).json({ error: 'Failed to get domains' });
  }
});

router.post('/domains', async (req, res) => {
  try {
    const { domain } = req.body;

    if (!domain) {
      return res.status(400).json({ error: 'Domain is required' });
    }

    await new Promise((resolve, reject) => {
      db.run('INSERT INTO user_domains (user_id, domain) VALUES (?, ?)', 
        [req.user.id, domain], (err) => {
          if (err) reject(err);
          else resolve();
        });
    });

    await AuditLogger.logDomainAdd(req.user.id, domain, req);

    res.status(201).json({ message: 'Domain added successfully' });
  } catch (error) {
    console.error('[User] Error adding domain:', error);
    res.status(500).json({ error: 'Failed to add domain' });
  }
});

router.delete('/domains/:id', async (req, res) => {
  try {
    const domain = await new Promise((resolve, reject) => {
      db.get('SELECT domain FROM user_domains WHERE id = ? AND user_id = ?', 
        [req.params.id, req.user.id], (err, row) => {
          if (err) reject(err);
          else resolve(row);
        });
    });

    if (!domain) {
      return res.status(404).json({ error: 'Domain not found' });
    }

    await new Promise((resolve, reject) => {
      db.run('DELETE FROM user_domains WHERE id = ? AND user_id = ?', 
        [req.params.id, req.user.id], (err) => {
          if (err) reject(err);
          else resolve();
        });
    });

    await AuditLogger.logDomainRemove(req.user.id, parseInt(req.params.id), domain.domain, req);

    res.json({ message: 'Domain deleted successfully' });
  } catch (error) {
    console.error('[User] Error deleting domain:', error);
    res.status(500).json({ error: 'Failed to delete domain' });
  }
});

// ==================== API KEYS ====================

router.get('/api-keys', async (req, res) => {
  try {
    const keys = await new Promise((resolve, reject) => {
      db.all(`
        SELECT id, key_prefix, name, created_at, last_used, is_active
        FROM api_keys
        WHERE user_id = ?
        ORDER BY created_at DESC
      `, [req.user.id], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ apiKeys: keys });
  } catch (error) {
    console.error('[User] Error getting API keys:', error);
    res.status(500).json({ error: 'Failed to get API keys' });
  }
});

router.post('/api-keys', async (req, res) => {
  try {
    const { name } = req.body;
    const bcrypt = require('bcryptjs');
    const crypto = require('crypto');

    const apiKey = 'gw_' + crypto.randomBytes(32).toString('hex');
    const keyHash = await bcrypt.hash(apiKey, 10);
    const keyPrefix = apiKey.substring(0, 10);

    await new Promise((resolve, reject) => {
      db.run(`
        INSERT INTO api_keys (user_id, key_hash, key_prefix, name)
        VALUES (?, ?, ?, ?)
      `, [req.user.id, keyHash, keyPrefix, name], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.logApiKeyCreate(req.user.id, name, req);

    res.status(201).json({
      apiKey,
      warning: 'Save this key securely. It will not be shown again.'
    });
  } catch (error) {
    console.error('[User] Error creating API key:', error);
    res.status(500).json({ error: 'Failed to create API key' });
  }
});

router.delete('/api-keys/:id', async (req, res) => {
  try {
    const key = await new Promise((resolve, reject) => {
      db.get('SELECT name FROM api_keys WHERE id = ? AND user_id = ?', 
        [req.params.id, req.user.id], (err, row) => {
          if (err) reject(err);
          else resolve(row);
        });
    });

    if (!key) {
      return res.status(404).json({ error: 'API key not found' });
    }

    await new Promise((resolve, reject) => {
      db.run('DELETE FROM api_keys WHERE id = ? AND user_id = ?', 
        [req.params.id, req.user.id], (err) => {
          if (err) reject(err);
          else resolve();
        });
    });

    await AuditLogger.logApiKeyDelete(req.user.id, parseInt(req.params.id), key.name, req);

    res.json({ message: 'API key deleted successfully' });
  } catch (error) {
    console.error('[User] Error deleting API key:', error);
    res.status(500).json({ error: 'Failed to delete API key' });
  }
});

// ==================== USAGE STATISTICS ====================

router.get('/usage', async (req, res) => {
  try {
    const { days = 30 } = req.query;
    const dateFrom = new Date();
    dateFrom.setDate(dateFrom.getDate() - parseInt(days));

    const usage = await new Promise((resolve, reject) => {
      db.all(`
        SELECT 
          model_alias,
          COUNT(*) as request_count,
          SUM(total_tokens) as total_tokens,
          DATE(created_at) as date
        FROM usage_logs
        WHERE user_id = ? AND created_at >= ?
        GROUP BY model_alias, DATE(created_at)
        ORDER BY date DESC
      `, [req.user.id, dateFrom.toISOString()], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    const quota = await QuotaManager.checkQuota(req.user.id);

    res.json({ usage, quota });
  } catch (error) {
    console.error('[User] Error getting usage:', error);
    res.status(500).json({ error: 'Failed to get usage statistics' });
  }
});

// ==================== QUOTA INFO ====================

router.get('/quota', async (req, res) => {
  try {
    const quota = await QuotaManager.checkQuota(req.user.id);
    const history = await QuotaManager.getQuotaStats(req.user.id, 6);

    res.json({ current: quota, history });
  } catch (error) {
    console.error('[User] Error getting quota:', error);
    res.status(500).json({ error: 'Failed to get quota information' });
  }
});

// ==================== WEBHOOKS ====================

router.get('/webhooks', async (req, res) => {
  try {
    const webhooks = await WebhookManager.getUserWebhooks(req.user.id);
    res.json({ webhooks });
  } catch (error) {
    console.error('[User] Error getting webhooks:', error);
    res.status(500).json({ error: 'Failed to get webhooks' });
  }
});

router.post('/webhooks', async (req, res) => {
  try {
    const { name, url, events } = req.body;

    if (!name || !url || !events || !Array.isArray(events)) {
      return res.status(400).json({ error: 'Name, URL, and events array are required' });
    }

    const webhook = await WebhookManager.create(req.user.id, name, url, events);

    res.status(201).json({
      message: 'Webhook created successfully',
      webhook
    });
  } catch (error) {
    console.error('[User] Error creating webhook:', error);
    res.status(500).json({ error: 'Failed to create webhook' });
  }
});

router.put('/webhooks/:id', async (req, res) => {
  try {
    const updates = req.body;
    const success = await WebhookManager.update(parseInt(req.params.id), req.user.id, updates);

    if (!success) {
      return res.status(404).json({ error: 'Webhook not found' });
    }

    res.json({ message: 'Webhook updated successfully' });
  } catch (error) {
    console.error('[User] Error updating webhook:', error);
    res.status(500).json({ error: 'Failed to update webhook' });
  }
});

router.delete('/webhooks/:id', async (req, res) => {
  try {
    const success = await WebhookManager.delete(parseInt(req.params.id), req.user.id);

    if (!success) {
      return res.status(404).json({ error: 'Webhook not found' });
    }

    res.json({ message: 'Webhook deleted successfully' });
  } catch (error) {
    console.error('[User] Error deleting webhook:', error);
    res.status(500).json({ error: 'Failed to delete webhook' });
  }
});

router.post('/webhooks/:id/test', async (req, res) => {
  try {
    const result = await WebhookManager.test(parseInt(req.params.id), req.user.id);
    res.json(result);
  } catch (error) {
    console.error('[User] Error testing webhook:', error);
    res.status(500).json({ error: error.message });
  }
});

router.get('/webhooks/:id/logs', async (req, res) => {
  try {
    const { limit = 50 } = req.query;
    
    // Verify webhook belongs to user
    const webhook = await WebhookManager.getWebhook(parseInt(req.params.id), req.user.id);
    if (!webhook) {
      return res.status(404).json({ error: 'Webhook not found' });
    }

    const logs = await WebhookManager.getLogs(parseInt(req.params.id), parseInt(limit));
    res.json({ logs });
  } catch (error) {
    console.error('[User] Error getting webhook logs:', error);
    res.status(500).json({ error: 'Failed to get webhook logs' });
  }
});

router.get('/webhooks/events/available', (req, res) => {
  res.json({ events: Object.values(WebhookManager.EVENTS) });
});

// ==================== TWO-FACTOR AUTHENTICATION ====================

router.get('/2fa/status', async (req, res) => {
  try {
    const status = await TwoFactorAuth.getStatus(req.user.id);
    res.json(status);
  } catch (error) {
    console.error('[User] Error getting 2FA status:', error);
    res.status(500).json({ error: 'Failed to get 2FA status' });
  }
});

router.post('/2fa/setup', async (req, res) => {
  try {
    const { secret, otpauth_url } = await TwoFactorAuth.generateSecret(req.user.id, req.user.email);
    const qrCode = await TwoFactorAuth.generateQRCode(otpauth_url);

    res.json({
      secret,
      qrCode,
      message: 'Scan the QR code with your authenticator app, then verify with a code to enable 2FA'
    });
  } catch (error) {
    console.error('[User] Error setting up 2FA:', error);
    res.status(500).json({ error: 'Failed to setup 2FA' });
  }
});

router.post('/2fa/enable', async (req, res) => {
  try {
    const { secret, token } = req.body;

    if (!secret || !token) {
      return res.status(400).json({ error: 'Secret and token are required' });
    }

    const result = await TwoFactorAuth.enable(req.user.id, secret, token, req);

    if (!result.success) {
      return res.status(400).json({ error: result.message });
    }

    res.json(result);
  } catch (error) {
    console.error('[User] Error enabling 2FA:', error);
    res.status(500).json({ error: 'Failed to enable 2FA' });
  }
});

router.post('/2fa/disable', async (req, res) => {
  try {
    const { token } = req.body;

    if (!token) {
      return res.status(400).json({ error: 'Token is required' });
    }

    const result = await TwoFactorAuth.disable(req.user.id, token, req);

    if (!result.success) {
      return res.status(400).json({ error: result.message });
    }

    res.json(result);
  } catch (error) {
    console.error('[User] Error disabling 2FA:', error);
    res.status(500).json({ error: 'Failed to disable 2FA' });
  }
});

// ==================== PROFILE ====================

router.get('/profile', async (req, res) => {
  try {
    const user = await new Promise((resolve, reject) => {
      db.get(`
        SELECT 
          u.id, u.username, u.email, u.role, u.group_id,
          u.two_factor_enabled, u.created_at, u.last_login,
          g.name as group_name
        FROM users u
        LEFT JOIN groups g ON u.group_id = g.id
        WHERE u.id = ?
      `, [req.user.id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    res.json({ user });
  } catch (error) {
    console.error('[User] Error getting profile:', error);
    res.status(500).json({ error: 'Failed to get profile' });
  }
});

// ==================== ACTIVITY LOG ====================

router.get('/activity', async (req, res) => {
  try {
    const { days = 30 } = req.query;
    const activity = await AuditLogger.getUserActivity(req.user.id, parseInt(days));

    res.json({ activity });
  } catch (error) {
    console.error('[User] Error getting activity:', error);
    res.status(500).json({ error: 'Failed to get activity log' });
  }
});

module.exports = router;
