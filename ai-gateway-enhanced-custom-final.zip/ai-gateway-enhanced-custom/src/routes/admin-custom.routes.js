const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const { authenticate, requireAdmin } = require('../middleware/auth.middleware');
const db = require('../database/db');
const AuditLogger = require('../utils/audit-logger');
const WebhookManager = require('../utils/webhook-manager');
const EmailManager = require('../utils/email-manager');
const TwoFactorAuth = require('../utils/two-factor-auth');

// Apply authentication and admin requirement to all routes
router.use(authenticate);
router.use(requireAdmin);

// ==================== DASHBOARD STATS ====================

router.get('/stats', async (req, res) => {
  try {
    const stats = await new Promise((resolve, reject) => {
      db.get(`
        SELECT 
          (SELECT COUNT(*) FROM users WHERE role = 'user') as total_users,
          (SELECT COUNT(*) FROM groups) as total_groups,
          (SELECT COUNT(*) FROM users WHERE is_banned = 1) as banned_users,
          (SELECT COUNT(DISTINCT user_id) FROM usage_logs WHERE created_at >= datetime('now', '-7 days')) as active_users_7d,
          (SELECT COUNT(*) FROM usage_logs WHERE created_at >= datetime('now', '-24 hours')) as requests_24h,
          (SELECT SUM(total_tokens) FROM usage_logs WHERE created_at >= datetime('now', '-24 hours')) as tokens_24h
      `, (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    // Get recent activity
    const recentActivity = await AuditLogger.getLogs({}, 10, 0);

    res.json({
      ...stats,
      recentActivity
    });
  } catch (error) {
    console.error('[Admin] Error getting stats:', error);
    res.status(500).json({ error: 'Failed to get statistics' });
  }
});

// ==================== USER MANAGEMENT ====================

router.get('/users', async (req, res) => {
  try {
    const users = await new Promise((resolve, reject) => {
      db.all(`
        SELECT 
          u.id, u.username, u.email, u.role, u.group_id, u.is_banned,
          u.two_factor_enabled, u.created_at, u.last_login,
          g.name as group_name
        FROM users u
        LEFT JOIN groups g ON u.group_id = g.id
        ORDER BY u.created_at DESC
      `, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ users });
  } catch (error) {
    console.error('[Admin] Error getting users:', error);
    res.status(500).json({ error: 'Failed to get users' });
  }
});

router.get('/users/:id', async (req, res) => {
  try {
    const user = await new Promise((resolve, reject) => {
      db.get(`
        SELECT 
          u.id, u.username, u.email, u.role, u.group_id, u.is_banned,
          u.two_factor_enabled, u.created_at, u.last_login,
          g.name as group_name
        FROM users u
        LEFT JOIN groups g ON u.group_id = g.id
        WHERE u.id = ?
      `, [req.params.id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Get user's domains
    const domains = await new Promise((resolve, reject) => {
      db.all('SELECT * FROM user_domains WHERE user_id = ?', [req.params.id], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    // Get user's API keys
    const apiKeys = await new Promise((resolve, reject) => {
      db.all(`
        SELECT id, key_prefix, name, expires_at, created_at, last_used, is_active
        FROM api_keys WHERE user_id = ?
      `, [req.params.id], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    // Get user's knowledge base
    const knowledgeBase = await new Promise((resolve, reject) => {
      db.all(`
        SELECT id, name, content, is_active, created_at, updated_at
        FROM user_knowledge_base WHERE user_id = ?
      `, [req.params.id], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ 
      user,
      domains,
      apiKeys,
      knowledgeBase
    });
  } catch (error) {
    console.error('[Admin] Error getting user:', error);
    res.status(500).json({ error: 'Failed to get user details' });
  }
});

router.post('/users', [
  body('username').trim().isLength({ min: 3 }).withMessage('Username must be at least 3 characters'),
  body('email').isEmail().withMessage('Invalid email address'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
  body('group_id').isInt().withMessage('Valid group ID is required')
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { username, email, password, group_id } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);

    const result = await new Promise((resolve, reject) => {
      db.run(`
        INSERT INTO users (username, email, password, group_id)
        VALUES (?, ?, ?, ?)
      `, [username, email, hashedPassword, group_id], function(err) {
        if (err) reject(err);
        else resolve(this.lastID);
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'CREATE_USER',
      resourceType: 'user',
      resourceId: result,
      details: `Created user: ${username}`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.status(201).json({
      message: 'User created successfully',
      userId: result
    });
  } catch (error) {
    console.error('[Admin] Error creating user:', error);
    if (error.code === 'SQLITE_CONSTRAINT') {
      res.status(400).json({ error: 'Username or email already exists' });
    } else {
      res.status(500).json({ error: 'Failed to create user' });
    }
  }
});

router.put('/users/:id', async (req, res) => {
  try {
    const { username, email, group_id, is_banned } = req.body;
    
    await new Promise((resolve, reject) => {
      db.run(`
        UPDATE users 
        SET username = ?, email = ?, group_id = ?, is_banned = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `, [username, email, group_id, is_banned ? 1 : 0, req.params.id], function(err) {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'UPDATE_USER',
      resourceType: 'user',
      resourceId: parseInt(req.params.id),
      details: `Updated user: ${username}`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({ message: 'User updated successfully' });
  } catch (error) {
    console.error('[Admin] Error updating user:', error);
    res.status(500).json({ error: 'Failed to update user' });
  }
});

router.delete('/users/:id', async (req, res) => {
  try {
    const user = await new Promise((resolve, reject) => {
      db.get('SELECT username FROM users WHERE id = ?', [req.params.id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    await new Promise((resolve, reject) => {
      db.run('DELETE FROM users WHERE id = ?', [req.params.id], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'DELETE_USER',
      resourceType: 'user',
      resourceId: parseInt(req.params.id),
      details: `Deleted user: ${user.username}`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    console.error('[Admin] Error deleting user:', error);
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

// ==================== LOGIN AS USER ====================

router.post('/users/:id/impersonate', async (req, res) => {
  try {
    const targetUserId = parseInt(req.params.id);
    
    // Get target user
    const targetUser = await new Promise((resolve, reject) => {
      db.get(`
        SELECT u.*, g.name as group_name
        FROM users u
        LEFT JOIN groups g ON u.group_id = g.id
        WHERE u.id = ? AND u.role = 'user'
      `, [targetUserId], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!targetUser) {
      return res.status(404).json({ error: 'User not found or cannot impersonate admin' });
    }

    // Log impersonation
    await new Promise((resolve, reject) => {
      db.run(`
        INSERT INTO admin_impersonation_logs (admin_id, target_user_id, ip_address, user_agent)
        VALUES (?, ?, ?, ?)
      `, [req.user.id, targetUserId, req.ip, req.get('user-agent')], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'IMPERSONATE_USER',
      resourceType: 'user',
      resourceId: targetUserId,
      details: `Admin ${req.user.username} logged in as ${targetUser.username}`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    // Generate token for target user with special flag
    const token = jwt.sign(
      { 
        id: targetUser.id,
        username: targetUser.username,
        role: targetUser.role,
        group_id: targetUser.group_id,
        impersonated_by: req.user.id,
        impersonated_by_username: req.user.username
      },
      process.env.JWT_SECRET || 'your-secret-key-change-in-production',
      { expiresIn: '4h' } // Shorter expiry for impersonation
    );

    res.json({
      message: 'Impersonation successful',
      token,
      user: {
        id: targetUser.id,
        username: targetUser.username,
        email: targetUser.email,
        role: targetUser.role,
        group_id: targetUser.group_id,
        group_name: targetUser.group_name,
        impersonated_by: req.user.username
      }
    });
  } catch (error) {
    console.error('[Admin] Error impersonating user:', error);
    res.status(500).json({ error: 'Failed to impersonate user' });
  }
});

router.get('/impersonation-logs', async (req, res) => {
  try {
    const logs = await new Promise((resolve, reject) => {
      db.all(`
        SELECT 
          il.*,
          a.username as admin_username,
          u.username as target_username
        FROM admin_impersonation_logs il
        JOIN users a ON il.admin_id = a.id
        JOIN users u ON il.target_user_id = u.id
        ORDER BY il.started_at DESC
        LIMIT 100
      `, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ logs });
  } catch (error) {
    console.error('[Admin] Error getting impersonation logs:', error);
    res.status(500).json({ error: 'Failed to get impersonation logs' });
  }
});

// ==================== GROUP MANAGEMENT ====================

router.get('/groups', async (req, res) => {
  try {
    const groups = await new Promise((resolve, reject) => {
      db.all(`
        SELECT 
          g.*,
          COUNT(DISTINCT u.id) as user_count
        FROM groups g
        LEFT JOIN users u ON g.id = u.group_id
        GROUP BY g.id
        ORDER BY g.name
      `, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    // Get models for each group
    for (let group of groups) {
      const models = await new Promise((resolve, reject) => {
        db.all('SELECT * FROM group_models WHERE group_id = ?', [group.id], (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
      });
      group.models = models;
    }

    res.json({ groups });
  } catch (error) {
    console.error('[Admin] Error getting groups:', error);
    res.status(500).json({ error: 'Failed to get groups' });
  }
});

router.get('/groups/:id', async (req, res) => {
  try {
    const group = await new Promise((resolve, reject) => {
      db.get('SELECT * FROM groups WHERE id = ?', [req.params.id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!group) {
      return res.status(404).json({ error: 'Group not found' });
    }

    const models = await new Promise((resolve, reject) => {
      db.all('SELECT * FROM group_models WHERE group_id = ?', [req.params.id], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    group.models = models;
    res.json({ group });
  } catch (error) {
    console.error('[Admin] Error getting group:', error);
    res.status(500).json({ error: 'Failed to get group' });
  }
});

router.post('/groups', [
  body('name').trim().isLength({ min: 1 }).withMessage('Group name is required'),
  body('description').optional(),
  body('allowed_domains').optional()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { name, description, allowed_domains } = req.body;

    const result = await new Promise((resolve, reject) => {
      db.run(`
        INSERT INTO groups (name, description, allowed_domains)
        VALUES (?, ?, ?)
      `, [name, description, allowed_domains || '*'], function(err) {
        if (err) reject(err);
        else resolve(this.lastID);
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'CREATE_GROUP',
      resourceType: 'group',
      resourceId: result,
      details: `Created group: ${name}`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.status(201).json({
      message: 'Group created successfully',
      groupId: result
    });
  } catch (error) {
    console.error('[Admin] Error creating group:', error);
    if (error.code === 'SQLITE_CONSTRAINT') {
      res.status(400).json({ error: 'Group name already exists' });
    } else {
      res.status(500).json({ error: 'Failed to create group' });
    }
  }
});

router.put('/groups/:id', async (req, res) => {
  try {
    const { name, description, allowed_domains } = req.body;

    await new Promise((resolve, reject) => {
      db.run(`
        UPDATE groups 
        SET name = ?, description = ?, allowed_domains = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `, [name, description, allowed_domains || '*', req.params.id], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'UPDATE_GROUP',
      resourceType: 'group',
      resourceId: parseInt(req.params.id),
      details: `Updated group: ${name}`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({ message: 'Group updated successfully' });
  } catch (error) {
    console.error('[Admin] Error updating group:', error);
    res.status(500).json({ error: 'Failed to update group' });
  }
});

router.delete('/groups/:id', async (req, res) => {
  try {
    // Check if group has users
    const userCount = await new Promise((resolve, reject) => {
      db.get('SELECT COUNT(*) as count FROM users WHERE group_id = ?', [req.params.id], (err, row) => {
        if (err) reject(err);
        else resolve(row.count);
      });
    });

    if (userCount > 0) {
      return res.status(400).json({ error: 'Cannot delete group with active users' });
    }

    await new Promise((resolve, reject) => {
      db.run('DELETE FROM groups WHERE id = ?', [req.params.id], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'DELETE_GROUP',
      resourceType: 'group',
      resourceId: parseInt(req.params.id),
      details: `Deleted group`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({ message: 'Group deleted successfully' });
  } catch (error) {
    console.error('[Admin] Error deleting group:', error);
    res.status(500).json({ error: 'Failed to delete group' });
  }
});

// ==================== MODEL RULES MANAGEMENT (ADMIN ONLY) ====================

router.get('/model-rules', async (req, res) => {
  try {
    const rules = await new Promise((resolve, reject) => {
      db.all('SELECT * FROM model_rules ORDER BY model_alias', (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ rules });
  } catch (error) {
    console.error('[Admin] Error getting model rules:', error);
    res.status(500).json({ error: 'Failed to get model rules' });
  }
});

router.get('/model-rules/:alias', async (req, res) => {
  try {
    const rule = await new Promise((resolve, reject) => {
      db.get('SELECT * FROM model_rules WHERE model_alias = ?', [req.params.alias], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!rule) {
      return res.status(404).json({ error: 'Model rule not found' });
    }

    res.json({ rule });
  } catch (error) {
    console.error('[Admin] Error getting model rule:', error);
    res.status(500).json({ error: 'Failed to get model rule' });
  }
});

router.post('/model-rules', [
  body('model_alias').trim().isLength({ min: 1 }).withMessage('Model alias is required'),
  body('system_prompt').optional(),
  body('temperature').optional().isFloat({ min: 0, max: 2 }),
  body('max_tokens').optional().isInt({ min: 1 })
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const {
      model_alias,
      system_prompt,
      temperature,
      max_tokens,
      top_p,
      frequency_penalty,
      presence_penalty,
      stop_sequences,
      other_params
    } = req.body;

    await new Promise((resolve, reject) => {
      db.run(`
        INSERT INTO model_rules (
          model_alias, system_prompt, temperature, max_tokens,
          top_p, frequency_penalty, presence_penalty,
          stop_sequences, other_params
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        model_alias,
        system_prompt,
        temperature || 0.7,
        max_tokens || 2000,
        top_p || 1.0,
        frequency_penalty || 0.0,
        presence_penalty || 0.0,
        stop_sequences ? JSON.stringify(stop_sequences) : null,
        other_params ? JSON.stringify(other_params) : null
      ], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'CREATE_MODEL_RULE',
      resourceType: 'model_rule',
      details: `Created model rule for: ${model_alias}`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.status(201).json({ message: 'Model rule created successfully' });
  } catch (error) {
    console.error('[Admin] Error creating model rule:', error);
    if (error.code === 'SQLITE_CONSTRAINT') {
      res.status(400).json({ error: 'Model rule already exists for this alias' });
    } else {
      res.status(500).json({ error: 'Failed to create model rule' });
    }
  }
});

router.put('/model-rules/:alias', async (req, res) => {
  try {
    const {
      system_prompt,
      temperature,
      max_tokens,
      top_p,
      frequency_penalty,
      presence_penalty,
      stop_sequences,
      other_params
    } = req.body;

    await new Promise((resolve, reject) => {
      db.run(`
        UPDATE model_rules 
        SET system_prompt = ?,
            temperature = ?,
            max_tokens = ?,
            top_p = ?,
            frequency_penalty = ?,
            presence_penalty = ?,
            stop_sequences = ?,
            other_params = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE model_alias = ?
      `, [
        system_prompt,
        temperature,
        max_tokens,
        top_p,
        frequency_penalty,
        presence_penalty,
        stop_sequences ? JSON.stringify(stop_sequences) : null,
        other_params ? JSON.stringify(other_params) : null,
        req.params.alias
      ], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'UPDATE_MODEL_RULE',
      resourceType: 'model_rule',
      details: `Updated model rule for: ${req.params.alias}`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({ message: 'Model rule updated successfully' });
  } catch (error) {
    console.error('[Admin] Error updating model rule:', error);
    res.status(500).json({ error: 'Failed to update model rule' });
  }
});

router.delete('/model-rules/:alias', async (req, res) => {
  try {
    await new Promise((resolve, reject) => {
      db.run('DELETE FROM model_rules WHERE model_alias = ?', [req.params.alias], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'DELETE_MODEL_RULE',
      resourceType: 'model_rule',
      details: `Deleted model rule for: ${req.params.alias}`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({ message: 'Model rule deleted successfully' });
  } catch (error) {
    console.error('[Admin] Error deleting model rule:', error);
    res.status(500).json({ error: 'Failed to delete model rule' });
  }
});

// ==================== GROUP MODEL MANAGEMENT ====================

router.post('/groups/:id/models', [
  body('model_alias').trim().notEmpty(),
  body('model_name').trim().notEmpty()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { model_alias, model_name } = req.body;

    await new Promise((resolve, reject) => {
      db.run(`
        INSERT INTO group_models (group_id, model_alias, model_name)
        VALUES (?, ?, ?)
      `, [req.params.id, model_alias, model_name], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'ADD_GROUP_MODEL',
      resourceType: 'group',
      resourceId: parseInt(req.params.id),
      details: `Added model ${model_alias} to group`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.status(201).json({ message: 'Model added to group successfully' });
  } catch (error) {
    console.error('[Admin] Error adding model to group:', error);
    if (error.code === 'SQLITE_CONSTRAINT') {
      res.status(400).json({ error: 'Model already exists in this group' });
    } else {
      res.status(500).json({ error: 'Failed to add model to group' });
    }
  }
});

router.delete('/groups/:id/models/:modelId', async (req, res) => {
  try {
    await new Promise((resolve, reject) => {
      db.run('DELETE FROM group_models WHERE id = ?', [req.params.modelId], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'REMOVE_GROUP_MODEL',
      resourceType: 'group',
      resourceId: parseInt(req.params.id),
      details: `Removed model from group`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({ message: 'Model removed from group successfully' });
  } catch (error) {
    console.error('[Admin] Error removing model from group:', error);
    res.status(500).json({ error: 'Failed to remove model from group' });
  }
});

// ==================== SYSTEM SETTINGS ====================

router.get('/settings', async (req, res) => {
  try {
    const settings = await new Promise((resolve, reject) => {
      db.all('SELECT * FROM system_settings ORDER BY key', (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ settings });
  } catch (error) {
    console.error('[Admin] Error getting settings:', error);
    res.status(500).json({ error: 'Failed to get settings' });
  }
});

router.put('/settings/:key', async (req, res) => {
  try {
    const { value } = req.body;

    await new Promise((resolve, reject) => {
      db.run(`
        UPDATE system_settings 
        SET value = ?, updated_at = CURRENT_TIMESTAMP
        WHERE key = ?
      `, [value, req.params.key], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    await AuditLogger.log({
      userId: req.user.id,
      action: 'UPDATE_SETTING',
      resourceType: 'setting',
      details: `Updated setting: ${req.params.key}`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({ message: 'Setting updated successfully' });
  } catch (error) {
    console.error('[Admin] Error updating setting:', error);
    res.status(500).json({ error: 'Failed to update setting' });
  }
});

// ==================== AUDIT LOGS ====================

router.get('/audit-logs', async (req, res) => {
  try {
    const { limit = 100, offset = 0 } = req.query;
    const logs = await AuditLogger.getLogs({}, parseInt(limit), parseInt(offset));
    
    res.json({ logs });
  } catch (error) {
    console.error('[Admin] Error getting audit logs:', error);
    res.status(500).json({ error: 'Failed to get audit logs' });
  }
});

// ==================== USAGE ANALYTICS ====================

router.get('/analytics/usage', async (req, res) => {
  try {
    const { days = 7 } = req.query;
    
    const usage = await new Promise((resolve, reject) => {
      db.all(`
        SELECT 
          DATE(created_at) as date,
          COUNT(*) as request_count,
          SUM(total_tokens) as token_count,
          AVG(request_duration_ms) as avg_duration
        FROM usage_logs
        WHERE created_at >= datetime('now', '-' || ? || ' days')
        GROUP BY DATE(created_at)
        ORDER BY date DESC
      `, [days], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ usage });
  } catch (error) {
    console.error('[Admin] Error getting usage analytics:', error);
    res.status(500).json({ error: 'Failed to get usage analytics' });
  }
});

router.get('/analytics/models', async (req, res) => {
  try {
    const { days = 7 } = req.query;
    
    const modelUsage = await new Promise((resolve, reject) => {
      db.all(`
        SELECT 
          model_alias,
          COUNT(*) as request_count,
          SUM(total_tokens) as token_count,
          AVG(request_duration_ms) as avg_duration
        FROM usage_logs
        WHERE created_at >= datetime('now', '-' || ? || ' days')
        GROUP BY model_alias
        ORDER BY request_count DESC
      `, [days], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({ modelUsage });
  } catch (error) {
    console.error('[Admin] Error getting model analytics:', error);
    res.status(500).json({ error: 'Failed to get model analytics' });
  }
});

module.exports = router;
