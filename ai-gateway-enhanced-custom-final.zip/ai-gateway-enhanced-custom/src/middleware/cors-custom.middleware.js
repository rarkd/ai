const db = require('../database/db');

/**
 * Custom CORS Middleware dengan Group-based Allowed Domains
 * Memeriksa apakah origin request diizinkan berdasarkan:
 * 1. allowed_domains di group user
 * 2. user_domains yang ditambahkan user
 */

const corsMiddleware = async (req, res, next) => {
  const origin = req.headers.origin || req.headers.referer;
  
  // Skip CORS check for requests without origin
  if (!origin) {
    return next();
  }

  try {
    // Get user from token (asumsi sudah ter-authenticate)
    const userId = req.user ? req.user.id : null;
    
    if (!userId) {
      // If no user, allow all origins (untuk login page, etc)
      res.header('Access-Control-Allow-Origin', '*');
      res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
      res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
      res.header('Access-Control-Allow-Credentials', 'true');
      
      if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
      }
      return next();
    }

    // Get user's group allowed_domains
    const user = await new Promise((resolve, reject) => {
      db.get(`
        SELECT g.allowed_domains
        FROM users u
        LEFT JOIN groups g ON u.group_id = g.id
        WHERE u.id = ?
      `, [userId], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    // Get user's custom domains
    const userDomains = await new Promise((resolve, reject) => {
      db.all('SELECT domain FROM user_domains WHERE user_id = ?', [userId], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    // Parse allowed domains
    let allowedDomains = [];
    
    // Add group allowed domains
    if (user && user.allowed_domains) {
      if (user.allowed_domains === '*') {
        // Allow all domains
        res.header('Access-Control-Allow-Origin', origin);
        res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
        res.header('Access-Control-Allow-Credentials', 'true');
        
        if (req.method === 'OPTIONS') {
          return res.sendStatus(200);
        }
        return next();
      }
      
      // Parse comma-separated domains
      allowedDomains = user.allowed_domains.split(',').map(d => d.trim());
    }

    // Add user custom domains
    userDomains.forEach(d => {
      if (!allowedDomains.includes(d.domain)) {
        allowedDomains.push(d.domain);
      }
    });

    // Check if origin is allowed
    const originDomain = new URL(origin).hostname;
    const isAllowed = allowedDomains.some(domain => {
      // Exact match
      if (domain === originDomain) return true;
      
      // Wildcard subdomain match (*.example.com)
      if (domain.startsWith('*.')) {
        const baseDomain = domain.substring(2);
        return originDomain.endsWith(baseDomain);
      }
      
      return false;
    });

    if (isAllowed) {
      res.header('Access-Control-Allow-Origin', origin);
      res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
      res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
      res.header('Access-Control-Allow-Credentials', 'true');
      
      if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
      }
      return next();
    } else {
      // Origin not allowed
      console.log(`[CORS] Blocked origin: ${origin} for user ${userId}`);
      return res.status(403).json({ 
        error: 'CORS policy: Origin not allowed',
        origin: origin
      });
    }
  } catch (error) {
    console.error('[CORS] Error checking CORS:', error);
    // On error, allow the request to continue (fail-open)
    res.header('Access-Control-Allow-Origin', origin);
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.header('Access-Control-Allow-Credentials', 'true');
    
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    return next();
  }
};

module.exports = corsMiddleware;
