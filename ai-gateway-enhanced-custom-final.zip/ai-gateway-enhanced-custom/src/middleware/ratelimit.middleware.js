const db = require('../database/db');

/**
 * Rate Limiting Middleware
 * Checks user's rate limits based on their group settings
 */
class RateLimiter {
  
  /**
   * Get user's rate limits from their group
   */
  static async getUserLimits(userId) {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT 
          g.max_requests_per_minute,
          g.max_requests_per_hour,
          g.max_requests_per_day,
          g.monthly_quota
        FROM users u
        LEFT JOIN groups g ON u.group_id = g.id
        WHERE u.id = ?
      `;

      db.get(query, [userId], (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve(row || {
            max_requests_per_minute: 60,
            max_requests_per_hour: 1000,
            max_requests_per_day: 10000,
            monthly_quota: 100000
          });
        }
      });
    });
  }

  /**
   * Get current usage for a time window
   */
  static async getWindowUsage(userId, windowType, windowStart) {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT request_count
        FROM rate_limit_tracking
        WHERE user_id = ? AND window_type = ? AND window_start = ?
      `;

      db.get(query, [userId, windowType, windowStart], (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve(row ? row.request_count : 0);
        }
      });
    });
  }

  /**
   * Increment usage for a time window
   */
  static async incrementWindowUsage(userId, windowType, windowStart) {
    return new Promise((resolve, reject) => {
      const query = `
        INSERT INTO rate_limit_tracking (user_id, window_type, window_start, request_count)
        VALUES (?, ?, ?, 1)
        ON CONFLICT(user_id, window_type, window_start) 
        DO UPDATE SET request_count = request_count + 1
      `;

      db.run(query, [userId, windowType, windowStart], (err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  }

  /**
   * Get window start time
   */
  static getWindowStart(windowType) {
    const now = new Date();
    
    switch (windowType) {
      case 'minute':
        return new Date(now.getFullYear(), now.getMonth(), now.getDate(), 
                       now.getHours(), now.getMinutes(), 0, 0).toISOString();
      case 'hour':
        return new Date(now.getFullYear(), now.getMonth(), now.getDate(), 
                       now.getHours(), 0, 0, 0).toISOString();
      case 'day':
        return new Date(now.getFullYear(), now.getMonth(), now.getDate(), 
                       0, 0, 0, 0).toISOString();
      default:
        return now.toISOString();
    }
  }

  /**
   * Check all rate limits for a user
   */
  static async checkRateLimits(userId) {
    try {
      const limits = await this.getUserLimits(userId);
      
      // Check minute limit
      const minuteStart = this.getWindowStart('minute');
      const minuteUsage = await this.getWindowUsage(userId, 'minute', minuteStart);
      
      if (minuteUsage >= limits.max_requests_per_minute) {
        return {
          allowed: false,
          reason: 'Rate limit exceeded: requests per minute',
          limit: limits.max_requests_per_minute,
          usage: minuteUsage,
          window: 'minute',
          resetAt: new Date(new Date(minuteStart).getTime() + 60000).toISOString()
        };
      }

      // Check hour limit
      const hourStart = this.getWindowStart('hour');
      const hourUsage = await this.getWindowUsage(userId, 'hour', hourStart);
      
      if (hourUsage >= limits.max_requests_per_hour) {
        return {
          allowed: false,
          reason: 'Rate limit exceeded: requests per hour',
          limit: limits.max_requests_per_hour,
          usage: hourUsage,
          window: 'hour',
          resetAt: new Date(new Date(hourStart).getTime() + 3600000).toISOString()
        };
      }

      // Check day limit
      const dayStart = this.getWindowStart('day');
      const dayUsage = await this.getWindowUsage(userId, 'day', dayStart);
      
      if (dayUsage >= limits.max_requests_per_day) {
        return {
          allowed: false,
          reason: 'Rate limit exceeded: requests per day',
          limit: limits.max_requests_per_day,
          usage: dayUsage,
          window: 'day',
          resetAt: new Date(new Date(dayStart).getTime() + 86400000).toISOString()
        };
      }

      // All checks passed
      return {
        allowed: true,
        limits: {
          minute: { limit: limits.max_requests_per_minute, usage: minuteUsage },
          hour: { limit: limits.max_requests_per_hour, usage: hourUsage },
          day: { limit: limits.max_requests_per_day, usage: dayUsage }
        }
      };
    } catch (error) {
      console.error('[Rate Limiter] Error checking limits:', error);
      throw error;
    }
  }

  /**
   * Record a request
   */
  static async recordRequest(userId) {
    try {
      const minuteStart = this.getWindowStart('minute');
      const hourStart = this.getWindowStart('hour');
      const dayStart = this.getWindowStart('day');

      await Promise.all([
        this.incrementWindowUsage(userId, 'minute', minuteStart),
        this.incrementWindowUsage(userId, 'hour', hourStart),
        this.incrementWindowUsage(userId, 'day', dayStart)
      ]);
    } catch (error) {
      console.error('[Rate Limiter] Error recording request:', error);
      throw error;
    }
  }

  /**
   * Middleware function
   */
  static middleware() {
    return async (req, res, next) => {
      try {
        // Skip if no user (shouldn't happen if auth middleware is used first)
        if (!req.user || !req.user.id) {
          return res.status(401).json({ error: 'Authentication required' });
        }

        // Check rate limits
        const result = await this.checkRateLimits(req.user.id);

        if (!result.allowed) {
          // Log security event
          await this.logSecurityEvent(req.user.id, 'rate_limit_exceeded', result, req);
          
          return res.status(429).json({
            error: result.reason,
            limit: result.limit,
            usage: result.usage,
            window: result.window,
            resetAt: result.resetAt
          });
        }

        // Record the request
        await this.recordRequest(req.user.id);

        // Add rate limit info to response headers
        res.setHeader('X-RateLimit-Limit-Minute', result.limits.minute.limit);
        res.setHeader('X-RateLimit-Remaining-Minute', result.limits.minute.limit - result.limits.minute.usage);
        res.setHeader('X-RateLimit-Limit-Hour', result.limits.hour.limit);
        res.setHeader('X-RateLimit-Remaining-Hour', result.limits.hour.limit - result.limits.hour.usage);
        res.setHeader('X-RateLimit-Limit-Day', result.limits.day.limit);
        res.setHeader('X-RateLimit-Remaining-Day', result.limits.day.limit - result.limits.day.usage);

        next();
      } catch (error) {
        console.error('[Rate Limiter Middleware] Error:', error);
        next(error);
      }
    };
  }

  /**
   * Log security event
   */
  static async logSecurityEvent(userId, eventType, details, req) {
    return new Promise((resolve) => {
      const query = `
        INSERT INTO security_events (user_id, event_type, severity, description, ip_address, user_agent)
        VALUES (?, ?, ?, ?, ?, ?)
      `;

      const description = JSON.stringify(details);
      const ipAddress = req.ip || req.connection.remoteAddress;
      const userAgent = req.get('user-agent');

      db.run(query, [userId, eventType, 'warning', description, ipAddress, userAgent], (err) => {
        if (err) {
          console.error('[Rate Limiter] Error logging security event:', err);
        }
        resolve();
      });
    });
  }

  /**
   * Clean up old tracking records (should be run periodically)
   */
  static async cleanup() {
    return new Promise((resolve, reject) => {
      const oneDayAgo = new Date(Date.now() - 86400000).toISOString();
      
      const query = `
        DELETE FROM rate_limit_tracking
        WHERE created_at < ?
      `;

      db.run(query, [oneDayAgo], function(err) {
        if (err) {
          reject(err);
        } else {
          console.log(`[Rate Limiter] Cleaned up ${this.changes} old tracking records`);
          resolve(this.changes);
        }
      });
    });
  }
}

module.exports = RateLimiter;
