const db = require('../database/db');

/**
 * Quota Management System
 * Tracks and enforces monthly usage quotas
 */
class QuotaManager {

  /**
   * Get current month identifier
   */
  static getCurrentMonth() {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  }

  /**
   * Get user's quota limit from their group
   */
  static async getUserQuotaLimit(userId) {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT g.monthly_quota
        FROM users u
        LEFT JOIN groups g ON u.group_id = g.id
        WHERE u.id = ?
      `;

      db.get(query, [userId], (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve(row ? row.monthly_quota : 100000);
        }
      });
    });
  }

  /**
   * Get user's current usage for the month
   */
  static async getMonthlyUsage(userId, month) {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT total_requests, total_tokens, reset_at
        FROM quota_tracking
        WHERE user_id = ? AND month = ?
      `;

      db.get(query, [userId, month], (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve(row || { total_requests: 0, total_tokens: 0, reset_at: null });
        }
      });
    });
  }

  /**
   * Initialize or get quota tracking record
   */
  static async initializeQuotaTracking(userId, month) {
    return new Promise((resolve, reject) => {
      // Calculate next reset date (first day of next month)
      const now = new Date();
      const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);
      const resetAt = nextMonth.toISOString();

      const query = `
        INSERT INTO quota_tracking (user_id, month, total_requests, total_tokens, reset_at)
        VALUES (?, ?, 0, 0, ?)
        ON CONFLICT(user_id, month) DO NOTHING
      `;

      db.run(query, [userId, month, resetAt], (err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  }

  /**
   * Check if user has exceeded their quota
   */
  static async checkQuota(userId) {
    try {
      const month = this.getCurrentMonth();
      const [limit, usage] = await Promise.all([
        this.getUserQuotaLimit(userId),
        this.getMonthlyUsage(userId, month)
      ]);

      const exceeded = usage.total_tokens >= limit;
      const remaining = Math.max(0, limit - usage.total_tokens);
      const percentUsed = (usage.total_tokens / limit * 100).toFixed(2);

      return {
        allowed: !exceeded,
        limit,
        used: usage.total_tokens,
        remaining,
        percentUsed: parseFloat(percentUsed),
        resetAt: usage.reset_at,
        month
      };
    } catch (error) {
      console.error('[Quota Manager] Error checking quota:', error);
      throw error;
    }
  }

  /**
   * Record token usage
   */
  static async recordUsage(userId, tokens) {
    try {
      const month = this.getCurrentMonth();
      
      // Ensure tracking record exists
      await this.initializeQuotaTracking(userId, month);

      // Update usage
      const query = `
        UPDATE quota_tracking
        SET total_requests = total_requests + 1,
            total_tokens = total_tokens + ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE user_id = ? AND month = ?
      `;

      return new Promise((resolve, reject) => {
        db.run(query, [tokens, userId, month], (err) => {
          if (err) {
            reject(err);
          } else {
            resolve();
          }
        });
      });
    } catch (error) {
      console.error('[Quota Manager] Error recording usage:', error);
      throw error;
    }
  }

  /**
   * Middleware to check quota before processing request
   */
  static middleware() {
    return async (req, res, next) => {
      try {
        // Skip if no user
        if (!req.user || !req.user.id) {
          return res.status(401).json({ error: 'Authentication required' });
        }

        // Check quota
        const quota = await this.checkQuota(req.user.id);

        if (!quota.allowed) {
          // Log event
          await this.logQuotaEvent(req.user.id, 'quota_exceeded', quota, req);

          return res.status(429).json({
            error: 'Monthly quota exceeded',
            quota: {
              limit: quota.limit,
              used: quota.used,
              remaining: 0,
              resetAt: quota.resetAt
            }
          });
        }

        // Add quota info to request for later use
        req.quota = quota;

        // Add quota headers
        res.setHeader('X-Quota-Limit', quota.limit);
        res.setHeader('X-Quota-Used', quota.used);
        res.setHeader('X-Quota-Remaining', quota.remaining);
        res.setHeader('X-Quota-Reset', quota.resetAt);

        next();
      } catch (error) {
        console.error('[Quota Middleware] Error:', error);
        next(error);
      }
    };
  }

  /**
   * Get quota statistics for a user
   */
  static async getQuotaStats(userId, months = 6) {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT month, total_requests, total_tokens, reset_at
        FROM quota_tracking
        WHERE user_id = ?
        ORDER BY month DESC
        LIMIT ?
      `;

      db.all(query, [userId, months], (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }

  /**
   * Reset quota for a user (admin function)
   */
  static async resetQuota(userId) {
    const month = this.getCurrentMonth();
    
    return new Promise((resolve, reject) => {
      const query = `
        UPDATE quota_tracking
        SET total_requests = 0,
            total_tokens = 0,
            updated_at = CURRENT_TIMESTAMP
        WHERE user_id = ? AND month = ?
      `;

      db.run(query, [userId, month], (err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  }

  /**
   * Get all users approaching quota limit (for notifications)
   */
  static async getUsersApproachingQuota(threshold = 80) {
    return new Promise((resolve, reject) => {
      const month = this.getCurrentMonth();
      
      const query = `
        SELECT 
          u.id,
          u.username,
          u.email,
          g.monthly_quota as quota_limit,
          qt.total_tokens,
          (qt.total_tokens * 100.0 / g.monthly_quota) as percent_used
        FROM users u
        LEFT JOIN groups g ON u.group_id = g.id
        LEFT JOIN quota_tracking qt ON u.id = qt.user_id AND qt.month = ?
        WHERE (qt.total_tokens * 100.0 / g.monthly_quota) >= ?
        AND u.is_banned = 0
        ORDER BY percent_used DESC
      `;

      db.all(query, [month, threshold], (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }

  /**
   * Log quota event
   */
  static async logQuotaEvent(userId, eventType, details, req) {
    return new Promise((resolve) => {
      const query = `
        INSERT INTO security_events (user_id, event_type, severity, description, ip_address, user_agent)
        VALUES (?, ?, ?, ?, ?, ?)
      `;

      const description = JSON.stringify(details);
      const ipAddress = req.ip || req.connection.remoteAddress;
      const userAgent = req.get('user-agent');

      db.run(query, [userId, eventType, 'warning', description, ipAddress, userAgent], (err) => {
        if (err) {
          console.error('[Quota Manager] Error logging event:', err);
        }
        resolve();
      });
    });
  }

  /**
   * Periodic cleanup of old quota records
   */
  static async cleanupOldRecords(monthsToKeep = 12) {
    return new Promise((resolve, reject) => {
      const now = new Date();
      const cutoffDate = new Date(now.getFullYear(), now.getMonth() - monthsToKeep, 1);
      const cutoffMonth = `${cutoffDate.getFullYear()}-${String(cutoffDate.getMonth() + 1).padStart(2, '0')}`;

      const query = `
        DELETE FROM quota_tracking
        WHERE month < ?
      `;

      db.run(query, [cutoffMonth], function(err) {
        if (err) {
          reject(err);
        } else {
          console.log(`[Quota Manager] Cleaned up ${this.changes} old quota records`);
          resolve(this.changes);
        }
      });
    });
  }

  /**
   * Get quota summary for all users (admin dashboard)
   */
  static async getAllUsersQuotaSummary() {
    return new Promise((resolve, reject) => {
      const month = this.getCurrentMonth();
      
      const query = `
        SELECT 
          u.id,
          u.username,
          u.email,
          g.name as group_name,
          g.monthly_quota as quota_limit,
          COALESCE(qt.total_requests, 0) as total_requests,
          COALESCE(qt.total_tokens, 0) as total_tokens,
          COALESCE((qt.total_tokens * 100.0 / g.monthly_quota), 0) as percent_used
        FROM users u
        LEFT JOIN groups g ON u.group_id = g.id
        LEFT JOIN quota_tracking qt ON u.id = qt.user_id AND qt.month = ?
        WHERE u.role = 'user'
        ORDER BY percent_used DESC
      `;

      db.all(query, [month], (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }
}

module.exports = QuotaManager;
