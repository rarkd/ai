const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const path = require('path');
require('dotenv').config();

const dbPath = process.env.DATABASE_PATH || path.join(__dirname, '../../data/gateway.db');

async function initDatabase() {
  return new Promise((resolve, reject) => {
    const db = new sqlite3.Database(dbPath, (err) => {
      if (err) {
        console.error('[DB Init Custom] Error opening database:', err);
        reject(err);
        return;
      }
      console.log('[DB Init Custom] Database opened successfully');
    });

    db.serialize(async () => {
      try {
        // ===== EXISTING TABLES =====
        
        // Users table
        db.run(`
          CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'user' CHECK(role IN ('admin', 'user')),
            group_id INTEGER,
            is_banned INTEGER DEFAULT 0,
            two_factor_secret TEXT,
            two_factor_enabled INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_login DATETIME,
            FOREIGN KEY (group_id) REFERENCES groups(id)
          )
        `);

        // Groups table - MODIFIED: tambah allowed_domains
        db.run(`
          CREATE TABLE IF NOT EXISTS groups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            description TEXT,
            allowed_domains TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `);

        // Group models table
        db.run(`
          CREATE TABLE IF NOT EXISTS group_models (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_id INTEGER NOT NULL,
            model_alias TEXT NOT NULL,
            model_name TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (group_id) REFERENCES groups(id) ON DELETE CASCADE,
            UNIQUE(group_id, model_alias)
          )
        `);

        // User domains table
        db.run(`
          CREATE TABLE IF NOT EXISTS user_domains (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            domain TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE(user_id, domain)
          )
        `);

        // API keys table
        db.run(`
          CREATE TABLE IF NOT EXISTS api_keys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            key_hash TEXT NOT NULL,
            key_prefix TEXT NOT NULL,
            name TEXT,
            expires_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_used DATETIME,
            is_active INTEGER DEFAULT 1,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
          )
        `);

        // Usage logs table (simplified - no quota tracking)
        db.run(`
          CREATE TABLE IF NOT EXISTS usage_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            model_alias TEXT NOT NULL,
            request_tokens INTEGER DEFAULT 0,
            response_tokens INTEGER DEFAULT 0,
            total_tokens INTEGER DEFAULT 0,
            request_duration_ms INTEGER DEFAULT 0,
            status_code INTEGER DEFAULT 200,
            error_message TEXT,
            ip_address TEXT,
            user_agent TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
          )
        `);

        // Audit logs table
        db.run(`
          CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            action TEXT NOT NULL,
            resource_type TEXT,
            resource_id INTEGER,
            details TEXT,
            ip_address TEXT,
            user_agent TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
          )
        `);

        // Webhooks table
        db.run(`
          CREATE TABLE IF NOT EXISTS webhooks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            url TEXT NOT NULL,
            secret TEXT,
            events TEXT NOT NULL,
            is_active INTEGER DEFAULT 1,
            last_triggered DATETIME,
            failure_count INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
          )
        `);

        // Webhook logs table
        db.run(`
          CREATE TABLE IF NOT EXISTS webhook_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            webhook_id INTEGER NOT NULL,
            event_type TEXT NOT NULL,
            payload TEXT,
            response_status INTEGER,
            response_body TEXT,
            error_message TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (webhook_id) REFERENCES webhooks(id) ON DELETE CASCADE
          )
        `);

        // Email notifications queue
        db.run(`
          CREATE TABLE IF NOT EXISTS email_queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            to_email TEXT NOT NULL,
            subject TEXT NOT NULL,
            body TEXT NOT NULL,
            status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'sent', 'failed')),
            attempts INTEGER DEFAULT 0,
            error_message TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            sent_at DATETIME,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
          )
        `);

        // System settings table
        db.run(`
          CREATE TABLE IF NOT EXISTS system_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key TEXT UNIQUE NOT NULL,
            value TEXT,
            description TEXT,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `);

        // Security events table
        db.run(`
          CREATE TABLE IF NOT EXISTS security_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            event_type TEXT NOT NULL,
            severity TEXT DEFAULT 'info' CHECK(severity IN ('info', 'warning', 'critical')),
            description TEXT,
            ip_address TEXT,
            user_agent TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
          )
        `);

        // ===== NEW CUSTOM TABLES =====

        // Model rules table (hanya admin yang bisa atur)
        db.run(`
          CREATE TABLE IF NOT EXISTS model_rules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            model_alias TEXT NOT NULL UNIQUE,
            system_prompt TEXT,
            temperature REAL DEFAULT 0.7,
            max_tokens INTEGER DEFAULT 2000,
            top_p REAL DEFAULT 1.0,
            frequency_penalty REAL DEFAULT 0.0,
            presence_penalty REAL DEFAULT 0.0,
            stop_sequences TEXT,
            other_params TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `);

        // User knowledge base table (setiap user bisa punya)
        db.run(`
          CREATE TABLE IF NOT EXISTS user_knowledge_base (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            content TEXT NOT NULL,
            is_active INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
          )
        `);

        // Admin impersonation log (untuk tracking admin login as user)
        db.run(`
          CREATE TABLE IF NOT EXISTS admin_impersonation_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_id INTEGER NOT NULL,
            target_user_id INTEGER NOT NULL,
            ip_address TEXT,
            user_agent TEXT,
            started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            ended_at DATETIME,
            FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (target_user_id) REFERENCES users(id) ON DELETE CASCADE
          )
        `);

        console.log('[DB Init Custom] All tables created successfully');

        // Create indexes for performance
        db.run('CREATE INDEX IF NOT EXISTS idx_usage_logs_user_id ON usage_logs(user_id)');
        db.run('CREATE INDEX IF NOT EXISTS idx_usage_logs_created_at ON usage_logs(created_at)');
        db.run('CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id)');
        db.run('CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at)');
        db.run('CREATE INDEX IF NOT EXISTS idx_webhook_logs_webhook_id ON webhook_logs(webhook_id)');
        db.run('CREATE INDEX IF NOT EXISTS idx_user_knowledge_base_user_id ON user_knowledge_base(user_id)');
        db.run('CREATE INDEX IF NOT EXISTS idx_admin_impersonation_logs_admin_id ON admin_impersonation_logs(admin_id)');

        console.log('[DB Init Custom] Indexes created successfully');

        // ===== MIGRATE EXISTING DATA =====
        
        // Add allowed_domains column to groups if not exists
        db.run(`ALTER TABLE groups ADD COLUMN allowed_domains TEXT`, (err) => {
          // Ignore if column already exists
        });

        console.log('[DB Init Custom] Migration applied');

        // ===== INSERT DEFAULT DATA =====

        // Hash default admin password
        const hashedPassword = await bcrypt.hash('admin123', 10);

        // Check if admin exists
        db.get('SELECT id FROM users WHERE username = ?', ['admin'], (err, row) => {
          if (err) {
            console.error('[DB Init Custom] Error checking admin:', err);
            return;
          }

          if (!row) {
            db.run(`
              INSERT INTO users (username, email, password, role, group_id)
              VALUES (?, ?, ?, ?, ?)
            `, ['admin', 'admin@gateway.local', hashedPassword, 'admin', 3], (err) => {
              if (err) {
                console.error('[DB Init Custom] Error creating admin:', err);
              } else {
                console.log('[DB Init Custom] Default admin user created');
                console.log('  Username: admin');
                console.log('  Email: admin@gateway.local');
                console.log('  Password: admin123');
                console.log('  ⚠️  CHANGE PASSWORD IMMEDIATELY!');
              }
            });
          } else {
            console.log('[DB Init Custom] Admin user already exists');
          }
        });

        // Create default groups
        const groups = [
          { name: 'Basic', description: 'Basic tier with limited models', domains: '*' },
          { name: 'Pro', description: 'Pro tier with more models', domains: '*' },
          { name: 'Enterprise', description: 'Enterprise tier with all models', domains: '*' }
        ];

        groups.forEach(group => {
          db.run(`
            INSERT OR IGNORE INTO groups (name, description, allowed_domains)
            VALUES (?, ?, ?)
          `, [group.name, group.description, group.domains]);
        });

        console.log('[DB Init Custom] Default groups created/verified');

        // Create default model mappings
        const models = [
          { groupId: 1, alias: 'gpt-3.5-turbo', model: 'llama3.2:latest' },
          { groupId: 2, alias: 'gpt-3.5-turbo', model: 'llama3.2:latest' },
          { groupId: 2, alias: 'gpt-4', model: 'llama3.2:latest' },
          { groupId: 2, alias: 'claude-3-sonnet', model: 'llama3.2:latest' },
          { groupId: 3, alias: 'gpt-3.5-turbo', model: 'llama3.2:latest' },
          { groupId: 3, alias: 'gpt-4', model: 'llama3.2:latest' },
          { groupId: 3, alias: 'claude-3-sonnet', model: 'llama3.2:latest' },
          { groupId: 3, alias: 'claude-3-opus', model: 'llama3.2:latest' }
        ];

        models.forEach(model => {
          db.run(`
            INSERT OR IGNORE INTO group_models (group_id, model_alias, model_name)
            VALUES (?, ?, ?)
          `, [model.groupId, model.alias, model.model]);
        });

        console.log('[DB Init Custom] Default model mappings created/verified');

        // Create default model rules
        const modelRules = [
          {
            alias: 'gpt-3.5-turbo',
            prompt: 'You are a helpful AI assistant.',
            temp: 0.7,
            max_tokens: 2000
          },
          {
            alias: 'gpt-4',
            prompt: 'You are a highly capable AI assistant with advanced reasoning abilities.',
            temp: 0.7,
            max_tokens: 4000
          },
          {
            alias: 'claude-3-sonnet',
            prompt: 'You are Claude, an AI assistant created by Anthropic.',
            temp: 0.7,
            max_tokens: 4000
          }
        ];

        modelRules.forEach(rule => {
          db.run(`
            INSERT OR IGNORE INTO model_rules (model_alias, system_prompt, temperature, max_tokens)
            VALUES (?, ?, ?, ?)
          `, [rule.alias, rule.prompt, rule.temp, rule.max_tokens]);
        });

        console.log('[DB Init Custom] Default model rules created/verified');

        // Insert default system settings
        const settings = [
          { key: 'SMTP_ENABLED', value: 'false', description: 'Enable email notifications' },
          { key: 'SMTP_HOST', value: '', description: 'SMTP server host' },
          { key: 'SMTP_PORT', value: '587', description: 'SMTP server port' },
          { key: 'SMTP_USER', value: '', description: 'SMTP username' },
          { key: 'SMTP_FROM', value: 'noreply@gateway.local', description: 'From email address' },
          { key: 'WEBHOOK_TIMEOUT', value: '5000', description: 'Webhook timeout in ms' },
          { key: 'LOG_RETENTION_DAYS', value: '90', description: 'Days to retain logs' }
        ];

        settings.forEach(setting => {
          db.run(`
            INSERT OR IGNORE INTO system_settings (key, value, description)
            VALUES (?, ?, ?)
          `, [setting.key, setting.value, setting.description]);
        });

        console.log('[DB Init Custom] System settings initialized');

        console.log('');
        console.log('========================================');
        console.log('✅ Custom Database initialization complete!');
        console.log('========================================');
        console.log('');
        console.log('🎉 New Custom Features:');
        console.log('  ✓ Group CORS Allowed Domains');
        console.log('  ✓ Admin Login as User');
        console.log('  ✓ Model Rules (Admin Only)');
        console.log('  ✓ User Knowledge Base');
        console.log('  ✓ No Rate Limits');
        console.log('  ✓ No Monthly Quotas');
        console.log('========================================');

        db.close((err) => {
          if (err) {
            console.error('[DB Init Custom] Error closing database:', err);
            reject(err);
          } else {
            console.log('[DB Init Custom] Database closed successfully');
            resolve();
          }
        });
      } catch (error) {
        console.error('[DB Init Custom] Error during initialization:', error);
        reject(error);
      }
    });
  });
}

// Run initialization if called directly
if (require.main === module) {
  initDatabase()
    .then(() => {
      console.log('[DB Init Custom] Initialization script completed successfully');
      process.exit(0);
    })
    .catch(err => {
      console.error('[DB Init Custom] Initialization script failed:', err);
      process.exit(1);
    });
}

module.exports = { initDatabase };
