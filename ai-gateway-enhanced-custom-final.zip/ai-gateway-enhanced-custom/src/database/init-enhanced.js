const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const path = require('path');
require('dotenv').config();

const dbPath = process.env.DATABASE_PATH || path.join(__dirname, '../../data/gateway.db');

async function initDatabase() {
  return new Promise((resolve, reject) => {
    const db = new sqlite3.Database(dbPath, (err) => {
      if (err) {
        console.error('[DB Init] Error opening database:', err);
        reject(err);
        return;
      }
      console.log('[DB Init] Database opened successfully');
    });

    db.serialize(async () => {
      try {
        // ===== EXISTING TABLES =====
        
        // Users table
        db.run(`
          CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'user' CHECK(role IN ('admin', 'user')),
            group_id INTEGER,
            is_banned INTEGER DEFAULT 0,
            two_factor_secret TEXT,
            two_factor_enabled INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_login DATETIME,
            FOREIGN KEY (group_id) REFERENCES groups(id)
          )
        `);

        // Groups table
        db.run(`
          CREATE TABLE IF NOT EXISTS groups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            description TEXT,
            max_requests_per_minute INTEGER DEFAULT 60,
            max_requests_per_hour INTEGER DEFAULT 1000,
            max_requests_per_day INTEGER DEFAULT 10000,
            monthly_quota INTEGER DEFAULT 100000,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `);

        // Group models table
        db.run(`
          CREATE TABLE IF NOT EXISTS group_models (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_id INTEGER NOT NULL,
            model_alias TEXT NOT NULL,
            model_name TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (group_id) REFERENCES groups(id) ON DELETE CASCADE,
            UNIQUE(group_id, model_alias)
          )
        `);

        // User domains table
        db.run(`
          CREATE TABLE IF NOT EXISTS user_domains (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            domain TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE(user_id, domain)
          )
        `);

        // API keys table
        db.run(`
          CREATE TABLE IF NOT EXISTS api_keys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            key_hash TEXT NOT NULL,
            key_prefix TEXT NOT NULL,
            name TEXT,
            expires_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_used DATETIME,
            is_active INTEGER DEFAULT 1,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
          )
        `);

        // ===== NEW ENHANCED TABLES =====

        // Usage logs table (enhanced)
        db.run(`
          CREATE TABLE IF NOT EXISTS usage_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            model_alias TEXT NOT NULL,
            request_tokens INTEGER DEFAULT 0,
            response_tokens INTEGER DEFAULT 0,
            total_tokens INTEGER DEFAULT 0,
            request_duration_ms INTEGER DEFAULT 0,
            status_code INTEGER DEFAULT 200,
            error_message TEXT,
            ip_address TEXT,
            user_agent TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
          )
        `);

        // Quota tracking table
        db.run(`
          CREATE TABLE IF NOT EXISTS quota_tracking (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            month TEXT NOT NULL,
            total_requests INTEGER DEFAULT 0,
            total_tokens INTEGER DEFAULT 0,
            reset_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE(user_id, month)
          )
        `);

        // Rate limit tracking table
        db.run(`
          CREATE TABLE IF NOT EXISTS rate_limit_tracking (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            window_type TEXT NOT NULL CHECK(window_type IN ('minute', 'hour', 'day')),
            window_start DATETIME NOT NULL,
            request_count INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE(user_id, window_type, window_start)
          )
        `);

        // Audit logs table
        db.run(`
          CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            action TEXT NOT NULL,
            resource_type TEXT,
            resource_id INTEGER,
            details TEXT,
            ip_address TEXT,
            user_agent TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
          )
        `);

        // Webhooks table
        db.run(`
          CREATE TABLE IF NOT EXISTS webhooks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            url TEXT NOT NULL,
            secret TEXT,
            events TEXT NOT NULL,
            is_active INTEGER DEFAULT 1,
            last_triggered DATETIME,
            failure_count INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
          )
        `);

        // Webhook logs table
        db.run(`
          CREATE TABLE IF NOT EXISTS webhook_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            webhook_id INTEGER NOT NULL,
            event_type TEXT NOT NULL,
            payload TEXT,
            response_status INTEGER,
            response_body TEXT,
            error_message TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (webhook_id) REFERENCES webhooks(id) ON DELETE CASCADE
          )
        `);

        // Email notifications queue
        db.run(`
          CREATE TABLE IF NOT EXISTS email_queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            to_email TEXT NOT NULL,
            subject TEXT NOT NULL,
            body TEXT NOT NULL,
            status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'sent', 'failed')),
            attempts INTEGER DEFAULT 0,
            error_message TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            sent_at DATETIME,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
          )
        `);

        // System settings table
        db.run(`
          CREATE TABLE IF NOT EXISTS system_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key TEXT UNIQUE NOT NULL,
            value TEXT,
            description TEXT,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `);

        // Security events table
        db.run(`
          CREATE TABLE IF NOT EXISTS security_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            event_type TEXT NOT NULL,
            severity TEXT DEFAULT 'info' CHECK(severity IN ('info', 'warning', 'critical')),
            description TEXT,
            ip_address TEXT,
            user_agent TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
          )
        `);

        console.log('[DB Init] All tables created successfully');

        // Create indexes for performance
        db.run('CREATE INDEX IF NOT EXISTS idx_usage_logs_user_id ON usage_logs(user_id)');
        db.run('CREATE INDEX IF NOT EXISTS idx_usage_logs_created_at ON usage_logs(created_at)');
        db.run('CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id)');
        db.run('CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at)');
        db.run('CREATE INDEX IF NOT EXISTS idx_webhook_logs_webhook_id ON webhook_logs(webhook_id)');
        db.run('CREATE INDEX IF NOT EXISTS idx_quota_tracking_user_month ON quota_tracking(user_id, month)');
        db.run('CREATE INDEX IF NOT EXISTS idx_rate_limit_tracking_user ON rate_limit_tracking(user_id, window_type, window_start)');

        console.log('[DB Init] Indexes created successfully');

        // ===== INSERT DEFAULT DATA =====

        // Hash default admin password
        const hashedPassword = await bcrypt.hash('admin123', 10);

        // Check if admin exists
        db.get('SELECT id FROM users WHERE username = ?', ['admin'], (err, row) => {
          if (err) {
            console.error('[DB Init] Error checking admin:', err);
            return;
          }

          if (!row) {
            db.run(`
              INSERT INTO users (username, email, password, role, group_id)
              VALUES (?, ?, ?, ?, ?)
            `, ['admin', 'admin@gateway.local', hashedPassword, 'admin', 3], (err) => {
              if (err) {
                console.error('[DB Init] Error creating admin:', err);
              } else {
                console.log('[DB Init] Default admin user created');
                console.log('  Username: admin');
                console.log('  Email: admin@gateway.local');
                console.log('  Password: admin123');
                console.log('  ⚠️  CHANGE PASSWORD IMMEDIATELY!');
              }
            });
          } else {
            console.log('[DB Init] Admin user already exists');
          }
        });

        // Create default groups
        const groups = [
          { name: 'Basic', description: 'Basic tier with limited models', max_rpm: 10, max_rph: 100, max_rpd: 1000, quota: 10000 },
          { name: 'Pro', description: 'Pro tier with more models', max_rpm: 30, max_rph: 500, max_rpd: 5000, quota: 50000 },
          { name: 'Enterprise', description: 'Enterprise tier with all models', max_rpm: 60, max_rph: 1000, max_rpd: 10000, quota: 100000 }
        ];

        groups.forEach(group => {
          db.run(`
            INSERT OR IGNORE INTO groups (name, description, max_requests_per_minute, max_requests_per_hour, max_requests_per_day, monthly_quota)
            VALUES (?, ?, ?, ?, ?, ?)
          `, [group.name, group.description, group.max_rpm, group.max_rph, group.max_rpd, group.quota]);
        });

        console.log('[DB Init] Default groups created/verified');

        // Create default model mappings
        const models = [
          { groupId: 1, alias: 'gpt-3.5-turbo', model: 'llama3.2:latest' },
          { groupId: 2, alias: 'gpt-3.5-turbo', model: 'llama3.2:latest' },
          { groupId: 2, alias: 'gpt-4', model: 'llama3.2:latest' },
          { groupId: 2, alias: 'claude-3-sonnet', model: 'llama3.2:latest' },
          { groupId: 3, alias: 'gpt-3.5-turbo', model: 'llama3.2:latest' },
          { groupId: 3, alias: 'gpt-4', model: 'llama3.2:latest' },
          { groupId: 3, alias: 'claude-3-sonnet', model: 'llama3.2:latest' },
          { groupId: 3, alias: 'claude-3-opus', model: 'llama3.2:latest' }
        ];

        models.forEach(model => {
          db.run(`
            INSERT OR IGNORE INTO group_models (group_id, model_alias, model_name)
            VALUES (?, ?, ?)
          `, [model.groupId, model.alias, model.model]);
        });

        console.log('[DB Init] Default model mappings created/verified');

        // Insert default system settings
        const settings = [
          { key: 'SMTP_ENABLED', value: 'false', description: 'Enable email notifications' },
          { key: 'SMTP_HOST', value: '', description: 'SMTP server host' },
          { key: 'SMTP_PORT', value: '587', description: 'SMTP server port' },
          { key: 'SMTP_USER', value: '', description: 'SMTP username' },
          { key: 'SMTP_FROM', value: 'noreply@gateway.local', description: 'From email address' },
          { key: 'WEBHOOK_TIMEOUT', value: '5000', description: 'Webhook timeout in ms' },
          { key: 'QUOTA_RESET_DAY', value: '1', description: 'Day of month to reset quotas' },
          { key: 'LOG_RETENTION_DAYS', value: '90', description: 'Days to retain logs' }
        ];

        settings.forEach(setting => {
          db.run(`
            INSERT OR IGNORE INTO system_settings (key, value, description)
            VALUES (?, ?, ?)
          `, [setting.key, setting.value, setting.description]);
        });

        console.log('[DB Init] System settings initialized');

        console.log('');
        console.log('========================================');
        console.log('✅ Database initialization complete!');
        console.log('========================================');
        console.log('');
        console.log('🎉 New Features Added:');
        console.log('  ✓ Rate Limiting (per minute/hour/day)');
        console.log('  ✓ Quota Management (monthly limits)');
        console.log('  ✓ Audit Logs (track all actions)');
        console.log('  ✓ Webhooks (event notifications)');
        console.log('  ✓ Email Notifications');
        console.log('  ✓ 2FA Support (speakeasy)');
        console.log('  ✓ Security Events Tracking');
        console.log('  ✓ Advanced Analytics');
        console.log('========================================');

        db.close((err) => {
          if (err) {
            console.error('[DB Init] Error closing database:', err);
            reject(err);
          } else {
            console.log('[DB Init] Database closed successfully');
            resolve();
          }
        });
      } catch (error) {
        console.error('[DB Init] Error during initialization:', error);
        reject(error);
      }
    });
  });
}

// Run initialization if called directly
if (require.main === module) {
  initDatabase()
    .then(() => {
      console.log('[DB Init] Initialization script completed successfully');
      process.exit(0);
    })
    .catch(err => {
      console.error('[DB Init] Initialization script failed:', err);
      process.exit(1);
    });
}

module.exports = { initDatabase };
