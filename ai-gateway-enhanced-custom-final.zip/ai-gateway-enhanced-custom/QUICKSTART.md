# ⚡ Quick Start Guide - 5 Minutes to Running!

## 🎯 Goal
Get AI Gateway Enhanced v3.0 running in 5 minutes!

## 📋 Prerequisites
- Node.js 16+ installed
- Terminal/Command prompt access
- 5 minutes of your time

## 🚀 Steps

### 1. Extract & Navigate (30 seconds)
```bash
unzip ai-gateway-enhanced-complete.zip
cd ai-gateway-enhanced-complete
```

### 2. Install Dependencies (2 minutes)
```bash
npm install
```

### 3. Setup Environment (30 seconds)
```bash
cp .env.example .env
```

**Edit .env (important!):**
```bash
# Change this line:
JWT_SECRET=your-random-32-character-secret-here

# Optional: Add your email (for notifications)
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
```

### 4. Initialize Database (30 seconds)
```bash
node src/database/init-enhanced.js
```

### 5. Start Server (10 seconds)
```bash
npm start
```

## 🎉 That's It!

Server is now running at: `http://localhost:422`

## 🔐 First Login

### Admin Dashboard
1. Open: `http://localhost:422/admin.html`
2. Login:
   - Email: `admin@gateway.local`
   - Password: `admin123`
3. **⚠️ Change password immediately!**

### User Dashboard  
1. Open: `http://localhost:422/user.html`
2. Create user account via admin first

## ✅ Quick Test

```bash
# Test health endpoint
curl http://localhost:422/health

# Should return:
# {"status":"ok","service":"AI Gateway Enhanced","version":"3.0.0"}
```

## 📚 What's Next?

1. **Change admin password** (Security!)
2. **Create a test user** (Admin panel → Users → Add)
3. **Configure groups** (Admin panel → Groups)
4. **Generate API key** (User panel → API Keys)
5. **Make first AI request**

## 🤖 Make Your First AI Request

```bash
# 1. Get API key from user dashboard
# 2. Make request:

curl -X POST http://localhost:422/api/gpt-3.5-turbo \
  -H "X-API-Key: YOUR_API_KEY_HERE" \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Hello, how are you?",
    "stream": false
  }'
```

## 🎯 Common Next Steps

### Enable Email Notifications
```bash
# Edit .env:
SMTP_ENABLED=true
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
```

### Setup Webhooks
1. Go to User Dashboard
2. Navigate to Webhooks
3. Add webhook:
   - Name: "My App"
   - URL: "https://yourapp.com/webhook"
   - Events: Select events you want

### Enable 2FA (Recommended!)
1. User Dashboard → 2FA
2. Click "Setup 2FA"
3. Scan QR with Google Authenticator
4. Enter code to enable

## 🔧 Quick Commands

```bash
# Start server
npm start

# Development mode (auto-reload)
npm run dev

# Initialize database
node src/database/init-enhanced.js

# With PM2 (production)
npm install -g pm2
npm run pm2:start
```

## 📖 Learn More

- **Full Documentation**: `README-ENHANCED.md`
- **All Features**: `FEATURES-COMPLETE.md`
- **Installation Guide**: `INSTALLATION.md`
- **API Reference**: Check endpoints in README

## 🆘 Having Issues?

### Port already in use?
```bash
# Change port in .env
PORT=8080
```

### Dependencies not installing?
```bash
# Try:
rm -rf node_modules
npm install
```

### Database issues?
```bash
# Reinitialize:
rm ./data/gateway.db
node src/database/init-enhanced.js
```

## ✨ Key Features You Just Got

- ✅ User Management with Groups
- ✅ Rate Limiting (per min/hour/day)
- ✅ Monthly Quotas
- ✅ Audit Logging
- ✅ Webhooks
- ✅ Email Notifications
- ✅ 2FA Authentication
- ✅ CORS Management
- ✅ API Keys
- ✅ Advanced Analytics
- ✅ Automated Maintenance
- ✅ Security Monitoring

## 🎉 You're All Set!

**Time taken:** ~5 minutes  
**Status:** Production Ready ✅  
**Features:** 50+ endpoints, 10+ major features  

**Happy coding!** 🚀

---

**Need help?** Check `INSTALLATION.md` for detailed guide.  
**Want to explore?** Check `FEATURES-COMPLETE.md` for all features.
