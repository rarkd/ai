# AI Gateway Enhanced - User Management & CORS System

Gateway AI dengan sistem manajemen user, grup, CORS domain, dan autentikasi lengkap.

## 🚀 Fitur Utama

### 1. **Sistem Autentikasi**
- Login dengan JWT token
- API Key untuk akses programmatik
- Password hashing dengan bcrypt
- Session management

### 2. **Admin Dashboard**
- Management user (create, edit, delete, ban/unban)
- Management grup (create, edit, delete)
- Assignment model ke grup
- Statistik dan monitoring
- Reset password user

### 3. **User Dashboard**
- Lihat model yang tersedia sesuai grup
- Management domain CORS
- Generate dan kelola API keys
- Dokumentasi API dan contoh kode
- Statistik penggunaan

### 4. **CORS Management**
- Dynamic CORS berdasarkan domain yang didaftarkan user
- Validasi domain per user
- Keamanan cross-origin request

### 5. **Group System**
- Grup fleksibel (Basic, Pro, Enterprise, dll)
- Model assignment per grup
- User assignment ke grup
- Kontrol akses berbasis grup

## 📦 Instalasi

### 1. Install Dependencies

```bash
npm install
```

### 2. Setup Environment

Copy `.env.example` ke `.env` dan sesuaikan:

```bash
cp .env.example .env
```

Edit `.env`:
```env
PORT=422
JWT_SECRET=your-super-secret-jwt-key-change-this
OLLAMA_BASE_URL=https://aiapi.awwlk.my.id
DATABASE_PATH=./data/gateway.db
```

### 3. Initialize Database

```bash
npm run init-db
```

Ini akan membuat:
- Database SQLite
- Tabel-tabel yang diperlukan
- Default admin user (username: admin, password: admin123)
- Default groups (Basic, Pro, Enterprise)
- Sample model mappings

### 4. Start Server

**Development:**
```bash
npm run dev
```

**Production:**
```bash
npm start
```

**With PM2:**
```bash
npm run pm2:start
```

## 📚 Struktur Database

### Users
- id, username, email, password (hashed)
- role (admin/user)
- group_id (referensi ke groups)
- is_banned (status banned)

### Groups
- id, name, description
- Untuk mengorganisir user dan model

### Group Models
- Relasi grup dengan model yang diperbolehkan
- group_id, model_alias, model_name

### User Domains
- Domain yang diperbolehkan untuk CORS per user
- user_id, domain

### API Keys
- API key untuk akses programmatik
- user_id, key_hash, key_prefix, name

### Usage Logs
- Log penggunaan per user
- user_id, model_alias, request_tokens, response_tokens

## 🔐 Autentikasi

### 1. JWT Token (untuk Web)

**Login:**
```javascript
POST /auth/login
{
  "email": "user@example.com",
  "password": "password123"
}

Response:
{
  "token": "eyJhbGc...",
  "user": { ... }
}
```

**Menggunakan Token:**
```javascript
Authorization: Bearer eyJhbGc...
```

### 2. API Key (untuk Server/Script)

**Create API Key:** Melalui User Dashboard

**Menggunakan API Key:**
```javascript
X-API-Key: gw_your_api_key_here
```

## 🌐 API Endpoints

### Authentication
```
POST   /auth/login              - Login user
POST   /auth/register           - Register user baru (admin only)
GET    /auth/me                 - Get current user info
POST   /auth/change-password    - Ubah password
```

### Admin Endpoints (Require Admin Role)
```
GET    /admin/users             - List semua user
GET    /admin/users/:id         - Detail user
POST   /admin/users             - Buat user baru
PUT    /admin/users/:id         - Update user
DELETE /admin/users/:id         - Hapus user
PATCH  /admin/users/:id/ban     - Ban/unban user
POST   /admin/users/:id/reset-password  - Reset password user

GET    /admin/groups            - List semua grup
GET    /admin/groups/:id        - Detail grup
POST   /admin/groups            - Buat grup baru
PUT    /admin/groups/:id        - Update grup
DELETE /admin/groups/:id        - Hapus grup

POST   /admin/groups/:id/models - Tambah model ke grup
DELETE /admin/groups/:groupId/models/:modelId - Hapus model dari grup

POST   /admin/users/:id/domains - Tambah domain ke user
DELETE /admin/users/:userId/domains/:domainId - Hapus domain

GET    /admin/stats             - Dashboard statistics
```

### User Endpoints
```
GET    /user/models             - List model yang tersedia
GET    /user/group              - Info grup user
GET    /user/domains            - List domain CORS user
POST   /user/domains            - Tambah domain
DELETE /user/domains/:id        - Hapus domain
GET    /user/api-keys           - List API keys
POST   /user/api-keys           - Generate API key baru
DELETE /user/api-keys/:id       - Hapus API key
GET    /user/usage              - Statistik penggunaan
```

### AI Gateway
```
POST   /api/:model              - AI request (authenticated & CORS checked)
GET    /api/models/available    - List available models untuk user
```

## 💡 Contoh Penggunaan

### 1. Admin: Buat User Baru

```javascript
POST /admin/users
Authorization: Bearer {admin_token}

{
  "username": "john",
  "email": "john@example.com",
  "password": "password123",
  "role": "user",
  "group_id": 2
}
```

### 2. Admin: Assign Model ke Grup

```javascript
POST /admin/groups/2/models
Authorization: Bearer {admin_token}

{
  "model_alias": "gpt-4",
  "model_name": "llama3.2:latest"
}
```

### 3. User: Tambah Domain CORS

```javascript
POST /user/domains
Authorization: Bearer {user_token}

{
  "domain": "mywebsite.com"
}
```

### 4. User: Generate API Key

```javascript
POST /user/api-keys
Authorization: Bearer {user_token}

{
  "name": "Production Server"
}

Response:
{
  "apiKey": "gw_a1b2c3d4e5f6g7h8i9j0",
  "warning": "Save this key securely..."
}
```

### 5. AI Request dengan JWT

```javascript
POST /api/gpt-3.5-turbo
Authorization: Bearer {user_token}
Origin: https://mywebsite.com

{
  "prompt": "Hello, how are you?",
  "stream": false
}
```

### 6. AI Request dengan API Key

```javascript
POST /api/gpt-3.5-turbo
X-API-Key: gw_a1b2c3d4e5f6g7h8i9j0
Origin: https://mywebsite.com

{
  "prompt": "Hello, how are you?",
  "stream": false
}
```

## 🎨 Web Interfaces

### Admin Dashboard
- URL: `http://localhost:422/admin.html`
- Login dengan admin credentials
- Fitur:
  - View statistik
  - Manage users
  - Manage groups
  - Assign models to groups
  - Manage user domains

### User Dashboard
- URL: `http://localhost:422/user.html`
- Login dengan user credentials
- Fitur:
  - View available models
  - Manage CORS domains
  - Generate API keys
  - View API documentation
  - Usage statistics

## 🔒 Keamanan

1. **Password Hashing**: Semua password di-hash dengan bcrypt
2. **JWT Token**: Token expires setelah 24 jam (configurable)
3. **API Key**: API key di-hash di database
4. **CORS Protection**: Hanya domain yang terdaftar yang diperbolehkan
5. **Group-based Access**: User hanya bisa akses model sesuai grupnya
6. **Ban System**: Admin bisa ban user untuk suspend akses

## 🛠️ Maintenance

### Backup Database
```bash
cp ./data/gateway.db ./data/gateway.db.backup
```

### View Logs dengan PM2
```bash
npm run pm2:logs
```

### Restart Service
```bash
npm run pm2:restart
```

## 📊 Default Setup

### Default Admin
- Username: `admin`
- Email: `admin@gateway.local`
- Password: `admin123`
- ⚠️ **SEGERA GANTI PASSWORD SETELAH LOGIN PERTAMA KALI!**

### Default Groups
1. **Basic** - Model terbatas
2. **Pro** - Lebih banyak model
3. **Enterprise** - Semua model

### Default Models
- `gpt-3.5-turbo` → llama3.2:latest
- `gpt-4` → llama3.2:latest
- `claude-3-sonnet` → llama3.2:latest
- `claude-3-opus` → llama3.2:latest

## 🚨 Troubleshooting

### Database locked
```bash
# Stop semua instance
npm run pm2:stop
# atau
pkill -f "node.*server.js"

# Restart
npm start
```

### CORS Error
- Pastikan domain sudah ditambahkan di User Dashboard
- Check format domain (tanpa http/https)
- Pastikan Origin header terkirim dari browser

### Authentication Failed
- Check token belum expired
- Check user tidak ter-banned
- Verify API key format (harus mulai dengan `gw_`)

## 📝 Development

### Add New Model
```sql
INSERT INTO model_mappings (alias, model_name, description)
VALUES ('new-model', 'actual-ollama-model', 'Description');

-- Assign to group
INSERT INTO group_models (group_id, model_alias, model_name)
VALUES (2, 'new-model', 'actual-ollama-model');
```

### Custom Middleware
Tambahkan middleware di `src/middleware/` dan import di server.js

## 🤝 Support

Untuk pertanyaan atau issue, silakan buat issue di repository atau hubungi administrator.

## 📄 License

MIT License
