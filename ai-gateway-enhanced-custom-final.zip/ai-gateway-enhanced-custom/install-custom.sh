#!/bin/bash

echo "=========================================="
echo "AI Gateway Enhanced - Custom Edition"
echo "Installation Script"
echo "=========================================="
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    echo "Visit: https://nodejs.org/"
    exit 1
fi

echo "✓ Node.js version: $(node -v)"
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
npm install
echo "✓ Dependencies installed"
echo ""

# Create data directory
if [ ! -d "data" ]; then
    echo "📁 Creating data directory..."
    mkdir -p data
    echo "✓ Data directory created"
fi
echo ""

# Create .env if not exists
if [ ! -f ".env" ]; then
    echo "⚙️  Creating .env file..."
    cat > .env << EOF
# Server Configuration
PORT=422
NODE_ENV=development

# Database
DATABASE_PATH=./data/gateway.db

# JWT Secret (CHANGE THIS IN PRODUCTION!)
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production

# Ollama Configuration
OLLAMA_BASE_URL=https://aiapi.awwlk.my.id
OLLAMA_GENERATE_ENDPOINT=/api/generate

# SMTP Configuration (Optional)
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASS=
SMTP_FROM=noreply@gateway.local

# Features
ENABLE_2FA=true
ENABLE_WEBHOOKS=true
ENABLE_EMAIL=false
EOF
    echo "✓ .env file created"
    echo "⚠️  Please edit .env and change JWT_SECRET!"
else
    echo "✓ .env file already exists"
fi
echo ""

# Initialize database
echo "🗄️  Initializing custom database..."
node src/database/init-custom.js
if [ $? -eq 0 ]; then
    echo "✓ Database initialized successfully"
else
    echo "❌ Database initialization failed"
    exit 1
fi
echo ""

echo "=========================================="
echo "✅ Installation Complete!"
echo "=========================================="
echo ""
echo "🚀 Quick Start:"
echo ""
echo "1. Review and edit .env file:"
echo "   nano .env"
echo ""
echo "2. Start the server:"
echo "   npm start"
echo "   # or for development with auto-reload:"
echo "   npm run dev"
echo ""
echo "3. Access the dashboards:"
echo "   Admin: http://localhost:422/admin.html"
echo "   User:  http://localhost:422/user.html"
echo ""
echo "4. Default admin credentials:"
echo "   Username: admin"
echo "   Password: admin123"
echo "   ⚠️  CHANGE PASSWORD IMMEDIATELY!"
echo ""
echo "=========================================="
echo "📚 Custom Features:"
echo "  ✓ Group-based CORS (Allowed Domains)"
echo "  ✓ Admin Login as User (Impersonation)"
echo "  ✓ Model Rules (Admin-configured)"
echo "  ✓ User Knowledge Base"
echo "  ✓ No Rate Limits"
echo "  ✓ No Monthly Quotas"
echo "=========================================="
echo ""
echo "📖 Read README-CUSTOM.md for detailed documentation"
echo ""
