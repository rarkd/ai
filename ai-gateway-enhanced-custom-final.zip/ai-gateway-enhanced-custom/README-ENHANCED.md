# 🚀 AI Gateway Enhanced v3.0 - Complete Edition

Gateway AI dengan sistem lengkap: User Management, CORS, Rate Limiting, Quota, 2FA, Audit Logs, Webhooks, Email Notifications, dan banyak lagi!

## 🌟 Highlight Fitur

### ✨ Fitur Lengkap (50+ Endpoints!)

| Kategori | Fitur |
|----------|-------|
| **Autentikasi** | JWT, API Keys, 2FA (TOTP) |
| **User Management** | CRUD, Ban/Unban, Password Reset, Group Assignment |
| **Rate Limiting** | Per minute/hour/day, Group-based limits |
| **Quota Management** | Monthly quotas, Auto warnings, Auto reset |
| **Audit Logging** | Track all actions, Export logs, Statistics |
| **Webhooks** | Event subscriptions, HMAC signatures, Auto retry |
| **Email Notifications** | Welcome, Warnings, Reports, Alerts |
| **Security** | Failed login tracking, Suspicious activity detection |
| **Analytics** | Usage stats, Token tracking, Model analytics |
| **Task Scheduler** | Auto cleanup, Email queue, Monthly reports |

## 📦 Instalasi

### 1. Install Dependencies

```bash
npm install
```

**Dependencies Baru:**
- express-rate-limit - Rate limiting
- nodemailer - Email notifications
- speakeasy - 2FA authentication
- qrcode - QR code generation
- cron - Task scheduling
- helmet - Security headers
- winston - Logging

### 2. Setup Environment

```bash
cp .env.example .env
```

Edit `.env`:
```env
# Server
PORT=422
JWT_SECRET=your-super-secret-jwt-key-change-this
OLLAMA_BASE_URL=https://aiapi.awwlk.my.id
DATABASE_PATH=./data/gateway.db

# Email (SMTP)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
SMTP_FROM=noreply@gateway.local

# Webhooks
WEBHOOK_TIMEOUT=5000

# Maintenance
LOG_RETENTION_DAYS=90
```

### 3. Initialize Database

```bash
node src/database/init-enhanced.js
```

Ini akan membuat:
- 15+ tables dengan schema lengkap
- Default admin user
- Default groups dengan rate limits
- Default system settings
- Indexes untuk performance

### 4. Start Server

**Development:**
```bash
npm run dev
```

**Production:**
```bash
npm start
```

**With PM2:**
```bash
npm run pm2:start
```

## 🎯 Quick Start Guide

### For Admins

1. **Login** ke `/admin.html`
   ```
   Email: admin@gateway.local
   Password: admin123
   ⚠️ CHANGE IMMEDIATELY!
   ```

2. **Create User Group**
   - Set rate limits (per min/hour/day)
   - Set monthly quota
   - Assign models

3. **Create Users**
   - Assign to group
   - User receives welcome email
   - User can login and setup

### For Users

1. **Login** ke `/user.html`

2. **Add CORS Domains**
   ```bash
   POST /user/domains
   { "domain": "mywebsite.com" }
   ```

3. **Generate API Key**
   ```bash
   POST /user/api-keys
   { "name": "Production Server" }
   ```

4. **Enable 2FA (Recommended)**
   ```bash
   POST /user/2fa/setup       # Get QR code
   POST /user/2fa/enable      # Enable with verification
   ```

5. **Setup Webhooks (Optional)**
   ```bash
   POST /user/webhooks
   {
     "name": "My App",
     "url": "https://myapp.com/webhook",
     "events": ["quota.warning", "rate_limit.exceeded"]
   }
   ```

6. **Make API Requests**
   ```bash
   # With JWT
   POST /api/gpt-3.5-turbo
   Authorization: Bearer YOUR_JWT_TOKEN
   
   # With API Key
   POST /api/gpt-3.5-turbo
   X-API-Key: gw_your_api_key_here
   ```

## 📡 API Endpoints

### 🔐 Authentication

```bash
POST   /auth/login              # Login (support 2FA)
POST   /auth/register           # Register (admin only)
GET    /auth/me                 # Current user info
POST   /auth/change-password    # Change password
```

### 👨‍💼 Admin Endpoints

```bash
# Users
GET    /admin/users             # List all users
GET    /admin/users/:id         # User details + quota + activity
POST   /admin/users             # Create user
PUT    /admin/users/:id         # Update user
DELETE /admin/users/:id         # Delete user
PATCH  /admin/users/:id/ban     # Ban/unban user
POST   /admin/users/:id/reset-password  # Reset password

# Groups
GET    /admin/groups            # List groups
GET    /admin/groups/:id        # Group details
POST   /admin/groups            # Create group (with limits)
PUT    /admin/groups/:id        # Update group (change limits)
DELETE /admin/groups/:id        # Delete group
POST   /admin/groups/:id/models # Assign model
DELETE /admin/groups/:groupId/models/:modelId # Remove model

# Quota Management
GET    /admin/quota/summary     # All users quota summary
POST   /admin/users/:id/quota/reset  # Reset user quota

# Audit Logs
GET    /admin/audit-logs        # Get logs (with filters)
GET    /admin/audit-logs/stats  # Activity statistics
GET    /admin/audit-logs/export # Export to JSON

# Webhooks (View All)
GET    /admin/webhooks          # View all webhooks

# System Settings
GET    /admin/settings          # Get all settings
PUT    /admin/settings/:key     # Update setting

# Dashboard
GET    /admin/stats             # Dashboard statistics
```

### 👤 User Endpoints

```bash
# Models & Group
GET    /user/models             # Available models
GET    /user/group              # Group info with limits

# CORS Domains
GET    /user/domains            # List domains
POST   /user/domains            # Add domain
DELETE /user/domains/:id        # Delete domain

# API Keys
GET    /user/api-keys           # List API keys
POST   /user/api-keys           # Generate new key
DELETE /user/api-keys/:id       # Delete key

# Usage & Quota
GET    /user/usage              # Usage statistics
GET    /user/quota              # Current quota + history

# Webhooks
GET    /user/webhooks           # List webhooks
POST   /user/webhooks           # Create webhook
PUT    /user/webhooks/:id       # Update webhook
DELETE /user/webhooks/:id       # Delete webhook
POST   /user/webhooks/:id/test  # Test webhook
GET    /user/webhooks/:id/logs  # Webhook logs
GET    /user/webhooks/events/available # Available events

# Two-Factor Authentication
GET    /user/2fa/status         # Check 2FA status
POST   /user/2fa/setup          # Generate secret + QR
POST   /user/2fa/enable         # Enable 2FA
POST   /user/2fa/disable        # Disable 2FA

# Profile
GET    /user/profile            # User profile
GET    /user/activity           # Activity log
```

### 🤖 AI Gateway

```bash
POST   /api/:model              # AI request (with rate limit + quota check)
GET    /api/models/available    # Available models for user
```

## 🔥 Fitur Advanced

### 1. Rate Limiting

Setiap grup punya limit berbeda:

```javascript
// Example: Pro Group
{
  "max_requests_per_minute": 30,
  "max_requests_per_hour": 500,
  "max_requests_per_day": 5000
}
```

Response headers:
```
X-RateLimit-Limit-Minute: 30
X-RateLimit-Remaining-Minute: 25
X-RateLimit-Limit-Hour: 500
X-RateLimit-Remaining-Hour: 480
```

### 2. Quota Management

```javascript
// Check quota
GET /user/quota

Response:
{
  "current": {
    "allowed": true,
    "limit": 50000,
    "used": 12500,
    "remaining": 37500,
    "percentUsed": 25,
    "resetAt": "2024-02-01T00:00:00Z"
  },
  "history": [
    { "month": "2024-01", "total_tokens": 45000 },
    { "month": "2023-12", "total_tokens": 48000 }
  ]
}
```

**Auto Features:**
- Email warning di 80% usage
- Service suspension di 100%
- Auto reset tanggal 1 setiap bulan
- Webhook trigger untuk monitoring

### 3. Webhooks

```javascript
// Create webhook
POST /user/webhooks
{
  "name": "Slack Notifications",
  "url": "https://hooks.slack.com/services/...",
  "events": [
    "quota.warning",
    "quota.exceeded",
    "rate_limit.exceeded",
    "api_key.created"
  ]
}

// Webhook payload example
{
  "event": "quota.warning",
  "timestamp": "2024-01-15T10:00:00Z",
  "data": {
    "userId": 123,
    "username": "john",
    "percentUsed": 85,
    "limit": 50000,
    "used": 42500
  }
}

// Headers sent
X-Webhook-Signature: <HMAC-SHA256>
X-Webhook-Event: quota.warning
```

**Available Events:**
- `user.created`, `user.updated`, `user.deleted`, `user.banned`
- `quota.warning`, `quota.exceeded`
- `rate_limit.exceeded`
- `api_key.created`, `api_key.deleted`
- `security.alert`
- `report.monthly`

### 4. Two-Factor Authentication

```javascript
// Setup flow
1. POST /user/2fa/setup
   → Returns: { secret, qrCode }

2. Scan QR with Google Authenticator

3. POST /user/2fa/enable
   { "secret": "...", "token": "123456" }

// Login with 2FA
POST /auth/login
{
  "email": "user@example.com",
  "password": "password",
  "twoFactorToken": "123456"  // Required if 2FA enabled
}
```

### 5. Audit Logging

Semua aktivitas tercatat:

```javascript
// Get audit logs
GET /admin/audit-logs?userId=123&action=user_create&limit=50

// Export logs
GET /admin/audit-logs/export?dateFrom=2024-01-01&dateTo=2024-01-31

// Activity statistics
GET /admin/audit-logs/stats?days=7
```

**Logged Actions:**
- Authentication events
- User CRUD operations
- Group management
- Model assignments
- Domain changes
- API key operations
- Security events
- Webhook triggers

### 6. Email Notifications

Auto-send emails untuk:
- ✉️ Welcome email (user baru)
- 🔑 Password reset
- ⚠️ Quota warning (80%)
- 🚫 Quota exceeded
- 🔐 API key created
- 📊 Monthly report
- 🛡️ Security alerts

**Configure SMTP:**
```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
```

### 7. Task Scheduler

Automated tasks:

| Frequency | Task |
|-----------|------|
| Every 5 min | Process email queue |
| Hourly | Clean rate limit tracking |
| Daily 9 AM | Check quota warnings |
| Weekly Sunday | Clean audit logs (90 days) |
| Weekly Sunday | Clean webhook logs (30 days) |
| 1st of month | Clean old quota records |
| 1st of month | Send monthly reports |

Manual trigger:
```bash
// Via admin endpoint (if implemented)
POST /admin/tasks/run
{ "task": "quota-warnings" }
```

## 📊 Database Schema

### New Tables (v3.0)

```sql
-- Quota tracking
quota_tracking
├── user_id
├── month (YYYY-MM)
├── total_requests
├── total_tokens
├── reset_at
└── updated_at

-- Rate limit tracking
rate_limit_tracking
├── user_id
├── window_type (minute/hour/day)
├── window_start
├── request_count
└── created_at

-- Audit logs
audit_logs
├── user_id
├── action
├── resource_type
├── resource_id
├── details (JSON)
├── ip_address
├── user_agent
└── created_at

-- Webhooks
webhooks
├── user_id
├── name
├── url
├── secret
├── events (JSON array)
├── is_active
├── last_triggered
├── failure_count
└── timestamps

-- Webhook logs
webhook_logs
├── webhook_id
├── event_type
├── payload
├── response_status
├── error_message
└── created_at

-- Email queue
email_queue
├── user_id
├── to_email
├── subject
├── body
├── status (pending/sent/failed)
├── attempts
└── timestamps

-- System settings
system_settings
├── key
├── value
├── description
└── updated_at

-- Security events
security_events
├── user_id
├── event_type
├── severity (info/warning/critical)
├── description
├── ip_address
└── created_at
```

## 🔒 Security Features

1. **Password Hashing**: bcrypt dengan 10 rounds
2. **JWT Tokens**: Expires 24 jam
3. **API Key Hashing**: bcrypt (never stored plain)
4. **2FA Support**: TOTP (RFC 6238)
5. **Rate Limiting**: Prevent brute force & DoS
6. **CORS Protection**: Per-user whitelist
7. **Audit Logging**: Track all activities
8. **Security Events**: Automatic detection
9. **Webhook Signatures**: HMAC-SHA256
10. **Input Validation**: express-validator

## 🎨 Web Interfaces

### Admin Dashboard (`/admin.html`)
- 📊 Real-time statistics
- 👥 User management
- 🔐 Group management dengan rate limits
- 📝 Audit log viewer
- 🔔 Webhook monitor
- ⚙️ System settings

### User Dashboard (`/user.html`)
- 🤖 Available models
- 🌐 CORS domain management
- 🔑 API key generation
- 📊 Usage statistics & quota
- 🔔 Webhook configuration
- 🔐 2FA setup
- 📖 API documentation

## 📈 Monitoring & Analytics

### Real-time Metrics
- Request count per minute/hour/day
- Token usage tracking
- Error rates
- Response times
- Active users
- Quota usage

### Reports
- Daily usage summary
- Weekly trends
- Monthly reports (auto-email)
- Per-user analytics
- Per-model analytics
- Group comparisons

### Alerts
- Quota warnings (80%)
- Rate limit exceeded
- Failed authentications
- Suspicious activities
- Service disruptions

## 🚀 Production Deployment

### Requirements
- Node.js 16+
- SQLite 3 (or MySQL/PostgreSQL dengan adapter)
- SMTP server (untuk email)
- Reverse proxy (nginx/Apache)
- SSL certificate

### Production Checklist
- [ ] Change default admin password
- [ ] Set strong JWT_SECRET
- [ ] Configure SMTP properly
- [ ] Enable SSL/HTTPS
- [ ] Set up log rotation
- [ ] Configure firewall
- [ ] Set up monitoring
- [ ] Regular database backups
- [ ] Enable PM2 untuk auto-restart

### Performance Tips
1. Use connection pooling
2. Enable database indexes (sudah ada)
3. Configure rate limits sesuai server capacity
4. Set proper cache headers
5. Use CDN untuk static files
6. Monitor memory usage
7. Regular cleanup via scheduler

## 🛠️ Maintenance

### Regular Tasks
```bash
# Backup database
cp ./data/gateway.db ./backups/gateway-$(date +%Y%m%d).db

# View logs
npm run pm2:logs

# Restart service
npm run pm2:restart

# Check status
curl http://localhost:422/health
```

### Troubleshooting

**Rate Limit Issues:**
```bash
# Check rate limit settings
GET /admin/groups/:id

# Adjust limits
PUT /admin/groups/:id
{
  "max_requests_per_minute": 100
}
```

**Email Not Sending:**
1. Check SMTP settings in system_settings
2. Test with: `POST /admin/tasks/run { "task": "email-queue" }`
3. Check email_queue table for errors

**Quota Not Resetting:**
- Scheduler should auto-reset
- Manual reset: `POST /admin/users/:id/quota/reset`

**Webhook Failures:**
- Check webhook logs: `GET /user/webhooks/:id/logs`
- Test webhook: `POST /user/webhooks/:id/test`
- Webhook auto-disables after 10 failures

## 📚 Documentation

- `README-ENHANCED.md` - This file
- `FEATURES-COMPLETE.md` - Detailed feature documentation
- `API.md` - Complete API reference (if available)
- `SETUP.md` - Detailed setup guide (if available)

## 🎓 Examples

### Python Client
```python
import requests

# Setup
BASE_URL = "http://localhost:422"
API_KEY = "gw_your_api_key_here"

headers = {
    "X-API-Key": API_KEY,
    "Content-Type": "application/json"
}

# Make request
response = requests.post(
    f"{BASE_URL}/api/gpt-3.5-turbo",
    headers=headers,
    json={
        "prompt": "Hello, how are you?",
        "stream": False
    }
)

print(response.json())

# Check quota
quota = requests.get(
    f"{BASE_URL}/user/quota",
    headers=headers
)
print(f"Quota used: {quota.json()['current']['percentUsed']}%")
```

### Node.js Client
```javascript
const axios = require('axios');

const client = axios.create({
  baseURL: 'http://localhost:422',
  headers: {
    'X-API-Key': 'gw_your_api_key_here'
  }
});

// Make request
async function chat(prompt) {
  const response = await client.post('/api/gpt-3.5-turbo', {
    prompt,
    stream: false
  });
  
  return response.data;
}

// Check quota
async function checkQuota() {
  const response = await client.get('/user/quota');
  console.log(`Quota: ${response.data.current.percentUsed}%`);
}
```

### Webhook Handler (Express)
```javascript
const crypto = require('crypto');

app.post('/webhook', (req, res) => {
  const signature = req.headers['x-webhook-signature'];
  const payload = JSON.stringify(req.body);
  
  // Verify signature
  const expected = crypto
    .createHmac('sha256', WEBHOOK_SECRET)
    .update(payload)
    .digest('hex');
    
  if (signature !== expected) {
    return res.status(401).send('Invalid signature');
  }
  
  // Handle event
  const { event, data } = req.body;
  
  if (event === 'quota.warning') {
    console.log(`User ${data.username} at ${data.percentUsed}%`);
    // Send notification, update billing, etc.
  }
  
  res.status(200).send('OK');
});
```

## 🤝 Support & Contribution

### Getting Help
- Check documentation
- Review examples
- Check issue tracker
- Contact admin

### Contributing
1. Fork repository
2. Create feature branch
3. Make changes
4. Test thoroughly
5. Submit pull request

## 📄 License

MIT License - Free to use, modify, and distribute

## 🎉 Summary

**AI Gateway Enhanced v3.0** adalah solusi complete untuk:
- ✅ Multi-user AI gateway
- ✅ Enterprise-grade features
- ✅ Production-ready security
- ✅ Comprehensive monitoring
- ✅ Automated maintenance
- ✅ Flexible configuration
- ✅ Excellent performance

**50+ Endpoints | 15+ Tables | 10+ Advanced Features**

**Ready for Production!** 🚀🎯
