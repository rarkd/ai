# AI Gateway Enhanced - Custom Edition

Versi custom dengan fitur-fitur tambahan sesuai kebutuhan spesifik.

## 🎯 Fitur Custom Baru

### 1. **Allowed Domains (CORS) per Group**
Setiap grup dapat memiliki daftar domain yang diizinkan untuk mengakses API.

**Konfigurasi:**
- Admin dapat mengatur `allowed_domains` di setiap grup
- Format: `domain1.com,domain2.com,*.subdomain.com` atau `*` untuk semua domain
- User juga bisa menambahkan domain pribadi melalui endpoint `/user/domains`

**Contoh:**
```bash
# Update group dengan allowed domains
PUT /admin/groups/1
{
  "name": "Pro",
  "description": "Pro tier",
  "allowed_domains": "app.example.com,*.myapp.com,localhost:3000"
}
```

### 2. **Admin Login as User (Impersonation)**
Admin dapat login sebagai user untuk troubleshooting atau testing.

**Cara Menggunakan:**
```bash
# Admin login sebagai user dengan ID 5
POST /admin/users/5/impersonate
Authorization: Bearer <admin_token>

# Response:
{
  "token": "<new_token_as_user>",
  "user": {
    "id": 5,
    "username": "john",
    "impersonated_by": "admin"
  }
}
```

**Tracking:**
- Semua impersonation dicatat di tabel `admin_impersonation_logs`
- View logs: `GET /admin/impersonation-logs`

### 3. **Model Rules (Base Peraturan AI)**
Admin dapat mengatur parameter default untuk setiap model AI.

**Parameter yang bisa diatur:**
- `system_prompt`: Instruksi sistem default
- `temperature`: Kreativitas AI (0-2)
- `max_tokens`: Maksimal token respons
- `top_p`: Nucleus sampling
- `frequency_penalty`: Penalti pengulangan
- `presence_penalty`: Penalti topik baru
- `stop_sequences`: Sequence untuk menghentikan generasi
- `other_params`: Parameter tambahan (JSON)

**Contoh:**
```bash
# Buat model rule
POST /admin/model-rules
{
  "model_alias": "gpt-4",
  "system_prompt": "You are a helpful AI assistant specialized in coding.",
  "temperature": 0.7,
  "max_tokens": 4000
}

# Update model rule
PUT /admin/model-rules/gpt-4
{
  "temperature": 0.5,
  "system_prompt": "You are a professional code reviewer."
}

# Lihat model rules
GET /admin/model-rules
```

### 4. **User Knowledge Base**
Setiap user dapat membuat knowledge base pribadi yang akan ditambahkan ke context AI.

**Fitur:**
- Setiap user bisa punya multiple knowledge entries
- Bisa diaktifkan/nonaktifkan per entry
- Otomatis ditambahkan ke prompt AI saat request

**Contoh:**
```bash
# Buat knowledge base entry
POST /user/knowledge-base
{
  "name": "Company Guidelines",
  "content": "Our company uses React for frontend and Node.js for backend...",
  "is_active": true
}

# Update knowledge base
PUT /user/knowledge-base/1
{
  "name": "Updated Guidelines",
  "content": "New content...",
  "is_active": true
}

# List knowledge base
GET /user/knowledge-base

# Delete knowledge base
DELETE /user/knowledge-base/1
```

**Cara Kerja:**
Ketika user melakukan request AI, semua active knowledge base akan ditambahkan ke system prompt:
```
[Model System Prompt dari admin]

## User Context and Knowledge Base:
[Company Guidelines]
Our company uses React for frontend...

[Project Standards]
Code style guide: ...

---

[User's actual question]
```

### 5. **Tanpa Rate Limit & Quota**
- ❌ Tidak ada rate limiting per menit/jam/hari
- ❌ Tidak ada monthly quota
- ✅ Unlimited requests (tergantung Ollama server)

## 🚀 Setup & Installation

### 1. Install Dependencies
```bash
cd ai-gateway-enhanced-finalv2
npm install
```

### 2. Initialize Custom Database
```bash
node src/database/init-custom.js
```

### 3. Configure Environment
```bash
cp .env.example .env
# Edit .env sesuai kebutuhan
```

### 4. Start Server
```bash
# Development
node src/server-custom.js

# Production with PM2
pm2 start src/server-custom.js --name "ai-gateway-custom"
```

## 📊 Database Schema Custom

### New Tables:

#### `model_rules`
```sql
CREATE TABLE model_rules (
  id INTEGER PRIMARY KEY,
  model_alias TEXT UNIQUE NOT NULL,
  system_prompt TEXT,
  temperature REAL DEFAULT 0.7,
  max_tokens INTEGER DEFAULT 2000,
  top_p REAL DEFAULT 1.0,
  frequency_penalty REAL DEFAULT 0.0,
  presence_penalty REAL DEFAULT 0.0,
  stop_sequences TEXT,
  other_params TEXT,
  created_at DATETIME,
  updated_at DATETIME
);
```

#### `user_knowledge_base`
```sql
CREATE TABLE user_knowledge_base (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  content TEXT NOT NULL,
  is_active INTEGER DEFAULT 1,
  created_at DATETIME,
  updated_at DATETIME,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
```

#### `admin_impersonation_logs`
```sql
CREATE TABLE admin_impersonation_logs (
  id INTEGER PRIMARY KEY,
  admin_id INTEGER NOT NULL,
  target_user_id INTEGER NOT NULL,
  ip_address TEXT,
  user_agent TEXT,
  started_at DATETIME,
  ended_at DATETIME,
  FOREIGN KEY (admin_id) REFERENCES users(id),
  FOREIGN KEY (target_user_id) REFERENCES users(id)
);
```

### Modified Tables:

#### `groups` - Added Column
```sql
ALTER TABLE groups ADD COLUMN allowed_domains TEXT DEFAULT '*';
```

## 🔧 API Endpoints

### Admin Endpoints (New)

#### Impersonation
- `POST /admin/users/:id/impersonate` - Login sebagai user
- `GET /admin/impersonation-logs` - View impersonation logs

#### Model Rules Management
- `GET /admin/model-rules` - List all model rules
- `GET /admin/model-rules/:alias` - Get specific model rule
- `POST /admin/model-rules` - Create model rule
- `PUT /admin/model-rules/:alias` - Update model rule
- `DELETE /admin/model-rules/:alias` - Delete model rule

#### Group Management (Enhanced)
- `PUT /admin/groups/:id` - Update group (with allowed_domains)

### User Endpoints (New)

#### Knowledge Base Management
- `GET /user/knowledge-base` - List all knowledge entries
- `GET /user/knowledge-base/:id` - Get specific entry
- `POST /user/knowledge-base` - Create knowledge entry
- `PUT /user/knowledge-base/:id` - Update knowledge entry
- `DELETE /user/knowledge-base/:id` - Delete knowledge entry

### Gateway Endpoints (Enhanced)
- `POST /api/:model` - AI request (dengan model rules & knowledge base)
- `GET /api/models/:model/rules` - Get model rules info

## 📝 Usage Examples

### 1. Setup Group dengan CORS Domain
```javascript
// Admin membuat grup dengan domain terbatas
const response = await fetch('http://localhost:422/admin/groups', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${adminToken}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    name: 'Premium Users',
    description: 'Users with premium features',
    allowed_domains: 'app.mycompany.com,*.dev.mycompany.com'
  })
});
```

### 2. Admin Login as User
```javascript
// Admin impersonate user untuk debugging
const response = await fetch('http://localhost:422/admin/users/5/impersonate', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${adminToken}`
  }
});

const { token, user } = await response.json();
// Sekarang admin bisa menggunakan token ini untuk bertindak sebagai user
```

### 3. Setup Model Rules
```javascript
// Admin mengatur rules untuk model GPT-4
const response = await fetch('http://localhost:422/admin/model-rules', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${adminToken}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    model_alias: 'gpt-4',
    system_prompt: 'You are an expert software architect. Always provide detailed, production-ready solutions.',
    temperature: 0.6,
    max_tokens: 4000,
    top_p: 0.9
  })
});
```

### 4. User Menambah Knowledge Base
```javascript
// User menambahkan context tentang proyeknya
const response = await fetch('http://localhost:422/user/knowledge-base', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${userToken}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    name: 'Project Tech Stack',
    content: `
      Our project uses:
      - Frontend: React 18 with TypeScript
      - Backend: Node.js with Express
      - Database: PostgreSQL
      - Deployment: AWS ECS
      
      Code style: We follow Airbnb style guide
    `,
    is_active: true
  })
});
```

### 5. AI Request dengan Model Rules & Knowledge Base
```javascript
// User melakukan AI request
// System akan otomatis:
// 1. Apply model rules dari admin
// 2. Inject user's knowledge base
// 3. Process dengan Ollama
const response = await fetch('http://localhost:422/api/gpt-4', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${userToken}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    prompt: 'How should I structure my React components?',
    // temperature bisa di-override, tapi default dari model rules
  })
});

// Response akan mempertimbangkan:
// - System prompt dari model rule
// - User's knowledge base tentang tech stack
// - Question user
```

## 🔒 Security Notes

### Impersonation Security
- Hanya admin yang bisa impersonate
- Semua impersonation dicatat dengan timestamp & IP
- Token impersonation expire dalam 4 jam
- Token memiliki flag `impersonated_by` untuk audit

### CORS Security
- Group-level CORS enforcement
- Support wildcard subdomain (*.example.com)
- User dapat menambahkan domain tambahan
- Admin bisa membatasi ke specific domains

### Model Rules Security
- Hanya admin yang bisa modify model rules
- User bisa melihat apakah model punya rules (tapi tidak full system prompt)
- Rules apply otomatis, user tidak bisa bypass

## 📈 Migration dari Versi Lama

Jika Anda sudah punya database lama:

```bash
# Backup database lama
cp data/gateway.db data/gateway.db.backup

# Run migration
node src/database/init-custom.js

# Server akan otomatis add kolom baru tanpa merusak data lama
```

## 🐛 Troubleshooting

### CORS Issues
```bash
# Check allowed domains untuk grup user
GET /admin/groups/:id

# Check user's custom domains
GET /user/domains
```

### Model Rules Not Applied
```bash
# Check apakah model rules sudah dibuat
GET /admin/model-rules

# Check specific model
GET /admin/model-rules/gpt-4
```

### Knowledge Base Not Working
```bash
# Check apakah knowledge base active
GET /user/knowledge-base

# Pastikan is_active = 1
PUT /user/knowledge-base/:id
{
  "is_active": true
}
```

## 📞 Support

Untuk pertanyaan atau issues, silakan buat issue di repository atau hubungi tim development.

## 📄 License

MIT License - see LICENSE file for details.
