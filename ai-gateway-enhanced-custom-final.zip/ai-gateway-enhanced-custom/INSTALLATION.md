# 📦 Installation Guide - AI Gateway Enhanced v3.0

## 🚀 Quick Install

### Method 1: Automatic Installation (Recommended)

```bash
# 1. Extract files
unzip ai-gateway-enhanced-complete.zip
cd ai-gateway-enhanced-complete

# 2. Run automatic installer
chmod +x install.sh
./install.sh

# 3. Start server
npm start
```

### Method 2: Manual Installation

```bash
# 1. Install dependencies
npm install

# 2. Create .env file
cp .env.example .env
nano .env  # Edit with your settings

# 3. Initialize database
node src/database/init-enhanced.js

# 4. Start server
npm start
```

## ⚙️ Configuration

### Environment Variables (.env)

```env
# Server Configuration
PORT=422
JWT_SECRET=CHANGE-THIS-TO-RANDOM-STRING-AT-LEAST-32-CHARS
OLLAMA_BASE_URL=https://aiapi.awwlk.my.id
DATABASE_PATH=./data/gateway.db

# Email Configuration (Optional but Recommended)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-specific-password
SMTP_FROM=noreply@gateway.local

# Webhook Configuration
WEBHOOK_TIMEOUT=5000

# Maintenance Configuration
LOG_RETENTION_DAYS=90
```

### Gmail Setup (for Email Notifications)

1. Enable 2-Step Verification di Google Account
2. Generate App Password:
   - Go to: https://myaccount.google.com/apppasswords
   - Select "Mail" and device
   - Copy generated password
3. Use App Password di SMTP_PASS

## 📊 Database Initialization

### Automatic (Recommended)

```bash
node src/database/init-enhanced.js
```

Creates:
- ✅ 15+ tables with complete schema
- ✅ Default admin user (admin@gateway.local / admin123)
- ✅ 3 default groups (Basic, Pro, Enterprise)
- ✅ Default rate limits and quotas
- ✅ Model mappings
- ✅ System settings
- ✅ Database indexes

### Manual (Advanced)

```bash
# If you want to customize:
1. Edit src/database/init-enhanced.js
2. Modify default groups, limits, etc.
3. Run: node src/database/init-enhanced.js
```

## 🔐 First Login

### Admin Access

1. Open browser: `http://localhost:422/admin.html`
2. Login with:
   ```
   Email: admin@gateway.local
   Password: admin123
   ```
3. **⚠️ CHANGE PASSWORD IMMEDIATELY!**
   - Go to Settings or Profile
   - Change to strong password

### Create First User

1. In Admin Dashboard, go to Users
2. Click "Add User"
3. Fill form:
   ```
   Username: testuser
   Email: test@example.com
   Password: testpass123
   Role: user
   Group: Basic (or Pro, Enterprise)
   ```
4. User akan menerima welcome email (jika SMTP configured)

## 🎯 Testing Installation

### 1. Health Check

```bash
curl http://localhost:422/health
```

Expected response:
```json
{
  "status": "ok",
  "service": "AI Gateway Enhanced",
  "timestamp": "2024-01-01T10:00:00Z",
  "version": "3.0.0"
}
```

### 2. Test Login

```bash
curl -X POST http://localhost:422/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@gateway.local",
    "password": "admin123"
  }'
```

### 3. Test User Creation

```bash
# Get admin token first from login
curl -X POST http://localhost:422/admin/users \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "testpass123",
    "role": "user",
    "group_id": 1
  }'
```

### 4. Test Rate Limiting

```bash
# Make multiple requests quickly
for i in {1..100}; do
  curl -X POST http://localhost:422/api/gpt-3.5-turbo \
    -H "X-API-Key: YOUR_API_KEY" \
    -d '{"prompt": "test"}'
done

# Should return 429 after limit exceeded
```

## 🔧 Troubleshooting

### Database Issues

```bash
# Database locked
pkill -f "node.*server.js"
rm ./data/gateway.db-wal  # If exists
rm ./data/gateway.db-shm  # If exists
node src/database/init-enhanced.js

# Reinitialize database
rm ./data/gateway.db
node src/database/init-enhanced.js
```

### Email Not Working

```bash
# Check SMTP settings
sqlite3 ./data/gateway.db "SELECT * FROM system_settings WHERE key LIKE 'SMTP%';"

# Update SMTP settings
sqlite3 ./data/gateway.db "UPDATE system_settings SET value='true' WHERE key='SMTP_ENABLED';"

# Test email manually
node -e "
const EmailManager = require('./src/utils/email-manager');
EmailManager.sendEmail('test@example.com', 'Test', '<h1>Test Email</h1>')
  .then(r => console.log(r))
  .catch(e => console.error(e));
"
```

### Port Already in Use

```bash
# Change port in .env
PORT=8080

# Or kill process using port
lsof -ti:422 | xargs kill -9
```

### Dependencies Issues

```bash
# Clear and reinstall
rm -rf node_modules package-lock.json
npm install

# If SQLite build fails
npm install --build-from-source sqlite3
```

## 🐳 Docker Installation (Optional)

### Dockerfile

```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install --production

COPY . .

RUN mkdir -p data

EXPOSE 422

CMD ["npm", "start"]
```

### docker-compose.yml

```yaml
version: '3.8'
services:
  gateway:
    build: .
    ports:
      - "422:422"
    volumes:
      - ./data:/app/data
      - ./.env:/app/.env
    restart: unless-stopped
    environment:
      - NODE_ENV=production
```

### Run with Docker

```bash
# Build and run
docker-compose up -d

# View logs
docker-compose logs -f

# Stop
docker-compose down
```

## 🚀 Production Deployment

### Using PM2

```bash
# Install PM2 globally
npm install -g pm2

# Start with PM2
pm2 start ecosystem.config.js

# Save PM2 config
pm2 save

# Setup auto-start on reboot
pm2 startup
```

### Nginx Reverse Proxy

```nginx
server {
    listen 80;
    server_name gateway.yourdomain.com;

    location / {
        proxy_pass http://localhost:422;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### SSL with Let's Encrypt

```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx

# Get certificate
sudo certbot --nginx -d gateway.yourdomain.com

# Auto-renewal
sudo certbot renew --dry-run
```

## 📊 Monitoring Setup

### Enable Logging

Already configured! Logs go to:
- Console output
- PM2 logs (if using PM2)

View logs:
```bash
# PM2 logs
pm2 logs ai-gateway-enhanced

# Or direct logs
npm start | tee logs/app.log
```

### Health Monitoring

Setup cron job to check health:

```bash
# Add to crontab
*/5 * * * * curl -f http://localhost:422/health || systemctl restart pm2-root
```

## 🔄 Upgrade from v2.0

### Backup First

```bash
# Backup database
cp ./data/gateway.db ./data/gateway.db.backup

# Backup .env
cp .env .env.backup
```

### Migration Steps

```bash
# 1. Pull new code
git pull origin main

# 2. Install new dependencies
npm install

# 3. Run enhanced database init
node src/database/init-enhanced.js

# 4. Restart server
pm2 restart ai-gateway-enhanced
```

**Note:** Database init is idempotent - won't overwrite existing data, only adds new tables.

## 📝 Post-Installation Checklist

- [ ] Changed default admin password
- [ ] Created test user account
- [ ] Configured SMTP (optional)
- [ ] Set strong JWT_SECRET
- [ ] Tested API endpoints
- [ ] Configured rate limits per group
- [ ] Setup SSL (for production)
- [ ] Configured firewall
- [ ] Setup backup cron job
- [ ] Tested webhook delivery
- [ ] Enabled 2FA for admin
- [ ] Reviewed audit logs
- [ ] Setup monitoring

## 🎉 Next Steps

1. **Configure Groups:**
   - Set appropriate rate limits
   - Set monthly quotas
   - Assign models

2. **Create Users:**
   - Assign to appropriate groups
   - Send credentials (auto email)

3. **Enable Features:**
   - Configure SMTP for emails
   - Setup webhooks for monitoring
   - Enable 2FA for security

4. **Monitor:**
   - Check dashboard regularly
   - Review audit logs
   - Monitor quota usage
   - Check webhook deliveries

## 📚 Further Reading

- `README-ENHANCED.md` - Main documentation
- `FEATURES-COMPLETE.md` - Complete feature list
- `API-REFERENCE.md` - API documentation
- `/admin.html` - Admin dashboard (try it!)
- `/user.html` - User dashboard (try it!)

## 🆘 Need Help?

1. Check documentation
2. Review examples
3. Check troubleshooting section
4. Contact support

**Installation complete!** 🎉
Your AI Gateway Enhanced v3.0 is ready to use!
