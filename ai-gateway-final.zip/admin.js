const API_URL = window.location.origin;
let authToken = localStorage.getItem('adminToken');
let currentUser = null;
let currentUserId = null;
let currentGroupId = null;
let auditPage = 0;
const auditLimit = 50;

// Check authentication on page load
window.addEventListener('DOMContentLoaded', () => {
    if (authToken) {
        verifyAuth();
    }
});

// ==================== AUTHENTICATION ====================

document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (response.ok) {
            if (data.user.role !== 'admin') {
                showLoginError('Access denied. Admin privileges required.');
                return;
            }

            authToken = data.token;
            currentUser = data.user;
            localStorage.setItem('adminToken', authToken);
            showDashboard();
        } else {
            showLoginError(data.message || 'Login failed');
        }
    } catch (error) {
        showLoginError('Connection error. Please try again.');
    }
});

async function verifyAuth() {
    try {
        const response = await fetch(`${API_URL}/auth/me`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            if (data.user.role !== 'admin') {
                logout();
                return;
            }
            currentUser = data.user;
            showDashboard();
        } else {
            logout();
        }
    } catch (error) {
        console.error('Auth verification failed:', error);
        logout();
    }
}

function showDashboard() {
    document.getElementById('loginContainer').classList.add('hidden');
    document.getElementById('dashboardContainer').classList.remove('hidden');
    document.getElementById('adminName').textContent = currentUser.username;
    
    loadStats();
    loadUsers();
    loadGroups();
}

function showLoginError(message) {
    const errorDiv = document.getElementById('loginError');
    errorDiv.innerHTML = `<div class="alert alert-error">${message}</div>`;
    setTimeout(() => {
        errorDiv.innerHTML = '';
    }, 5000);
}

function logout() {
    localStorage.removeItem('adminToken');
    authToken = null;
    currentUser = null;
    document.getElementById('loginContainer').classList.remove('hidden');
    document.getElementById('dashboardContainer').classList.add('hidden');
}

// ==================== TAB MANAGEMENT ====================

function showTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    event.target.classList.add('active');

    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    document.getElementById(`${tabName}Tab`).classList.add('active');

    // Reload data for the tab
    if (tabName === 'stats') loadStats();
    if (tabName === 'users') loadUsers();
    if (tabName === 'groups') loadGroups();
    if (tabName === 'quota') loadQuota();
    if (tabName === 'audit') loadAuditLogs();
    if (tabName === 'webhooks') loadWebhooks();
    if (tabName === 'settings') loadSettings();
}

// ==================== STATS ====================

async function loadStats() {
    try {
        const response = await fetch(`${API_URL}/admin/stats`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            
            // Update stat cards
            document.getElementById('totalUsers').textContent = data.total_users || 0;
            document.getElementById('totalGroups').textContent = data.total_groups || 0;
            document.getElementById('bannedUsers').textContent = data.banned_users || 0;
            document.getElementById('activeUsers').textContent = data.active_users_7d || 0;
            document.getElementById('requests24h').textContent = data.requests_24h || 0;
            document.getElementById('tokens24h').textContent = formatNumber(data.tokens_24h || 0);

            // Render top users
            if (data.quotaSummary) {
                renderTopUsers(data.quotaSummary);
            }

            // Render recent activity
            if (data.recentActivity) {
                renderRecentActivity(data.recentActivity);
            }
        }
    } catch (error) {
        console.error('Failed to load stats:', error);
    }
}

function renderTopUsers(users) {
    const tbody = document.querySelector('#topUsersTable tbody');
    tbody.innerHTML = users.map(user => {
        const percentage = user.monthly_quota > 0 ? 
            ((user.used / user.monthly_quota) * 100).toFixed(1) : 0;
        return `
            <tr>
                <td>${user.username}</td>
                <td>${user.group_name || '-'}</td>
                <td>${user.total_requests || 0}</td>
                <td>${formatNumber(user.used || 0)}</td>
                <td>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${percentage}%"></div>
                    </div>
                    ${percentage}%
                </td>
            </tr>
        `;
    }).join('');
}

function renderRecentActivity(activities) {
    const tbody = document.querySelector('#recentActivityTable tbody');
    tbody.innerHTML = activities.map(activity => `
        <tr>
            <td>${formatDateTime(activity.created_at)}</td>
            <td>${activity.username || 'System'}</td>
            <td><span class="badge badge-info">${activity.action}</span></td>
            <td>${activity.resource_type || '-'}</td>
        </tr>
    `).join('');
}

// ==================== USER MANAGEMENT ====================

async function loadUsers() {
    try {
        const response = await fetch(`${API_URL}/admin/users`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            renderUsersTable(data.users);
        }
    } catch (error) {
        console.error('Failed to load users:', error);
    }
}

function renderUsersTable(users) {
    const tbody = document.querySelector('#usersTable tbody');
    tbody.innerHTML = users.map(user => `
        <tr>
            <td><strong>${user.username}</strong></td>
            <td>${user.email}</td>
            <td><span class="badge badge-${user.role}">${user.role}</span></td>
            <td>${user.group_name || '-'}</td>
            <td>${user.two_factor_enabled ? '✅' : '❌'}</td>
            <td><span class="badge ${user.is_banned ? 'badge-banned' : 'badge-active'}">
                ${user.is_banned ? 'Banned' : 'Active'}
            </span></td>
            <td>
                <button class="btn btn-info btn-small" onclick="viewUserDetails(${user.id})">View</button>
                <button class="btn btn-primary btn-small" onclick="editUser(${user.id})">Edit</button>
                <button class="btn btn-${user.is_banned ? 'success' : 'warning'} btn-small" 
                        onclick="toggleBan(${user.id}, ${!user.is_banned})">
                    ${user.is_banned ? 'Unban' : 'Ban'}
                </button>
                <button class="btn btn-small" onclick="manageUserDomains(${user.id}, '${user.username}')">Domains</button>
                <button class="btn btn-danger btn-small" onclick="deleteUser(${user.id})">Delete</button>
            </td>
        </tr>
    `).join('');
}

async function viewUserDetails(userId) {
    try {
        const response = await fetch(`${API_URL}/admin/users/${userId}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            const user = data.user;
            const quota = data.quota;
            
            const details = `
User: ${user.username}
Email: ${user.email}
Role: ${user.role}
Group: ${user.group_name || 'None'}
2FA: ${user.two_factor_enabled ? 'Enabled' : 'Disabled'}
Created: ${formatDateTime(user.created_at)}
Last Login: ${formatDateTime(user.last_login)}

Quota:
- Used: ${formatNumber(quota.used)} / ${formatNumber(quota.limit)}
- Remaining: ${formatNumber(quota.remaining)}
- Percentage: ${quota.percentage}%

Domains: ${data.domains.length}
API Keys: ${data.apiKeys.length}
            `;
            
            alert(details);
        }
    } catch (error) {
        alert('Failed to load user details');
    }
}

async function editUser(userId) {
    try {
        const response = await fetch(`${API_URL}/admin/users/${userId}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            const form = document.getElementById('editUserForm');
            form.id.value = data.user.id;
            form.username.value = data.user.username;
            form.email.value = data.user.email;
            form.role.value = data.user.role;
            form.group_id.value = data.user.group_id || '';
            document.getElementById('editUserModal').classList.add('active');
        }
    } catch (error) {
        alert('Failed to load user data');
    }
}

document.getElementById('editUserForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());
    const userId = data.id;
    delete data.id;

    try {
        const response = await fetch(`${API_URL}/admin/users/${userId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            alert('User updated successfully!');
            closeModal('editUserModal');
            loadUsers();
        } else {
            alert('Failed to update user');
        }
    } catch (error) {
        alert('Connection error');
    }
});

async function toggleBan(userId, shouldBan) {
    if (!confirm(`Are you sure you want to ${shouldBan ? 'ban' : 'unban'} this user?`)) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/admin/users/${userId}/ban`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ is_banned: shouldBan })
        });

        if (response.ok) {
            alert(`User ${shouldBan ? 'banned' : 'unbanned'} successfully`);
            loadUsers();
        } else {
            alert('Failed to update user status');
        }
    } catch (error) {
        alert('Connection error');
    }
}

async function deleteUser(userId) {
    if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/admin/users/${userId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            alert('User deleted successfully');
            loadUsers();
        } else {
            alert('Failed to delete user');
        }
    } catch (error) {
        alert('Connection error');
    }
}

function showCreateUserModal() {
    document.getElementById('createUserModal').classList.add('active');
}

document.getElementById('createUserForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());

    try {
        const response = await fetch(`${API_URL}/admin/users`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            alert('User created successfully!');
            closeModal('createUserModal');
            e.target.reset();
            loadUsers();
        } else {
            const error = await response.json();
            alert('Error: ' + (error.message || 'Failed to create user'));
        }
    } catch (error) {
        alert('Connection error');
    }
});

// ==================== USER DOMAINS MANAGEMENT ====================

async function manageUserDomains(userId, username) {
    currentUserId = userId;
    document.getElementById('domainUserName').textContent = username;
    
    try {
        const response = await fetch(`${API_URL}/admin/users/${userId}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            renderUserDomains(data.domains);
            document.getElementById('userDomainsModal').classList.add('active');
        }
    } catch (error) {
        alert('Failed to load domains');
    }
}

function renderUserDomains(domains) {
    const container = document.getElementById('userDomainsList');
    
    if (domains.length === 0) {
        container.innerHTML = '<p style="color: #666;">No domains configured</p>';
        return;
    }
    
    container.innerHTML = `
        <ul class="domain-list">
            ${domains.map(domain => `
                <li class="domain-item">
                    <code>${domain.domain}</code>
                    <button class="btn btn-danger btn-small" onclick="removeUserDomain(${domain.id})">Remove</button>
                </li>
            `).join('')}
        </ul>
    `;
}

async function addUserDomain() {
    const domain = document.getElementById('newDomainInput').value.trim();
    
    if (!domain) {
        alert('Please enter a domain');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/admin/users/${currentUserId}/domains`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ domain })
        });

        if (response.ok) {
            document.getElementById('newDomainInput').value = '';
            manageUserDomains(currentUserId, document.getElementById('domainUserName').textContent);
        } else {
            alert('Failed to add domain');
        }
    } catch (error) {
        alert('Connection error');
    }
}

async function removeUserDomain(domainId) {
    if (!confirm('Remove this domain?')) return;

    try {
        const response = await fetch(`${API_URL}/admin/users/${currentUserId}/domains/${domainId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            manageUserDomains(currentUserId, document.getElementById('domainUserName').textContent);
        } else {
            alert('Failed to remove domain');
        }
    } catch (error) {
        alert('Connection error');
    }
}

// ==================== GROUP MANAGEMENT ====================

async function loadGroups() {
    try {
        const response = await fetch(`${API_URL}/admin/groups`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            renderGroupsTable(data.groups);
            populateGroupSelects(data.groups);
        }
    } catch (error) {
        console.error('Failed to load groups:', error);
    }
}

function renderGroupsTable(groups) {
    const tbody = document.querySelector('#groupsTable tbody');
    tbody.innerHTML = groups.map(group => `
        <tr>
            <td><strong>${group.name}</strong></td>
            <td>${group.description || '-'}</td>
            <td>${group.user_count || 0}</td>
            <td>
                ${group.max_requests_per_minute || 0}/min<br>
                ${group.max_requests_per_hour || 0}/hr<br>
                ${group.max_requests_per_day || 0}/day
            </td>
            <td>${formatNumber(group.monthly_quota || 0)}</td>
            <td>
                <button class="btn btn-primary btn-small" onclick="manageGroupModels(${group.id}, '${group.name}')">Models</button>
                <button class="btn btn-info btn-small" onclick="editGroup(${group.id})">Edit</button>
                <button class="btn btn-danger btn-small" onclick="deleteGroup(${group.id})">Delete</button>
            </td>
        </tr>
    `).join('');
}

function populateGroupSelects(groups) {
    const selects = [
        document.getElementById('createUserGroupSelect'),
        document.getElementById('editUserGroupSelect')
    ];

    selects.forEach(select => {
        if (select) {
            select.innerHTML = '<option value="">Tidak ada grup</option>' +
                groups.map(g => `<option value="${g.id}">${g.name}</option>`).join('');
        }
    });
}

function showCreateGroupModal() {
    document.getElementById('createGroupModal').classList.add('active');
}

document.getElementById('createGroupForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());

    try {
        const response = await fetch(`${API_URL}/admin/groups`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            alert('Group created successfully!');
            closeModal('createGroupModal');
            e.target.reset();
            loadGroups();
        } else {
            const error = await response.json();
            alert('Error: ' + (error.message || 'Failed to create group'));
        }
    } catch (error) {
        alert('Connection error');
    }
});

async function editGroup(groupId) {
    try {
        const response = await fetch(`${API_URL}/admin/groups/${groupId}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            const group = data.group;
            const form = document.getElementById('editGroupForm');
            form.id.value = group.id;
            form.name.value = group.name;
            form.description.value = group.description || '';
            form.max_requests_per_minute.value = group.max_requests_per_minute || 10;
            form.max_requests_per_hour.value = group.max_requests_per_hour || 100;
            form.max_requests_per_day.value = group.max_requests_per_day || 1000;
            form.monthly_quota.value = group.monthly_quota || 100000;
            document.getElementById('editGroupModal').classList.add('active');
        }
    } catch (error) {
        alert('Failed to load group data');
    }
}

document.getElementById('editGroupForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());
    const groupId = data.id;
    delete data.id;

    try {
        const response = await fetch(`${API_URL}/admin/groups/${groupId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            alert('Group updated successfully!');
            closeModal('editGroupModal');
            loadGroups();
        } else {
            alert('Failed to update group');
        }
    } catch (error) {
        alert('Connection error');
    }
});

async function deleteGroup(groupId) {
    if (!confirm('Are you sure you want to delete this group?')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/admin/groups/${groupId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            alert('Group deleted successfully');
            loadGroups();
        } else {
            const error = await response.json();
            alert('Error: ' + (error.message || 'Failed to delete group'));
        }
    } catch (error) {
        alert('Connection error');
    }
}

// ==================== GROUP MODELS MANAGEMENT ====================

async function manageGroupModels(groupId, groupName) {
    currentGroupId = groupId;
    document.getElementById('modelGroupName').textContent = groupName;
    
    try {
        const response = await fetch(`${API_URL}/admin/groups/${groupId}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            renderGroupModels(data.models || []);
            document.getElementById('groupModelsModal').classList.add('active');
        }
    } catch (error) {
        alert('Failed to load models');
    }
}

function renderGroupModels(models) {
    const container = document.getElementById('groupModelsList');
    
    if (models.length === 0) {
        container.innerHTML = '<p style="color: #666;">No models configured</p>';
        return;
    }
    
    container.innerHTML = `
        <div class="model-list">
            ${models.map(model => `
                <div class="model-tag">
                    <span>${model.model_alias} → ${model.model_name}</span>
                    <button onclick="removeGroupModel(${model.id})">×</button>
                </div>
            `).join('')}
        </div>
    `;
}

async function addGroupModel() {
    const alias = document.getElementById('newModelAlias').value.trim();
    const name = document.getElementById('newModelName').value.trim();
    
    if (!alias || !name) {
        alert('Please enter both model alias and name');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/admin/groups/${currentGroupId}/models`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ model_alias: alias, model_name: name })
        });

        if (response.ok) {
            document.getElementById('newModelAlias').value = '';
            document.getElementById('newModelName').value = '';
            manageGroupModels(currentGroupId, document.getElementById('modelGroupName').textContent);
        } else {
            alert('Failed to add model');
        }
    } catch (error) {
        alert('Connection error');
    }
}

async function removeGroupModel(modelId) {
    if (!confirm('Remove this model?')) return;

    try {
        const response = await fetch(`${API_URL}/admin/groups/${currentGroupId}/models/${modelId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            manageGroupModels(currentGroupId, document.getElementById('modelGroupName').textContent);
        } else {
            alert('Failed to remove model');
        }
    } catch (error) {
        alert('Connection error');
    }
}

// ==================== QUOTA MANAGEMENT ====================

async function loadQuota() {
    try {
        const response = await fetch(`${API_URL}/admin/quota/summary`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            renderQuotaTable(data.summary);
        }
    } catch (error) {
        console.error('Failed to load quota:', error);
    }
}

function renderQuotaTable(quotas) {
    const tbody = document.querySelector('#quotaTable tbody');
    tbody.innerHTML = quotas.map(quota => {
        const percentage = quota.monthly_quota > 0 ? 
            ((quota.used / quota.monthly_quota) * 100).toFixed(1) : 0;
        const isWarning = percentage >= 80;
        const isDanger = percentage >= 100;
        
        return `
            <tr>
                <td><strong>${quota.username}</strong></td>
                <td>${quota.group_name || '-'}</td>
                <td>${formatNumber(quota.used)}</td>
                <td>${formatNumber(quota.monthly_quota)}</td>
                <td>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${Math.min(percentage, 100)}%"></div>
                    </div>
                    ${percentage}%
                </td>
                <td>
                    <span class="badge ${isDanger ? 'badge-danger' : isWarning ? 'badge-warning' : 'badge-success'}">
                        ${isDanger ? 'Exceeded' : isWarning ? 'Warning' : 'OK'}
                    </span>
                </td>
                <td>
                    <button class="btn btn-warning btn-small" onclick="resetQuota(${quota.user_id})">Reset</button>
                </td>
            </tr>
        `;
    }).join('');
}

async function resetQuota(userId) {
    if (!confirm('Reset quota for this user?')) return;

    try {
        const response = await fetch(`${API_URL}/admin/users/${userId}/quota/reset`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            alert('Quota reset successfully');
            loadQuota();
        } else {
            alert('Failed to reset quota');
        }
    } catch (error) {
        alert('Connection error');
    }
}

// ==================== AUDIT LOGS ====================

async function loadAuditLogs() {
    const userId = document.getElementById('filterUserId').value;
    const action = document.getElementById('filterAction').value;
    const dateFrom = document.getElementById('filterDateFrom').value;
    const dateTo = document.getElementById('filterDateTo').value;

    const params = new URLSearchParams({
        limit: auditLimit,
        offset: auditPage * auditLimit
    });

    if (userId) params.append('userId', userId);
    if (action) params.append('action', action);
    if (dateFrom) params.append('dateFrom', dateFrom);
    if (dateTo) params.append('dateTo', dateTo);

    try {
        const response = await fetch(`${API_URL}/admin/audit-logs?${params}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            renderAuditTable(data.logs);
            renderAuditPagination(data.total);
        }
    } catch (error) {
        console.error('Failed to load audit logs:', error);
    }
}

function renderAuditTable(logs) {
    const tbody = document.querySelector('#auditTable tbody');
    tbody.innerHTML = logs.map(log => `
        <tr>
            <td>${formatDateTime(log.created_at)}</td>
            <td>${log.username || 'System'}</td>
            <td><span class="badge badge-info">${log.action}</span></td>
            <td>${log.resource_type || '-'} ${log.resource_id || ''}</td>
            <td>${log.ip_address || '-'}</td>
            <td>
                <button class="btn btn-small" onclick="showAuditDetails(${log.id})">View</button>
            </td>
        </tr>
    `).join('');
}

function renderAuditPagination(total) {
    const totalPages = Math.ceil(total / auditLimit);
    const pagination = document.getElementById('auditPagination');
    
    let html = '';
    
    if (auditPage > 0) {
        html += `<button onclick="changePage(${auditPage - 1})">Previous</button>`;
    }
    
    for (let i = 0; i < totalPages && i < 10; i++) {
        html += `<button class="${i === auditPage ? 'active' : ''}" onclick="changePage(${i})">${i + 1}</button>`;
    }
    
    if (auditPage < totalPages - 1) {
        html += `<button onclick="changePage(${auditPage + 1})">Next</button>`;
    }
    
    pagination.innerHTML = html;
}

function changePage(page) {
    auditPage = page;
    loadAuditLogs();
}

async function showAuditDetails(logId) {
    // This would require a new endpoint to get single audit log details
    alert('Audit log details view - implement if needed');
}

async function exportAuditLogs() {
    const userId = document.getElementById('filterUserId').value;
    const action = document.getElementById('filterAction').value;
    const dateFrom = document.getElementById('filterDateFrom').value;
    const dateTo = document.getElementById('filterDateTo').value;

    const params = new URLSearchParams();
    if (userId) params.append('userId', userId);
    if (action) params.append('action', action);
    if (dateFrom) params.append('dateFrom', dateFrom);
    if (dateTo) params.append('dateTo', dateTo);

    window.open(`${API_URL}/admin/audit-logs/export?${params}`, '_blank');
}

// ==================== WEBHOOKS ====================

async function loadWebhooks() {
    try {
        const response = await fetch(`${API_URL}/admin/webhooks`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            renderWebhooksTable(data.webhooks);
        }
    } catch (error) {
        console.error('Failed to load webhooks:', error);
    }
}

function renderWebhooksTable(webhooks) {
    const tbody = document.querySelector('#webhooksTable tbody');
    tbody.innerHTML = webhooks.map(webhook => `
        <tr>
            <td>${webhook.username || 'Unknown'}</td>
            <td><strong>${webhook.name}</strong></td>
            <td><code style="font-size: 12px;">${webhook.url}</code></td>
            <td>${webhook.events.join(', ')}</td>
            <td>
                <span class="badge ${webhook.is_active ? 'badge-active' : 'badge-banned'}">
                    ${webhook.is_active ? 'Active' : 'Disabled'}
                </span>
            </td>
            <td>
                <span class="badge ${webhook.failure_count > 5 ? 'badge-danger' : 'badge-success'}">
                    ${webhook.failure_count || 0}
                </span>
            </td>
            <td>${formatDateTime(webhook.created_at)}</td>
        </tr>
    `).join('');
}

// ==================== SYSTEM SETTINGS ====================

async function loadSettings() {
    try {
        const response = await fetch(`${API_URL}/admin/settings`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            renderSettings(data.settings);
        }
    } catch (error) {
        console.error('Failed to load settings:', error);
    }
}

function renderSettings(settings) {
    const grid = document.getElementById('settingsGrid');
    grid.innerHTML = settings.map(setting => `
        <div class="setting-item">
            <div class="setting-info">
                <h4>${setting.key}</h4>
                <p>${setting.description || 'No description'}</p>
            </div>
            <div>
                <input type="text" id="setting_${setting.key}" value="${setting.value || ''}" 
                       style="padding: 8px; border: 1px solid #ddd; border-radius: 4px; width: 200px;">
                <button class="btn btn-primary btn-small" onclick="updateSetting('${setting.key}')">Save</button>
            </div>
        </div>
    `).join('');
}

async function updateSetting(key) {
    const value = document.getElementById(`setting_${key}`).value;

    try {
        const response = await fetch(`${API_URL}/admin/settings/${key}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ value })
        });

        if (response.ok) {
            alert('Setting updated successfully');
        } else {
            alert('Failed to update setting');
        }
    } catch (error) {
        alert('Connection error');
    }
}

// ==================== UTILITY FUNCTIONS ====================

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

function formatDateTime(dateStr) {
    if (!dateStr) return '-';
    const date = new Date(dateStr);
    return date.toLocaleString('id-ID', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Close modals when clicking outside
window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('active');
    }
});
