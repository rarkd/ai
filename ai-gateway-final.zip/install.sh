#!/bin/bash

# AI Gateway Enhanced - Frontend Installation Script
# This script will backup old files and install new enhanced frontend

set -e

echo "🎉 AI Gateway Enhanced - Frontend Installation"
echo "=============================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if we're in the right directory
if [ ! -d "ai-gateway-enhanced-complete/public" ]; then
    echo -e "${RED}Error: ai-gateway-enhanced-complete/public directory not found!${NC}"
    echo "Please run this script from the parent directory of ai-gateway-enhanced-complete"
    exit 1
fi

PUBLIC_DIR="ai-gateway-enhanced-complete/public"
ENHANCED_DIR="enhanced-frontend"

# Check if enhanced-frontend exists
if [ ! -d "$ENHANCED_DIR" ]; then
    echo -e "${RED}Error: $ENHANCED_DIR directory not found!${NC}"
    echo "Please extract the enhanced-frontend folder first"
    exit 1
fi

echo "📂 Directories found:"
echo "  - Public dir: $PUBLIC_DIR"
echo "  - Enhanced dir: $ENHANCED_DIR"
echo ""

# Create backup directory
BACKUP_DIR="frontend-backup-$(date +%Y%m%d-%H%M%S)"
echo "💾 Creating backup directory: $BACKUP_DIR"
mkdir -p "$BACKUP_DIR"

# Backup old files
echo "📦 Backing up old files..."
if [ -f "$PUBLIC_DIR/admin.html" ]; then
    cp "$PUBLIC_DIR/admin.html" "$BACKUP_DIR/"
    echo "  ✓ Backed up admin.html"
fi

if [ -f "$PUBLIC_DIR/admin.js" ]; then
    cp "$PUBLIC_DIR/admin.js" "$BACKUP_DIR/"
    echo "  ✓ Backed up admin.js"
fi

if [ -f "$PUBLIC_DIR/user.html" ]; then
    cp "$PUBLIC_DIR/user.html" "$BACKUP_DIR/"
    echo "  ✓ Backed up user.html"
fi

if [ -f "$PUBLIC_DIR/user.js" ]; then
    cp "$PUBLIC_DIR/user.js" "$BACKUP_DIR/"
    echo "  ✓ Backed up user.js"
fi

echo ""
echo "🚀 Installing enhanced frontend files..."

# Copy new files
cp "$ENHANCED_DIR/admin.html" "$PUBLIC_DIR/"
echo "  ✓ Installed admin.html (907 lines)"

cp "$ENHANCED_DIR/admin.js" "$PUBLIC_DIR/"
echo "  ✓ Installed admin.js (1,169 lines)"

cp "$ENHANCED_DIR/user.html" "$PUBLIC_DIR/"
echo "  ✓ Installed user.html (779 lines)"

cp "$ENHANCED_DIR/user.js" "$PUBLIC_DIR/"
echo "  ✓ Installed user.js (806 lines)"

echo ""
echo "✅ Installation complete!"
echo ""
echo "📄 Documentation:"
echo "  - README.md: Quick start guide"
echo "  - IMPLEMENTATION-GUIDE.md: Complete feature documentation"
echo "  - COMPARISON.md: Old vs New comparison"
echo ""
echo "🔄 Next steps:"
echo "  1. Restart your server:"
echo "     cd ai-gateway-enhanced-complete"
echo "     npm start"
echo "     (or: pm2 restart ai-gateway)"
echo ""
echo "  2. Access dashboards:"
echo "     Admin: http://localhost:3000/admin.html"
echo "     User:  http://localhost:3000/user.html"
echo ""
echo "  3. Clear browser cache for best experience"
echo ""
echo "💾 Backup location: $BACKUP_DIR"
echo "   (Keep this in case you need to rollback)"
echo ""
echo -e "${GREEN}✨ All done! Enjoy the enhanced features! 🚀${NC}"
