const API_URL = window.location.origin;
let authToken = localStorage.getItem('userToken');
let currentUser = null;
let availableEvents = [];

// Check authentication on page load
window.addEventListener('DOMContentLoaded', () => {
    if (authToken) {
        verifyAuth();
    }
});

// ==================== AUTHENTICATION ====================

document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (response.ok) {
            authToken = data.token;
            currentUser = data.user;
            localStorage.setItem('userToken', authToken);
            showDashboard();
        } else {
            showLoginError(data.message || 'Login failed');
        }
    } catch (error) {
        showLoginError('Connection error. Please try again.');
    }
});

async function verifyAuth() {
    try {
        const response = await fetch(`${API_URL}/auth/me`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            currentUser = data.user;
            showDashboard();
        } else {
            logout();
        }
    } catch (error) {
        console.error('Auth verification failed:', error);
        logout();
    }
}

function showDashboard() {
    document.getElementById('loginContainer').classList.add('hidden');
    document.getElementById('dashboardContainer').classList.remove('hidden');
    document.getElementById('userName').textContent = currentUser.username;
    document.getElementById('userGroup').textContent = currentUser.group_name || 'No Group';
    
    // Set API endpoint
    document.getElementById('apiEndpoint').textContent = `${API_URL}/api/{model}`;
    
    // Load all data
    loadDashboard();
    loadModels();
    loadDomains();
    loadApiKeys();
    load2FAStatus();
    updateExampleCode();
}

function showLoginError(message) {
    const errorDiv = document.getElementById('loginError');
    errorDiv.innerHTML = `<div class="alert alert-error">${message}</div>`;
    setTimeout(() => {
        errorDiv.innerHTML = '';
    }, 5000);
}

function logout() {
    localStorage.removeItem('userToken');
    authToken = null;
    currentUser = null;
    document.getElementById('loginContainer').classList.remove('hidden');
    document.getElementById('dashboardContainer').classList.add('hidden');
}

// ==================== TAB MANAGEMENT ====================

function showTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    event.target.classList.add('active');

    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    document.getElementById(`${tabName}Tab`).classList.add('active');

    // Load data for specific tabs
    if (tabName === 'dashboard') loadDashboard();
    if (tabName === 'webhooks') loadWebhooks();
    if (tabName === 'activity') loadActivity();
}

// ==================== DASHBOARD ====================

async function loadDashboard() {
    await loadQuota();
    await loadUsageStats();
}

async function loadQuota() {
    try {
        const response = await fetch(`${API_URL}/user/quota`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            const quota = data.current;
            
            document.getElementById('quotaUsed').textContent = formatNumber(quota.used);
            document.getElementById('quotaLimit').textContent = formatNumber(quota.limit);
            document.getElementById('quotaRemaining').textContent = formatNumber(quota.remaining) + ' tokens remaining';
            
            const percentage = quota.percentage;
            const progressBar = document.getElementById('quotaProgress');
            progressBar.style.width = Math.min(percentage, 100) + '%';
            progressBar.textContent = percentage.toFixed(1) + '%';
            
            // Change color based on usage
            if (percentage >= 90) {
                progressBar.style.background = '#e74c3c';
            } else if (percentage >= 80) {
                progressBar.style.background = '#f39c12';
            } else {
                progressBar.style.background = 'white';
            }
        }
    } catch (error) {
        console.error('Failed to load quota:', error);
    }
}

async function loadUsageStats() {
    try {
        const response = await fetch(`${API_URL}/user/usage?days=30`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            
            // Calculate stats
            let totalRequests = 0;
            let totalTokens = 0;
            
            data.usage.forEach(item => {
                totalRequests += item.request_count;
                totalTokens += item.total_tokens;
            });
            
            const avgTokens = totalRequests > 0 ? Math.round(totalTokens / totalRequests) : 0;
            
            document.getElementById('totalRequests').textContent = totalRequests;
            document.getElementById('totalTokens').textContent = formatNumber(totalTokens);
            document.getElementById('avgTokens').textContent = avgTokens;
            
            // Render usage table
            renderUsageTable(data.usage);
        }
    } catch (error) {
        console.error('Failed to load usage stats:', error);
    }
}

function renderUsageTable(usage) {
    const tbody = document.querySelector('#usageTable tbody');
    
    if (usage.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: #666;">No usage data yet</td></tr>';
        return;
    }
    
    tbody.innerHTML = usage.slice(0, 10).map(item => `
        <tr>
            <td>${formatDate(item.date)}</td>
            <td><code>${item.model_alias}</code></td>
            <td>${item.request_count}</td>
            <td>${formatNumber(item.total_tokens)}</td>
        </tr>
    `).join('');
}

// ==================== MODELS ====================

async function loadModels() {
    try {
        const response = await fetch(`${API_URL}/user/models`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            
            if (data.models.length === 0) {
                document.getElementById('noGroupAlert').classList.remove('hidden');
                document.getElementById('modelsGrid').innerHTML = '';
            } else {
                document.getElementById('noGroupAlert').classList.add('hidden');
                renderModels(data.models);
            }
        }
    } catch (error) {
        console.error('Failed to load models:', error);
    }
}

function renderModels(models) {
    const grid = document.getElementById('modelsGrid');
    grid.innerHTML = models.map(model => `
        <div class="model-card">
            <h3>${model.model_alias}</h3>
            <p>→ ${model.model_name}</p>
        </div>
    `).join('');
}

function updateExampleCode() {
    const code = `curl -X POST ${API_URL}/api/gpt-4 \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "messages": [
      {"role": "user", "content": "Hello!"}
    ],
    "temperature": 0.7
  }'`;
    
    document.getElementById('exampleCode').textContent = code;
}

// ==================== API KEYS ====================

async function loadApiKeys() {
    try {
        const response = await fetch(`${API_URL}/user/api-keys`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            document.getElementById('apiKeyCount').textContent = data.apiKeys.filter(k => k.is_active).length;
            renderApiKeys(data.apiKeys);
        }
    } catch (error) {
        console.error('Failed to load API keys:', error);
    }
}

function renderApiKeys(keys) {
    const container = document.getElementById('apiKeysList');
    
    if (keys.length === 0) {
        container.innerHTML = '<p style="color: #666;">No API keys yet. Create one to get started!</p>';
        return;
    }
    
    container.innerHTML = keys.map(key => `
        <div class="api-key-item">
            <div class="api-key-info">
                <strong>${key.name}</strong><br>
                <code>${key.key_prefix}...</code><br>
                <small style="color: #666;">
                    Created: ${formatDateTime(key.created_at)}
                    ${key.last_used ? ` | Last used: ${formatDateTime(key.last_used)}` : ''}
                </small>
            </div>
            <div>
                <span class="badge ${key.is_active ? 'badge-active' : 'badge-inactive'}">
                    ${key.is_active ? 'Active' : 'Inactive'}
                </span>
                <button class="btn btn-danger btn-small" onclick="deleteApiKey(${key.id}, '${key.name}')" style="margin-left: 10px;">Delete</button>
            </div>
        </div>
    `).join('');
}

function showCreateKeyModal() {
    document.getElementById('createKeyModal').classList.add('active');
}

document.getElementById('createKeyForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());

    try {
        const response = await fetch(`${API_URL}/user/api-keys`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            const result = await response.json();
            closeModal('createKeyModal');
            e.target.reset();
            
            // Show the new API key
            document.getElementById('newApiKey').textContent = result.apiKey;
            document.getElementById('showKeyModal').classList.add('active');
            
            loadApiKeys();
        } else {
            const error = await response.json();
            alert('Error: ' + (error.message || 'Failed to create API key'));
        }
    } catch (error) {
        alert('Connection error');
    }
});

async function deleteApiKey(keyId, keyName) {
    if (!confirm(`Delete API key "${keyName}"? This action cannot be undone.`)) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/user/api-keys/${keyId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            alert('API key deleted successfully');
            loadApiKeys();
        } else {
            alert('Failed to delete API key');
        }
    } catch (error) {
        alert('Connection error');
    }
}

// ==================== DOMAINS ====================

async function loadDomains() {
    try {
        const response = await fetch(`${API_URL}/user/domains`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            renderDomains(data.domains);
        }
    } catch (error) {
        console.error('Failed to load domains:', error);
    }
}

function renderDomains(domains) {
    const list = document.getElementById('domainsList');
    
    if (domains.length === 0) {
        list.innerHTML = '<li class="domain-item"><em>No domains configured yet</em></li>';
        return;
    }
    
    list.innerHTML = domains.map(domain => `
        <li class="domain-item">
            <code>${domain.domain}</code>
            <button class="btn btn-danger btn-small" onclick="deleteDomain(${domain.id})">Delete</button>
        </li>
    `).join('');
}

async function addDomain() {
    const domain = document.getElementById('newDomainInput').value.trim();
    
    if (!domain) {
        alert('Please enter a domain');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/user/domains`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ domain })
        });

        if (response.ok) {
            document.getElementById('newDomainInput').value = '';
            loadDomains();
        } else {
            const error = await response.json();
            alert('Error: ' + (error.message || 'Failed to add domain'));
        }
    } catch (error) {
        alert('Connection error');
    }
}

async function deleteDomain(domainId) {
    if (!confirm('Delete this domain?')) return;

    try {
        const response = await fetch(`${API_URL}/user/domains/${domainId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            loadDomains();
        } else {
            alert('Failed to delete domain');
        }
    } catch (error) {
        alert('Connection error');
    }
}

// ==================== WEBHOOKS ====================

async function loadWebhooks() {
    try {
        // Load available events first
        const eventsResponse = await fetch(`${API_URL}/user/webhooks/events/available`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        
        if (eventsResponse.ok) {
            const eventsData = await eventsResponse.json();
            availableEvents = eventsData.events;
        }

        // Load user's webhooks
        const response = await fetch(`${API_URL}/user/webhooks`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            renderWebhooks(data.webhooks);
        }
    } catch (error) {
        console.error('Failed to load webhooks:', error);
    }
}

function renderWebhooks(webhooks) {
    const container = document.getElementById('webhooksList');
    
    if (webhooks.length === 0) {
        container.innerHTML = '<p style="color: #666;">No webhooks configured. Create one to receive notifications!</p>';
        return;
    }
    
    container.innerHTML = webhooks.map(webhook => `
        <div class="webhook-item">
            <div class="webhook-header">
                <div>
                    <strong>${webhook.name}</strong>
                    <span class="badge ${webhook.is_active ? 'badge-active' : 'badge-inactive'}" style="margin-left: 10px;">
                        ${webhook.is_active ? 'Active' : 'Disabled'}
                    </span>
                </div>
                <div>
                    <button class="btn btn-small" onclick="testWebhook(${webhook.id})">Test</button>
                    <button class="btn btn-danger btn-small" onclick="deleteWebhook(${webhook.id})">Delete</button>
                </div>
            </div>
            <div>
                <code style="font-size: 12px;">${webhook.url}</code>
                <div class="webhook-events">
                    ${webhook.events.map(event => `<span class="event-badge">${event}</span>`).join('')}
                </div>
            </div>
            <div style="margin-top: 10px; font-size: 12px; color: #666;">
                Failures: ${webhook.failure_count || 0} | 
                Created: ${formatDateTime(webhook.created_at)}
            </div>
        </div>
    `).join('');
}

function showCreateWebhookModal() {
    // Populate events checkboxes
    const eventsContainer = document.getElementById('webhookEvents');
    eventsContainer.innerHTML = availableEvents.map(event => `
        <div class="checkbox-item">
            <input type="checkbox" id="event_${event}" name="events" value="${event}">
            <label for="event_${event}">${event}</label>
        </div>
    `).join('');
    
    document.getElementById('createWebhookModal').classList.add('active');
}

document.getElementById('createWebhookForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const events = Array.from(formData.getAll('events'));
    
    if (events.length === 0) {
        alert('Please select at least one event');
        return;
    }
    
    const data = {
        name: formData.get('name'),
        url: formData.get('url'),
        events: events
    };

    try {
        const response = await fetch(`${API_URL}/user/webhooks`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            alert('Webhook created successfully!');
            closeModal('createWebhookModal');
            e.target.reset();
            loadWebhooks();
        } else {
            const error = await response.json();
            alert('Error: ' + (error.message || 'Failed to create webhook'));
        }
    } catch (error) {
        alert('Connection error');
    }
});

async function testWebhook(webhookId) {
    try {
        const response = await fetch(`${API_URL}/user/webhooks/${webhookId}/test`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        const data = await response.json();
        
        if (response.ok) {
            alert(`Webhook test successful!\n\nStatus: ${data.status}\nResponse Time: ${data.responseTime}ms`);
        } else {
            alert(`Webhook test failed: ${data.error}`);
        }
    } catch (error) {
        alert('Connection error');
    }
}

async function deleteWebhook(webhookId) {
    if (!confirm('Delete this webhook?')) return;

    try {
        const response = await fetch(`${API_URL}/user/webhooks/${webhookId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            alert('Webhook deleted successfully');
            loadWebhooks();
        } else {
            alert('Failed to delete webhook');
        }
    } catch (error) {
        alert('Connection error');
    }
}

// ==================== TWO-FACTOR AUTHENTICATION ====================

async function load2FAStatus() {
    try {
        const response = await fetch(`${API_URL}/user/2fa/status`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            render2FAStatus(data);
        }
    } catch (error) {
        console.error('Failed to load 2FA status:', error);
    }
}

function render2FAStatus(status) {
    const container = document.getElementById('2faStatus');
    
    if (status.enabled) {
        container.innerHTML = `
            <div class="alert alert-success">
                ✅ Two-Factor Authentication is ENABLED
            </div>
            <p style="margin-top: 15px;">Your account is protected with 2FA.</p>
            <button class="btn btn-danger" onclick="disable2FA()" style="margin-top: 15px;">Disable 2FA</button>
        `;
    } else {
        container.innerHTML = `
            <div class="alert alert-warning">
                ⚠️ Two-Factor Authentication is DISABLED
            </div>
            <p style="margin-top: 15px;">Enable 2FA to add an extra layer of security to your account.</p>
            <button class="btn btn-success" onclick="setup2FA()" style="margin-top: 15px;">Enable 2FA</button>
        `;
    }
}

async function setup2FA() {
    try {
        const response = await fetch(`${API_URL}/user/2fa/setup`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            show2FASetup(data);
        } else {
            alert('Failed to setup 2FA');
        }
    } catch (error) {
        alert('Connection error');
    }
}

function show2FASetup(data) {
    const content = document.getElementById('2faSetupContent');
    content.innerHTML = `
        <div class="alert alert-warning">
            ⚠️ Save your secret key in a safe place!
        </div>
        
        <div class="qr-code-container">
            <img src="${data.qrCode}" alt="QR Code">
        </div>
        
        <div style="margin-top: 20px;">
            <p><strong>Manual Entry Code:</strong></p>
            <div class="code-block">${data.secret}</div>
        </div>
        
        <div style="margin-top: 20px;">
            <h3>Verify Setup</h3>
            <p>Enter the 6-digit code from your authenticator app:</p>
            <div class="form-group">
                <input type="text" id="2faVerifyCode" placeholder="000000" maxlength="6" pattern="[0-9]{6}">
            </div>
            <button class="btn btn-success" onclick="enable2FA('${data.secret}')">Enable 2FA</button>
            <button class="btn" onclick="closeModal('setup2faModal')">Cancel</button>
        </div>
    `;
    
    document.getElementById('setup2faModal').classList.add('active');
}

async function enable2FA(secret) {
    const token = document.getElementById('2faVerifyCode').value;
    
    if (!token || token.length !== 6) {
        alert('Please enter a valid 6-digit code');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/user/2fa/enable`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ secret, token })
        });

        const data = await response.json();
        
        if (response.ok) {
            alert('2FA enabled successfully!');
            closeModal('setup2faModal');
            load2FAStatus();
        } else {
            alert('Error: ' + (data.message || 'Invalid code'));
        }
    } catch (error) {
        alert('Connection error');
    }
}

async function disable2FA() {
    const token = prompt('Enter your current 2FA code to disable:');
    
    if (!token) return;

    try {
        const response = await fetch(`${API_URL}/user/2fa/disable`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ token })
        });

        const data = await response.json();
        
        if (response.ok) {
            alert('2FA disabled successfully');
            load2FAStatus();
        } else {
            alert('Error: ' + (data.message || 'Invalid code'));
        }
    } catch (error) {
        alert('Connection error');
    }
}

// ==================== ACTIVITY LOG ====================

async function loadActivity() {
    try {
        const response = await fetch(`${API_URL}/user/activity?days=30`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            renderActivity(data.activity);
        }
    } catch (error) {
        console.error('Failed to load activity:', error);
    }
}

function renderActivity(activities) {
    const tbody = document.querySelector('#activityTable tbody');
    
    if (activities.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: #666;">No activity yet</td></tr>';
        return;
    }
    
    tbody.innerHTML = activities.map(activity => `
        <tr>
            <td>${formatDateTime(activity.created_at)}</td>
            <td><span class="badge badge-active">${activity.action}</span></td>
            <td>${activity.resource_type || '-'} ${activity.resource_id || ''}</td>
            <td>${activity.ip_address || '-'}</td>
        </tr>
    `).join('');
}

// ==================== CHANGE PASSWORD ====================

document.getElementById('changePasswordForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const currentPassword = formData.get('currentPassword');
    const newPassword = formData.get('newPassword');
    const confirmPassword = formData.get('confirmPassword');
    
    if (newPassword !== confirmPassword) {
        alert('New passwords do not match!');
        return;
    }
    
    if (newPassword.length < 6) {
        alert('Password must be at least 6 characters');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/auth/change-password`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ currentPassword, newPassword })
        });

        if (response.ok) {
            alert('Password changed successfully!');
            e.target.reset();
        } else {
            const error = await response.json();
            alert('Error: ' + (error.message || 'Failed to change password'));
        }
    } catch (error) {
        alert('Connection error');
    }
});

// ==================== UTILITY FUNCTIONS ====================

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

function formatDateTime(dateStr) {
    if (!dateStr) return '-';
    const date = new Date(dateStr);
    return date.toLocaleString('id-ID', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatDate(dateStr) {
    if (!dateStr) return '-';
    const date = new Date(dateStr);
    return date.toLocaleDateString('id-ID', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert('Copied to clipboard!');
    }).catch(() => {
        alert('Failed to copy. Please copy manually.');
    });
}

// Close modals when clicking outside
window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('active');
    }
});
