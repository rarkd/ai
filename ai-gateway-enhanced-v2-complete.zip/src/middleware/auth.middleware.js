const jwt = require('jsonwebtoken');
const db = require('../database/db');
require('dotenv').config();

const JWT_SECRET = process.env.JWT_SECRET || 'change-this-secret-key';

// Verify JWT token
async function authenticateToken(req, res, next) {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
      return res.status(401).json({ 
        error: 'Access denied', 
        message: 'No token provided' 
      });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    
    // Get user from database
    const user = await db.get(
      'SELECT id, username, email, role, group_id, is_banned FROM users WHERE id = ?',
      [decoded.userId]
    );

    if (!user) {
      return res.status(401).json({ 
        error: 'Invalid token', 
        message: 'User not found' 
      });
    }

    if (user.is_banned) {
      return res.status(403).json({ 
        error: 'Access denied', 
        message: 'User account is banned' 
      });
    }

    req.user = user;
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ 
        error: 'Token expired', 
        message: 'Please login again' 
      });
    }
    return res.status(403).json({ 
      error: 'Invalid token', 
      message: error.message 
    });
  }
}

// Check if user is admin
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ 
      error: 'Access denied', 
      message: 'Admin privileges required' 
    });
  }
  next();
}

// Check if user has group assigned
function requireGroup(req, res, next) {
  if (!req.user || !req.user.group_id) {
    return res.status(403).json({ 
      error: 'Access denied', 
      message: 'User must be assigned to a group' 
    });
  }
  next();
}

// Authenticate via API key
async function authenticateApiKey(req, res, next) {
  try {
    const apiKey = req.headers['x-api-key'];
    
    if (!apiKey) {
      return res.status(401).json({ 
        error: 'Access denied', 
        message: 'No API key provided' 
      });
    }

    // API keys format: gw_xxxxxxxxxxxxxxxx
    if (!apiKey.startsWith('gw_')) {
      return res.status(401).json({ 
        error: 'Invalid API key format' 
      });
    }

    const bcrypt = require('bcryptjs');
    
    // Get all API keys for this prefix (first 10 chars)
    const prefix = apiKey.substring(0, 10);
    const keys = await db.all(
      `SELECT ak.*, u.username, u.email, u.role, u.group_id, u.is_banned 
       FROM api_keys ak
       JOIN users u ON ak.user_id = u.id
       WHERE ak.key_prefix = ?`,
      [prefix]
    );

    let validKey = null;
    for (const key of keys) {
      if (await bcrypt.compare(apiKey, key.key_hash)) {
        validKey = key;
        break;
      }
    }

    if (!validKey) {
      return res.status(401).json({ 
        error: 'Invalid API key' 
      });
    }

    if (validKey.is_banned) {
      return res.status(403).json({ 
        error: 'Access denied', 
        message: 'User account is banned' 
      });
    }

    // Update last used
    await db.run(
      'UPDATE api_keys SET last_used = CURRENT_TIMESTAMP WHERE id = ?',
      [validKey.id]
    );

    req.user = {
      id: validKey.user_id,
      username: validKey.username,
      email: validKey.email,
      role: validKey.role,
      group_id: validKey.group_id,
      is_banned: validKey.is_banned
    };
    
    next();
  } catch (error) {
    console.error('[Auth] API key error:', error);
    return res.status(500).json({ 
      error: 'Authentication error' 
    });
  }
}

// Flexible auth - try JWT first, then API key
async function authenticate(req, res, next) {
  const hasToken = req.headers['authorization'];
  const hasApiKey = req.headers['x-api-key'];

  if (hasToken) {
    return authenticateToken(req, res, next);
  } else if (hasApiKey) {
    return authenticateApiKey(req, res, next);
  } else {
    return res.status(401).json({ 
      error: 'Access denied', 
      message: 'No authentication provided' 
    });
  }
}

module.exports = {
  authenticateToken,
  authenticateApiKey,
  authenticate,
  requireAdmin,
  requireGroup
};
