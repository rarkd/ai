const db = require('../database/db');

// Dynamic CORS middleware that checks user's allowed domains
async function dynamicCors(req, res, next) {
  const origin = req.headers.origin;
  
  // If no origin (like server-to-server), allow
  if (!origin) {
    return next();
  }

  try {
    // Extract domain from origin
    const originUrl = new URL(origin);
    const domain = originUrl.hostname;

    // Check if this origin is allowed for the authenticated user
    if (req.user && req.user.id) {
      const allowedDomain = await db.get(
        'SELECT * FROM user_domains WHERE user_id = ? AND domain = ?',
        [req.user.id, domain]
      );

      if (allowedDomain) {
        res.setHeader('Access-Control-Allow-Origin', origin);
        res.setHeader('Access-Control-Allow-Credentials', 'true');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-API-Key');
        
        // Handle preflight
        if (req.method === 'OPTIONS') {
          return res.status(200).end();
        }
        
        return next();
      } else {
        console.log(`[CORS] Domain ${domain} not allowed for user ${req.user.username}`);
        return res.status(403).json({
          error: 'CORS not allowed',
          message: `Domain ${domain} is not in your allowed domains list`
        });
      }
    }

    // For unauthenticated requests, deny CORS
    return res.status(401).json({
      error: 'Authentication required',
      message: 'Please authenticate to access this resource'
    });

  } catch (error) {
    console.error('[CORS] Error checking domain:', error);
    return res.status(500).json({
      error: 'CORS check failed',
      message: error.message
    });
  }
}

// Allow CORS for public endpoints (login, register, health)
function publicCors(req, res, next) {
  const origin = req.headers.origin;
  
  if (origin) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-API-Key');
    
    if (req.method === 'OPTIONS') {
      return res.status(200).end();
    }
  }
  
  next();
}

module.exports = {
  dynamicCors,
  publicCors
};
