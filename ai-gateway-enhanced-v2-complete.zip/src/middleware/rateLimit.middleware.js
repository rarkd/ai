const db = require('../database/db');

/**
 * Rate limiting middleware based on user's group limits
 */
async function rateLimitMiddleware(req, res, next) {
  try {
    const userId = req.user.id;
    const userGroupId = req.user.group_id;

    // Get group limits
    const group = await db.get(
      'SELECT max_requests_per_hour, max_requests_per_day FROM groups WHERE id = ?',
      [userGroupId]
    );

    if (!group) {
      return res.status(500).json({ error: 'Group configuration not found' });
    }

    const now = new Date();
    
    // Check hourly limit
    const hourStart = new Date(now);
    hourStart.setMinutes(0, 0, 0);
    
    let hourlyRecord = await db.get(
      `SELECT * FROM rate_limits 
       WHERE user_id = ? AND window_type = 'hour' 
       AND window_start = ?`,
      [userId, hourStart.toISOString()]
    );

    if (!hourlyRecord) {
      // Create new hourly record
      await db.run(
        `INSERT INTO rate_limits (user_id, window_start, window_type, request_count)
         VALUES (?, ?, 'hour', 1)`,
        [userId, hourStart.toISOString()]
      );
    } else if (hourlyRecord.request_count >= group.max_requests_per_hour) {
      const resetTime = new Date(hourStart);
      resetTime.setHours(resetTime.getHours() + 1);
      
      return res.status(429).json({
        error: 'Hourly rate limit exceeded',
        limit: group.max_requests_per_hour,
        reset_at: resetTime.toISOString()
      });
    } else {
      // Increment hourly count
      await db.run(
        `UPDATE rate_limits 
         SET request_count = request_count + 1, updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`,
        [hourlyRecord.id]
      );
    }

    // Check daily limit
    const dayStart = new Date(now);
    dayStart.setHours(0, 0, 0, 0);
    
    let dailyRecord = await db.get(
      `SELECT * FROM rate_limits 
       WHERE user_id = ? AND window_type = 'day' 
       AND window_start = ?`,
      [userId, dayStart.toISOString()]
    );

    if (!dailyRecord) {
      // Create new daily record
      await db.run(
        `INSERT INTO rate_limits (user_id, window_start, window_type, request_count)
         VALUES (?, ?, 'day', 1)`,
        [userId, dayStart.toISOString()]
      );
    } else if (dailyRecord.request_count >= group.max_requests_per_day) {
      const resetTime = new Date(dayStart);
      resetTime.setDate(resetTime.getDate() + 1);
      
      return res.status(429).json({
        error: 'Daily rate limit exceeded',
        limit: group.max_requests_per_day,
        reset_at: resetTime.toISOString()
      });
    } else {
      // Increment daily count
      await db.run(
        `UPDATE rate_limits 
         SET request_count = request_count + 1, updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`,
        [dailyRecord.id]
      );
    }

    // Add rate limit info to response headers
    res.setHeader('X-RateLimit-Limit-Hour', group.max_requests_per_hour);
    res.setHeader('X-RateLimit-Remaining-Hour', 
      group.max_requests_per_hour - (hourlyRecord ? hourlyRecord.request_count : 0) - 1);
    res.setHeader('X-RateLimit-Limit-Day', group.max_requests_per_day);
    res.setHeader('X-RateLimit-Remaining-Day', 
      group.max_requests_per_day - (dailyRecord ? dailyRecord.request_count : 0) - 1);

    next();
  } catch (error) {
    console.error('[Rate Limit] Error:', error);
    next(); // Continue even if rate limiting fails
  }
}

/**
 * Get rate limit status for a user
 */
async function getRateLimitStatus(userId) {
  try {
    const user = await db.get('SELECT group_id FROM users WHERE id = ?', [userId]);
    if (!user) return null;

    const group = await db.get(
      'SELECT max_requests_per_hour, max_requests_per_day FROM groups WHERE id = ?',
      [user.group_id]
    );

    const now = new Date();
    const hourStart = new Date(now);
    hourStart.setMinutes(0, 0, 0);
    const dayStart = new Date(now);
    dayStart.setHours(0, 0, 0, 0);

    const hourlyRecord = await db.get(
      `SELECT request_count FROM rate_limits 
       WHERE user_id = ? AND window_type = 'hour' 
       AND window_start = ?`,
      [userId, hourStart.toISOString()]
    );

    const dailyRecord = await db.get(
      `SELECT request_count FROM rate_limits 
       WHERE user_id = ? AND window_type = 'day' 
       AND window_start = ?`,
      [userId, dayStart.toISOString()]
    );

    return {
      hourly: {
        limit: group.max_requests_per_hour,
        used: hourlyRecord ? hourlyRecord.request_count : 0,
        remaining: group.max_requests_per_hour - (hourlyRecord ? hourlyRecord.request_count : 0),
        reset_at: new Date(hourStart.getTime() + 3600000).toISOString()
      },
      daily: {
        limit: group.max_requests_per_day,
        used: dailyRecord ? dailyRecord.request_count : 0,
        remaining: group.max_requests_per_day - (dailyRecord ? dailyRecord.request_count : 0),
        reset_at: new Date(dayStart.getTime() + 86400000).toISOString()
      }
    };
  } catch (error) {
    console.error('[Rate Limit Status] Error:', error);
    return null;
  }
}

/**
 * Cleanup old rate limit records (run periodically)
 */
async function cleanupOldRateLimits() {
  try {
    const twoDaysAgo = new Date();
    twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);
    
    await db.run(
      'DELETE FROM rate_limits WHERE window_start < ?',
      [twoDaysAgo.toISOString()]
    );
    
    console.log('[Rate Limit] Cleanup completed');
  } catch (error) {
    console.error('[Rate Limit Cleanup] Error:', error);
  }
}

module.exports = {
  rateLimitMiddleware,
  getRateLimitStatus,
  cleanupOldRateLimits
};
