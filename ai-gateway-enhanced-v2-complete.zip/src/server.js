const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
require('dotenv').config();

const db = require('./database/db');
const { publicCors } = require('./middleware/cors.middleware');

// Import routes
const authRoutes = require('./routes/auth.routes');
const adminRoutes = require('./routes/admin.routes');
const userRoutes = require('./routes/user.routes');
const gatewayRoutes = require('./routes/gateway.routes');

const app = express();
const PORT = process.env.PORT || 422;

// Connect to database
db.connect()
  .then(() => console.log('[Server] Database connected'))
  .catch(err => {
    console.error('[Server] Database connection failed:', err);
    process.exit(1);
  });

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Logging middleware
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${req.method} ${req.path}`);
  next();
});

// Public CORS for auth and health endpoints
app.use(['/auth', '/health'], publicCors);

// Serve static files (Web UI) - Admin and User dashboards
app.use(express.static(path.join(__dirname, '../public')));

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'AI Gateway Enhanced',
    timestamp: new Date().toISOString(),
    version: '2.0.0'
  });
});

// API Routes
app.use('/auth', authRoutes);         // Authentication endpoints
app.use('/admin', adminRoutes);        // Admin management endpoints
app.use('/user', userRoutes);          // User self-service endpoints
app.use('/api', gatewayRoutes);        // AI Gateway endpoints

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Endpoint not found',
    path: req.path,
    method: req.method
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error('[Server Error]:', err);
  res.status(500).json({
    error: 'Internal server error',
    message: err.message
  });
});

// Start server
app.listen(PORT, () => {
  console.log('=================================');
  console.log('🚀 AI Gateway Enhanced Started');
  console.log('=================================');
  console.log(`📡 Server running on: http://localhost:${PORT}`);
  console.log(`🌐 Admin Dashboard: http://localhost:${PORT}/admin.html`);
  console.log(`👤 User Dashboard: http://localhost:${PORT}/user.html`);
  console.log(`🔗 Ollama endpoint: ${process.env.OLLAMA_BASE_URL || 'https://aiapi.awwlk.my.id'}`);
  console.log('=================================');
  console.log('');
  console.log('🔐 Authentication Endpoints:');
  console.log(`  POST /auth/login              - Login`);
  console.log(`  POST /auth/register           - Register (admin only)`);
  console.log(`  GET  /auth/me                 - Get current user`);
  console.log(`  POST /auth/change-password    - Change password`);
  console.log('');
  console.log('👨‍💼 Admin Endpoints:');
  console.log(`  GET  /admin/users             - List users`);
  console.log(`  POST /admin/users             - Create user`);
  console.log(`  PUT  /admin/users/:id         - Update user`);
  console.log(`  DELETE /admin/users/:id       - Delete user`);
  console.log(`  PATCH /admin/users/:id/ban    - Ban/unban user`);
  console.log(`  GET  /admin/groups            - List groups`);
  console.log(`  POST /admin/groups            - Create group`);
  console.log(`  GET  /admin/stats             - Dashboard stats`);
  console.log('');
  console.log('👤 User Endpoints:');
  console.log(`  GET  /user/models             - Get available models`);
  console.log(`  GET  /user/domains            - Get allowed domains`);
  console.log(`  POST /user/domains            - Add domain`);
  console.log(`  GET  /user/api-keys           - Get API keys`);
  console.log(`  POST /user/api-keys           - Create API key`);
  console.log('');
  console.log('🤖 AI Gateway:');
  console.log(`  POST /api/:model              - AI request (authenticated)`);
  console.log(`  GET  /api/models/available    - List available models`);
  console.log('=================================');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully...');
  db.close().then(() => {
    console.log('Database connection closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('\nSIGINT received, shutting down gracefully...');
  db.close().then(() => {
    console.log('Database connection closed');
    process.exit(0);
  });
});

module.exports = app;
