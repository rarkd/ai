const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const db = require('../database/db');
const { authenticateToken } = require('../middleware/auth.middleware');
const { AuditLogger, UsageAnalytics } = require('../utils/analytics');
const { WebhookManager, DataExporter } = require('../utils/helpers');
const { getRateLimitStatus } = require('../middleware/rateLimit.middleware');

/**
 * GET /user/profile - Get current user profile
 */
router.get('/profile', authenticateToken, async (req, res) => {
  try {
    const user = await db.get(
      `SELECT u.id, u.username, u.email, u.role, u.group_id, u.created_at, u.last_login,
              g.name as group_name, g.max_requests_per_hour, g.max_requests_per_day, 
              g.max_tokens_per_request
       FROM users u
       LEFT JOIN groups g ON u.group_id = g.id
       WHERE u.id = ?`,
      [req.user.id]
    );

    // Get rate limit status
    const rateLimits = await getRateLimitStatus(req.user.id);

    res.json({
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        group: {
          id: user.group_id,
          name: user.group_name,
          limits: {
            max_requests_per_hour: user.max_requests_per_hour,
            max_requests_per_day: user.max_requests_per_day,
            max_tokens_per_request: user.max_tokens_per_request
          }
        },
        created_at: user.created_at,
        last_login: user.last_login
      },
      rate_limits: rateLimits
    });
  } catch (error) {
    console.error('[User] Get profile error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * GET /user/models - Get available models
 */
router.get('/models', authenticateToken, async (req, res) => {
  try {
    const userGroupId = req.user.group_id;

    if (!userGroupId) {
      return res.json({ models: [] });
    }

    const models = await db.all(
      `SELECT gm.model_alias, gm.model_name, mm.description
       FROM group_models gm
       LEFT JOIN model_mappings mm ON gm.model_alias = mm.alias
       WHERE gm.group_id = ?
       ORDER BY gm.model_alias`,
      [userGroupId]
    );

    res.json({ models });
  } catch (error) {
    console.error('[User] Get models error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * GET /user/domains - Get user's CORS domains
 */
router.get('/domains', authenticateToken, async (req, res) => {
  try {
    const domains = await db.all(
      'SELECT * FROM user_domains WHERE user_id = ? ORDER BY created_at DESC',
      [req.user.id]
    );

    res.json({ domains });
  } catch (error) {
    console.error('[User] Get domains error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * POST /user/domains - Add CORS domain
 */
router.post('/domains', authenticateToken, async (req, res) => {
  try {
    const { domain } = req.body;

    if (!domain) {
      return res.status(400).json({ error: 'Domain is required' });
    }

    // Validate domain format
    const domainRegex = /^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i;
    if (!domainRegex.test(domain) && domain !== 'localhost' && !domain.startsWith('localhost:')) {
      return res.status(400).json({ error: 'Invalid domain format' });
    }

    const result = await db.run(
      'INSERT INTO user_domains (user_id, domain) VALUES (?, ?)',
      [req.user.id, domain]
    );

    await AuditLogger.log({
      userId: req.user.id,
      action: 'domain.added',
      entityType: 'domain',
      entityId: result.id,
      details: { domain },
      ipAddress: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({
      message: 'Domain added successfully',
      domain: { id: result.id, domain, user_id: req.user.id }
    });
  } catch (error) {
    if (error.message.includes('UNIQUE constraint')) {
      res.status(400).json({ error: 'Domain already exists' });
    } else {
      console.error('[User] Add domain error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }
});

/**
 * DELETE /user/domains/:id - Remove CORS domain
 */
router.delete('/domains/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    const domain = await db.get(
      'SELECT * FROM user_domains WHERE id = ? AND user_id = ?',
      [id, req.user.id]
    );

    if (!domain) {
      return res.status(404).json({ error: 'Domain not found' });
    }

    await db.run('DELETE FROM user_domains WHERE id = ?', [id]);

    await AuditLogger.log({
      userId: req.user.id,
      action: 'domain.deleted',
      entityType: 'domain',
      entityId: id,
      details: { domain: domain.domain },
      ipAddress: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({ message: 'Domain deleted successfully' });
  } catch (error) {
    console.error('[User] Delete domain error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * GET /user/api-keys - Get user's API keys
 */
router.get('/api-keys', authenticateToken, async (req, res) => {
  try {
    const apiKeys = await db.all(
      `SELECT id, key_prefix, name, created_at, last_used, expires_at, is_active 
       FROM api_keys 
       WHERE user_id = ? 
       ORDER BY created_at DESC`,
      [req.user.id]
    );

    res.json({ api_keys: apiKeys });
  } catch (error) {
    console.error('[User] Get API keys error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * POST /user/api-keys - Create new API key
 */
router.post('/api-keys', authenticateToken, async (req, res) => {
  try {
    const { name, expires_in_days = null } = req.body;

    // Generate API key
    const apiKey = 'gw_' + crypto.randomBytes(32).toString('hex');
    const keyHash = crypto.createHash('sha256').update(apiKey).digest('hex');
    const keyPrefix = apiKey.substring(0, 12);

    let expiresAt = null;
    if (expires_in_days) {
      expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + expires_in_days);
    }

    const result = await db.run(
      `INSERT INTO api_keys (user_id, key_hash, key_prefix, name, expires_at)
       VALUES (?, ?, ?, ?, ?)`,
      [req.user.id, keyHash, keyPrefix, name || 'Unnamed Key', expiresAt?.toISOString() || null]
    );

    await AuditLogger.log({
      userId: req.user.id,
      action: 'api_key.created',
      entityType: 'api_key',
      entityId: result.id,
      details: { name, key_prefix: keyPrefix },
      ipAddress: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({
      message: 'API key created successfully',
      api_key: apiKey,
      warning: 'Save this key securely. You will not be able to see it again.',
      key_info: {
        id: result.id,
        key_prefix: keyPrefix,
        name: name || 'Unnamed Key',
        expires_at: expiresAt?.toISOString() || null
      }
    });
  } catch (error) {
    console.error('[User] Create API key error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * DELETE /user/api-keys/:id - Delete API key
 */
router.delete('/api-keys/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    const apiKey = await db.get(
      'SELECT * FROM api_keys WHERE id = ? AND user_id = ?',
      [id, req.user.id]
    );

    if (!apiKey) {
      return res.status(404).json({ error: 'API key not found' });
    }

    await db.run('DELETE FROM api_keys WHERE id = ?', [id]);

    await AuditLogger.log({
      userId: req.user.id,
      action: 'api_key.deleted',
      entityType: 'api_key',
      entityId: id,
      details: { key_prefix: apiKey.key_prefix },
      ipAddress: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({ message: 'API key deleted successfully' });
  } catch (error) {
    console.error('[User] Delete API key error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * GET /user/usage - Get usage statistics
 */
router.get('/usage', authenticateToken, async (req, res) => {
  try {
    const { start_date, end_date, days = 30 } = req.query;

    const stats = await UsageAnalytics.getUserStats(
      req.user.id,
      start_date,
      end_date
    );

    const trends = await UsageAnalytics.getUsageTrends(
      req.user.id,
      parseInt(days)
    );

    res.json({
      statistics: stats,
      trends: trends
    });
  } catch (error) {
    console.error('[User] Get usage error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * GET /user/webhooks - Get user's webhooks
 */
router.get('/webhooks', authenticateToken, async (req, res) => {
  try {
    const webhooks = await WebhookManager.getByUser(req.user.id);
    res.json({ webhooks });
  } catch (error) {
    console.error('[User] Get webhooks error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * POST /user/webhooks - Create webhook
 */
router.post('/webhooks', authenticateToken, async (req, res) => {
  try {
    const { url, events, secret } = req.body;

    if (!url || !events || !Array.isArray(events)) {
      return res.status(400).json({ error: 'URL and events array required' });
    }

    // Validate URL
    try {
      new URL(url);
    } catch {
      return res.status(400).json({ error: 'Invalid URL format' });
    }

    const webhookId = await WebhookManager.register(
      req.user.id,
      url,
      events,
      secret || null
    );

    await AuditLogger.log({
      userId: req.user.id,
      action: 'webhook.created',
      entityType: 'webhook',
      entityId: webhookId,
      details: { url, events },
      ipAddress: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({
      message: 'Webhook created successfully',
      webhook_id: webhookId
    });
  } catch (error) {
    console.error('[User] Create webhook error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * PUT /user/webhooks/:id - Update webhook
 */
router.put('/webhooks/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    // Verify webhook belongs to user
    const webhook = await db.get(
      'SELECT * FROM webhooks WHERE id = ? AND user_id = ?',
      [id, req.user.id]
    );

    if (!webhook) {
      return res.status(404).json({ error: 'Webhook not found' });
    }

    const success = await WebhookManager.update(id, updates);

    if (success) {
      await AuditLogger.log({
        userId: req.user.id,
        action: 'webhook.updated',
        entityType: 'webhook',
        entityId: id,
        details: updates,
        ipAddress: req.ip,
        userAgent: req.get('user-agent')
      });

      res.json({ message: 'Webhook updated successfully' });
    } else {
      res.status(500).json({ error: 'Failed to update webhook' });
    }
  } catch (error) {
    console.error('[User] Update webhook error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * DELETE /user/webhooks/:id - Delete webhook
 */
router.delete('/webhooks/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    // Verify webhook belongs to user
    const webhook = await db.get(
      'SELECT * FROM webhooks WHERE id = ? AND user_id = ?',
      [id, req.user.id]
    );

    if (!webhook) {
      return res.status(404).json({ error: 'Webhook not found' });
    }

    await WebhookManager.delete(id);

    await AuditLogger.log({
      userId: req.user.id,
      action: 'webhook.deleted',
      entityType: 'webhook',
      entityId: id,
      details: { url: webhook.url },
      ipAddress: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({ message: 'Webhook deleted successfully' });
  } catch (error) {
    console.error('[User] Delete webhook error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * POST /user/webhooks/:id/test - Test webhook
 */
router.post('/webhooks/:id/test', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    // Verify webhook belongs to user
    const webhook = await db.get(
      'SELECT * FROM webhooks WHERE id = ? AND user_id = ?',
      [id, req.user.id]
    );

    if (!webhook) {
      return res.status(404).json({ error: 'Webhook not found' });
    }

    const result = await WebhookManager.test(id);
    res.json(result);
  } catch (error) {
    console.error('[User] Test webhook error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * GET /user/export/usage - Export usage data
 */
router.get('/export/usage', authenticateToken, async (req, res) => {
  try {
    const { format = 'json', start_date, end_date } = req.query;

    if (format === 'csv') {
      const csv = await DataExporter.exportUsageLogsCSV(
        req.user.id,
        start_date,
        end_date
      );

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=usage_export.csv');
      res.send(csv);
    } else {
      const data = await DataExporter.exportJSON(req.user.id, true, false);

      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename=usage_export.json');
      res.json(data);
    }

    await AuditLogger.log({
      userId: req.user.id,
      action: 'data.exported',
      details: { format, type: 'usage' },
      ipAddress: req.ip,
      userAgent: req.get('user-agent')
    });
  } catch (error) {
    console.error('[User] Export usage error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * GET /user/audit-logs - Get user's audit logs
 */
router.get('/audit-logs', authenticateToken, async (req, res) => {
  try {
    const { limit = 50, offset = 0, action } = req.query;

    const logs = await AuditLogger.getLogs({
      userId: req.user.id,
      action: action,
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    res.json({ logs });
  } catch (error) {
    console.error('[User] Get audit logs error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
