const express = require('express');
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const db = require('../database/db');
const { authenticateToken, requireAdmin } = require('../middleware/auth.middleware');

const router = express.Router();

// All admin routes require authentication and admin role
router.use(authenticateToken, requireAdmin);

// ==================== USER MANAGEMENT ====================

// Get all users
router.get('/users', async (req, res) => {
  try {
    const users = await db.all(`
      SELECT u.id, u.username, u.email, u.role, u.is_banned, u.created_at,
             g.id as group_id, g.name as group_name
      FROM users u
      LEFT JOIN groups g ON u.group_id = g.id
      ORDER BY u.created_at DESC
    `);

    res.json({ users });
  } catch (error) {
    console.error('[Admin] Get users error:', error);
    res.status(500).json({ error: 'Failed to get users' });
  }
});

// Get single user details
router.get('/users/:id', async (req, res) => {
  try {
    const user = await db.get(`
      SELECT u.id, u.username, u.email, u.role, u.is_banned, u.created_at, u.updated_at,
             g.id as group_id, g.name as group_name, g.description as group_description
      FROM users u
      LEFT JOIN groups g ON u.group_id = g.id
      WHERE u.id = ?
    `, [req.params.id]);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Get user's domains
    const domains = await db.all(
      'SELECT id, domain FROM user_domains WHERE user_id = ?',
      [req.params.id]
    );

    // Get user's API keys
    const apiKeys = await db.all(
      'SELECT id, key_prefix, name, created_at, last_used FROM api_keys WHERE user_id = ?',
      [req.params.id]
    );

    res.json({ 
      user,
      domains,
      apiKeys
    });
  } catch (error) {
    console.error('[Admin] Get user error:', error);
    res.status(500).json({ error: 'Failed to get user' });
  }
});

// Create user
router.post('/users',
  [
    body('username').trim().isLength({ min: 3 }).withMessage('Username must be at least 3 characters'),
    body('email').isEmail().withMessage('Invalid email'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    body('role').optional().isIn(['user', 'admin']).withMessage('Invalid role')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { username, email, password, role, group_id } = req.body;

      // Check if user exists
      const existingUser = await db.get(
        'SELECT id FROM users WHERE email = ? OR username = ?',
        [email, username]
      );

      if (existingUser) {
        return res.status(400).json({ 
          error: 'User already exists',
          message: 'Email or username is already taken'
        });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Create user
      const result = await db.run(
        `INSERT INTO users (username, email, password, role, group_id) 
         VALUES (?, ?, ?, ?, ?)`,
        [username, email, hashedPassword, role || 'user', group_id || null]
      );

      res.status(201).json({
        message: 'User created successfully',
        user: {
          id: result.id,
          username,
          email,
          role: role || 'user',
          group_id: group_id || null
        }
      });
    } catch (error) {
      console.error('[Admin] Create user error:', error);
      res.status(500).json({ error: 'Failed to create user' });
    }
  }
);

// Update user
router.put('/users/:id',
  [
    body('username').optional().trim().isLength({ min: 3 }),
    body('email').optional().isEmail(),
    body('role').optional().isIn(['user', 'admin'])
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { username, email, role, group_id } = req.body;
      const userId = req.params.id;

      // Check if user exists
      const user = await db.get('SELECT id FROM users WHERE id = ?', [userId]);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Build update query
      const updates = [];
      const values = [];

      if (username) {
        updates.push('username = ?');
        values.push(username);
      }
      if (email) {
        updates.push('email = ?');
        values.push(email);
      }
      if (role) {
        updates.push('role = ?');
        values.push(role);
      }
      if (group_id !== undefined) {
        updates.push('group_id = ?');
        values.push(group_id);
      }

      if (updates.length === 0) {
        return res.status(400).json({ error: 'No fields to update' });
      }

      updates.push('updated_at = CURRENT_TIMESTAMP');
      values.push(userId);

      await db.run(
        `UPDATE users SET ${updates.join(', ')} WHERE id = ?`,
        values
      );

      res.json({ message: 'User updated successfully' });
    } catch (error) {
      console.error('[Admin] Update user error:', error);
      res.status(500).json({ error: 'Failed to update user' });
    }
  }
);

// Ban/Unban user
router.patch('/users/:id/ban', async (req, res) => {
  try {
    const { is_banned } = req.body;
    const userId = req.params.id;

    // Cannot ban yourself
    if (userId == req.user.id) {
      return res.status(400).json({ error: 'Cannot ban yourself' });
    }

    await db.run(
      'UPDATE users SET is_banned = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [is_banned ? 1 : 0, userId]
    );

    res.json({ 
      message: is_banned ? 'User banned successfully' : 'User unbanned successfully' 
    });
  } catch (error) {
    console.error('[Admin] Ban user error:', error);
    res.status(500).json({ error: 'Failed to update user status' });
  }
});

// Reset user password
router.post('/users/:id/reset-password',
  [
    body('newPassword').isLength({ min: 6 }).withMessage('Password must be at least 6 characters')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { newPassword } = req.body;
      const userId = req.params.id;

      // Hash password
      const hashedPassword = await bcrypt.hash(newPassword, 10);

      await db.run(
        'UPDATE users SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [hashedPassword, userId]
      );

      res.json({ message: 'Password reset successfully' });
    } catch (error) {
      console.error('[Admin] Reset password error:', error);
      res.status(500).json({ error: 'Failed to reset password' });
    }
  }
);

// Delete user
router.delete('/users/:id', async (req, res) => {
  try {
    const userId = req.params.id;

    // Cannot delete yourself
    if (userId == req.user.id) {
      return res.status(400).json({ error: 'Cannot delete yourself' });
    }

    await db.run('DELETE FROM users WHERE id = ?', [userId]);

    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    console.error('[Admin] Delete user error:', error);
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

// ==================== USER DOMAINS MANAGEMENT ====================

// Add domain to user
router.post('/users/:id/domains',
  [
    body('domain').trim().notEmpty().withMessage('Domain is required')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { domain } = req.body;
      const userId = req.params.id;

      // Check if domain already exists for this user
      const existing = await db.get(
        'SELECT id FROM user_domains WHERE user_id = ? AND domain = ?',
        [userId, domain]
      );

      if (existing) {
        return res.status(400).json({ error: 'Domain already added for this user' });
      }

      const result = await db.run(
        'INSERT INTO user_domains (user_id, domain) VALUES (?, ?)',
        [userId, domain]
      );

      res.status(201).json({
        message: 'Domain added successfully',
        domain: { id: result.id, domain }
      });
    } catch (error) {
      console.error('[Admin] Add domain error:', error);
      res.status(500).json({ error: 'Failed to add domain' });
    }
  }
);

// Remove domain from user
router.delete('/users/:userId/domains/:domainId', async (req, res) => {
  try {
    await db.run(
      'DELETE FROM user_domains WHERE id = ? AND user_id = ?',
      [req.params.domainId, req.params.userId]
    );

    res.json({ message: 'Domain removed successfully' });
  } catch (error) {
    console.error('[Admin] Remove domain error:', error);
    res.status(500).json({ error: 'Failed to remove domain' });
  }
});

// ==================== GROUP MANAGEMENT ====================

// Get all groups
router.get('/groups', async (req, res) => {
  try {
    const groups = await db.all(`
      SELECT g.*, COUNT(u.id) as user_count
      FROM groups g
      LEFT JOIN users u ON g.id = u.group_id
      GROUP BY g.id
      ORDER BY g.name
    `);

    res.json({ groups });
  } catch (error) {
    console.error('[Admin] Get groups error:', error);
    res.status(500).json({ error: 'Failed to get groups' });
  }
});

// Get single group with models
router.get('/groups/:id', async (req, res) => {
  try {
    const group = await db.get(
      'SELECT * FROM groups WHERE id = ?',
      [req.params.id]
    );

    if (!group) {
      return res.status(404).json({ error: 'Group not found' });
    }

    // Get group models
    const models = await db.all(
      'SELECT id, model_alias, model_name FROM group_models WHERE group_id = ?',
      [req.params.id]
    );

    // Get users in this group
    const users = await db.all(
      'SELECT id, username, email FROM users WHERE group_id = ?',
      [req.params.id]
    );

    res.json({ 
      group,
      models,
      users
    });
  } catch (error) {
    console.error('[Admin] Get group error:', error);
    res.status(500).json({ error: 'Failed to get group' });
  }
});

// Create group
router.post('/groups',
  [
    body('name').trim().isLength({ min: 2 }).withMessage('Name must be at least 2 characters'),
    body('description').optional()
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { name, description } = req.body;

      const result = await db.run(
        'INSERT INTO groups (name, description) VALUES (?, ?)',
        [name, description || null]
      );

      res.status(201).json({
        message: 'Group created successfully',
        group: { id: result.id, name, description }
      });
    } catch (error) {
      if (error.message.includes('UNIQUE')) {
        return res.status(400).json({ error: 'Group name already exists' });
      }
      console.error('[Admin] Create group error:', error);
      res.status(500).json({ error: 'Failed to create group' });
    }
  }
);

// Update group
router.put('/groups/:id',
  [
    body('name').optional().trim().isLength({ min: 2 }),
    body('description').optional()
  ],
  async (req, res) => {
    try {
      const { name, description } = req.body;
      
      const updates = [];
      const values = [];

      if (name) {
        updates.push('name = ?');
        values.push(name);
      }
      if (description !== undefined) {
        updates.push('description = ?');
        values.push(description);
      }

      if (updates.length === 0) {
        return res.status(400).json({ error: 'No fields to update' });
      }

      updates.push('updated_at = CURRENT_TIMESTAMP');
      values.push(req.params.id);

      await db.run(
        `UPDATE groups SET ${updates.join(', ')} WHERE id = ?`,
        values
      );

      res.json({ message: 'Group updated successfully' });
    } catch (error) {
      console.error('[Admin] Update group error:', error);
      res.status(500).json({ error: 'Failed to update group' });
    }
  }
);

// Delete group
router.delete('/groups/:id', async (req, res) => {
  try {
    // Check if group has users
    const users = await db.get(
      'SELECT COUNT(*) as count FROM users WHERE group_id = ?',
      [req.params.id]
    );

    if (users.count > 0) {
      return res.status(400).json({ 
        error: 'Cannot delete group with active users',
        message: `This group has ${users.count} user(s). Please reassign them first.`
      });
    }

    await db.run('DELETE FROM groups WHERE id = ?', [req.params.id]);

    res.json({ message: 'Group deleted successfully' });
  } catch (error) {
    console.error('[Admin] Delete group error:', error);
    res.status(500).json({ error: 'Failed to delete group' });
  }
});

// ==================== GROUP MODELS MANAGEMENT ====================

// Add model to group
router.post('/groups/:id/models',
  [
    body('model_alias').trim().notEmpty(),
    body('model_name').trim().notEmpty()
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { model_alias, model_name } = req.body;
      const groupId = req.params.id;

      const result = await db.run(
        'INSERT INTO group_models (group_id, model_alias, model_name) VALUES (?, ?, ?)',
        [groupId, model_alias, model_name]
      );

      res.status(201).json({
        message: 'Model added to group successfully',
        model: { id: result.id, model_alias, model_name }
      });
    } catch (error) {
      if (error.message.includes('UNIQUE')) {
        return res.status(400).json({ error: 'Model alias already exists for this group' });
      }
      console.error('[Admin] Add group model error:', error);
      res.status(500).json({ error: 'Failed to add model' });
    }
  }
);

// Remove model from group
router.delete('/groups/:groupId/models/:modelId', async (req, res) => {
  try {
    await db.run(
      'DELETE FROM group_models WHERE id = ? AND group_id = ?',
      [req.params.modelId, req.params.groupId]
    );

    res.json({ message: 'Model removed from group successfully' });
  } catch (error) {
    console.error('[Admin] Remove group model error:', error);
    res.status(500).json({ error: 'Failed to remove model' });
  }
});

// ==================== STATISTICS ====================

// Get dashboard statistics
router.get('/stats', async (req, res) => {
  try {
    const totalUsers = await db.get('SELECT COUNT(*) as count FROM users');
    const totalGroups = await db.get('SELECT COUNT(*) as count FROM groups');
    const bannedUsers = await db.get('SELECT COUNT(*) as count FROM users WHERE is_banned = 1');
    const activeUsers = await db.get(`
      SELECT COUNT(DISTINCT user_id) as count 
      FROM usage_logs 
      WHERE created_at > datetime('now', '-7 days')
    `);

    // Recent activity
    const recentActivity = await db.all(`
      SELECT u.username, ul.model_alias, ul.created_at
      FROM usage_logs ul
      JOIN users u ON ul.user_id = u.id
      ORDER BY ul.created_at DESC
      LIMIT 10
    `);

    res.json({
      stats: {
        total_users: totalUsers.count,
        total_groups: totalGroups.count,
        banned_users: bannedUsers.count,
        active_users_7d: activeUsers.count
      },
      recent_activity: recentActivity
    });
  } catch (error) {
    console.error('[Admin] Get stats error:', error);
    res.status(500).json({ error: 'Failed to get statistics' });
  }
});

module.exports = router;
