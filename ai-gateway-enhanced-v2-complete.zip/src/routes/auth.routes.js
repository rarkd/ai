const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const db = require('../database/db');
const { authenticateToken } = require('../middleware/auth.middleware');

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'change-this-secret-key';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '24h';

// Login
router.post('/login',
  [
    body('email').isEmail().withMessage('Invalid email'),
    body('password').notEmpty().withMessage('Password is required')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { email, password } = req.body;

      // Find user
      const user = await db.get(
        'SELECT * FROM users WHERE email = ?',
        [email]
      );

      if (!user) {
        return res.status(401).json({ 
          error: 'Invalid credentials',
          message: 'Email or password is incorrect'
        });
      }

      // Check if banned
      if (user.is_banned) {
        return res.status(403).json({ 
          error: 'Account banned',
          message: 'Your account has been banned. Please contact administrator.'
        });
      }

      // Verify password
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ 
          error: 'Invalid credentials',
          message: 'Email or password is incorrect'
        });
      }

      // Generate JWT
      const token = jwt.sign(
        { userId: user.id, role: user.role },
        JWT_SECRET,
        { expiresIn: JWT_EXPIRES_IN }
      );

      // Get group info
      let group = null;
      if (user.group_id) {
        group = await db.get(
          'SELECT id, name, description FROM groups WHERE id = ?',
          [user.group_id]
        );
      }

      res.json({
        message: 'Login successful',
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role,
          group: group
        }
      });
    } catch (error) {
      console.error('[Auth] Login error:', error);
      res.status(500).json({ 
        error: 'Login failed',
        message: error.message
      });
    }
  }
);

// Register (only admins can create users)
router.post('/register',
  authenticateToken,
  [
    body('username').trim().isLength({ min: 3 }).withMessage('Username must be at least 3 characters'),
    body('email').isEmail().withMessage('Invalid email'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    body('role').optional().isIn(['user', 'admin']).withMessage('Invalid role')
  ],
  async (req, res) => {
    try {
      // Only admins can register new users
      if (req.user.role !== 'admin') {
        return res.status(403).json({ 
          error: 'Access denied',
          message: 'Only administrators can create users'
        });
      }

      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { username, email, password, role, group_id } = req.body;

      // Check if user exists
      const existingUser = await db.get(
        'SELECT id FROM users WHERE email = ? OR username = ?',
        [email, username]
      );

      if (existingUser) {
        return res.status(400).json({ 
          error: 'User already exists',
          message: 'Email or username is already taken'
        });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Create user
      const result = await db.run(
        `INSERT INTO users (username, email, password, role, group_id) 
         VALUES (?, ?, ?, ?, ?)`,
        [username, email, hashedPassword, role || 'user', group_id || null]
      );

      res.status(201).json({
        message: 'User created successfully',
        user: {
          id: result.id,
          username,
          email,
          role: role || 'user',
          group_id: group_id || null
        }
      });
    } catch (error) {
      console.error('[Auth] Registration error:', error);
      res.status(500).json({ 
        error: 'Registration failed',
        message: error.message
      });
    }
  }
);

// Get current user profile
router.get('/me', authenticateToken, async (req, res) => {
  try {
    const user = await db.get(
      `SELECT u.id, u.username, u.email, u.role, u.group_id, u.created_at,
              g.name as group_name, g.description as group_description
       FROM users u
       LEFT JOIN groups g ON u.group_id = g.id
       WHERE u.id = ?`,
      [req.user.id]
    );

    // Get allowed domains
    const domains = await db.all(
      'SELECT domain FROM user_domains WHERE user_id = ?',
      [req.user.id]
    );

    // Get available models based on group
    let models = [];
    if (user.group_id) {
      models = await db.all(
        'SELECT model_alias, model_name FROM group_models WHERE group_id = ?',
        [user.group_id]
      );
    }

    res.json({
      user: {
        ...user,
        domains: domains.map(d => d.domain),
        available_models: models
      }
    });
  } catch (error) {
    console.error('[Auth] Get profile error:', error);
    res.status(500).json({ 
      error: 'Failed to get profile',
      message: error.message
    });
  }
});

// Change password
router.post('/change-password',
  authenticateToken,
  [
    body('currentPassword').notEmpty().withMessage('Current password is required'),
    body('newPassword').isLength({ min: 6 }).withMessage('New password must be at least 6 characters')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { currentPassword, newPassword } = req.body;

      // Get user
      const user = await db.get(
        'SELECT password FROM users WHERE id = ?',
        [req.user.id]
      );

      // Verify current password
      const isValid = await bcrypt.compare(currentPassword, user.password);
      if (!isValid) {
        return res.status(401).json({ 
          error: 'Invalid password',
          message: 'Current password is incorrect'
        });
      }

      // Hash new password
      const hashedPassword = await bcrypt.hash(newPassword, 10);

      // Update password
      await db.run(
        'UPDATE users SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [hashedPassword, req.user.id]
      );

      res.json({ message: 'Password changed successfully' });
    } catch (error) {
      console.error('[Auth] Change password error:', error);
      res.status(500).json({ 
        error: 'Failed to change password',
        message: error.message
      });
    }
  }
);

module.exports = router;
