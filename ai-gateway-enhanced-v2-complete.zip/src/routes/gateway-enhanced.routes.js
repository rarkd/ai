const express = require('express');
const router = express.Router();
const axios = require('axios');
const db = require('../database/db');
const { authenticateToken, authenticateApiKey } = require('../middleware/auth.middleware');
const { corsMiddleware } = require('../middleware/cors.middleware');
const { rateLimitMiddleware } = require('../middleware/rateLimit.middleware');
const { UsageAnalytics } = require('../utils/analytics');
const { ResponseCache, WebhookManager } = require('../utils/helpers');

/**
 * Middleware to check if model is allowed for user's group
 */
async function checkModelAccess(req, res, next) {
  try {
    const modelAlias = req.params.model;
    const userGroupId = req.user.group_id;

    if (!userGroupId) {
      return res.status(403).json({ error: 'User not assigned to any group' });
    }

    // Check if model is allowed for this group
    const allowedModel = await db.get(
      `SELECT gm.*, g.max_tokens_per_request 
       FROM group_models gm
       JOIN groups g ON gm.group_id = g.id
       WHERE gm.group_id = ? AND gm.model_alias = ?`,
      [userGroupId, modelAlias]
    );

    if (!allowedModel) {
      return res.status(403).json({ 
        error: 'Model not allowed for your group',
        model: modelAlias 
      });
    }

    req.allowedModel = allowedModel;
    next();
  } catch (error) {
    console.error('[Gateway] Check model access error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

/**
 * POST /api/:model - Make AI request
 */
router.post('/:model', 
  corsMiddleware,
  authenticateToken,
  rateLimitMiddleware,
  checkModelAccess,
  async (req, res) => {
    const startTime = Date.now();
    
    try {
      const { model: modelAlias } = req.params;
      const { prompt, stream = false, temperature = 0.7, max_tokens, ...options } = req.body;

      if (!prompt) {
        return res.status(400).json({ error: 'Prompt is required' });
      }

      // Check token limit
      const requestedMaxTokens = max_tokens || req.allowedModel.max_tokens_per_request;
      if (requestedMaxTokens > req.allowedModel.max_tokens_per_request) {
        return res.status(400).json({
          error: 'Token limit exceeded',
          max_allowed: req.allowedModel.max_tokens_per_request,
          requested: requestedMaxTokens
        });
      }

      // Check cache if not streaming and temperature is low (deterministic)
      if (!stream && temperature <= 0.3) {
        const cacheKey = ResponseCache.generateKey(modelAlias, prompt, temperature);
        const cached = await ResponseCache.get(cacheKey);
        
        if (cached) {
          console.log('[Gateway] Cache hit for', modelAlias);
          
          // Log usage from cache
          await UsageAnalytics.logUsage({
            userId: req.user.id,
            modelAlias: modelAlias,
            requestTokens: 0,
            responseTokens: cached.tokens_used,
            totalTokens: cached.tokens_used,
            responseTimeMs: Date.now() - startTime,
            status: 'success_cached',
            ipAddress: req.ip,
            userAgent: req.get('user-agent')
          });

          return res.json({
            response: cached.response,
            model: modelAlias,
            from_cache: true,
            tokens: cached.tokens_used
          });
        }
      }

      // Get actual model name from mapping
      const actualModel = req.allowedModel.model_name;
      const ollamaUrl = process.env.OLLAMA_BASE_URL || 'https://aiapi.awwlk.my.id';

      // Prepare request for Ollama
      const ollamaRequest = {
        model: actualModel,
        prompt: prompt,
        stream: stream,
        options: {
          temperature: temperature,
          num_predict: requestedMaxTokens,
          ...options
        }
      };

      // Handle streaming
      if (stream) {
        const response = await axios.post(
          `${ollamaUrl}/api/generate`,
          ollamaRequest,
          {
            responseType: 'stream',
            timeout: 120000 // 2 minutes
          }
        );

        let fullResponse = '';
        let totalTokens = 0;

        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');

        response.data.on('data', (chunk) => {
          try {
            const lines = chunk.toString().split('\n').filter(line => line.trim());
            
            for (const line of lines) {
              const data = JSON.parse(line);
              
              if (data.response) {
                fullResponse += data.response;
                res.write(`data: ${JSON.stringify({ token: data.response })}\n\n`);
              }
              
              if (data.done) {
                totalTokens = data.eval_count || 0;
              }
            }
          } catch (e) {
            console.error('[Gateway] Stream parse error:', e);
          }
        });

        response.data.on('end', async () => {
          res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
          res.end();

          // Log usage
          const responseTime = Date.now() - startTime;
          await UsageAnalytics.logUsage({
            userId: req.user.id,
            modelAlias: modelAlias,
            requestTokens: prompt.split(' ').length,
            responseTokens: totalTokens,
            totalTokens: totalTokens + prompt.split(' ').length,
            responseTimeMs: responseTime,
            status: 'success',
            ipAddress: req.ip,
            userAgent: req.get('user-agent')
          });

          // Trigger webhook
          await WebhookManager.trigger(req.user.id, 'request.completed', {
            model: modelAlias,
            tokens: totalTokens,
            response_time_ms: responseTime
          });
        });

        response.data.on('error', async (error) => {
          console.error('[Gateway] Stream error:', error);
          res.end();

          await UsageAnalytics.logUsage({
            userId: req.user.id,
            modelAlias: modelAlias,
            status: 'error',
            errorMessage: error.message,
            responseTimeMs: Date.now() - startTime,
            ipAddress: req.ip,
            userAgent: req.get('user-agent')
          });
        });

      } else {
        // Non-streaming request
        const response = await axios.post(
          `${ollamaUrl}/api/generate`,
          ollamaRequest,
          { timeout: 120000 }
        );

        const responseTime = Date.now() - startTime;
        const tokensUsed = response.data.eval_count || 0;
        const requestTokens = prompt.split(' ').length;

        // Cache response if temperature is low
        if (temperature <= 0.3) {
          const cacheKey = ResponseCache.generateKey(modelAlias, prompt, temperature);
          await ResponseCache.set(
            cacheKey,
            modelAlias,
            response.data.response,
            tokensUsed,
            60 // 60 minutes TTL
          );
        }

        // Log usage
        await UsageAnalytics.logUsage({
          userId: req.user.id,
          modelAlias: modelAlias,
          requestTokens: requestTokens,
          responseTokens: tokensUsed,
          totalTokens: tokensUsed + requestTokens,
          responseTimeMs: responseTime,
          status: 'success',
          ipAddress: req.ip,
          userAgent: req.get('user-agent')
        });

        // Trigger webhook
        await WebhookManager.trigger(req.user.id, 'request.completed', {
          model: modelAlias,
          tokens: tokensUsed,
          response_time_ms: responseTime
        });

        res.json({
          response: response.data.response,
          model: modelAlias,
          tokens: tokensUsed,
          response_time_ms: responseTime,
          from_cache: false
        });
      }

    } catch (error) {
      const responseTime = Date.now() - startTime;
      console.error('[Gateway] Request error:', error.message);

      // Log error
      await UsageAnalytics.logUsage({
        userId: req.user.id,
        modelAlias: req.params.model,
        status: 'error',
        errorMessage: error.message,
        responseTimeMs: responseTime,
        ipAddress: req.ip,
        userAgent: req.get('user-agent')
      });

      // Trigger webhook
      await WebhookManager.trigger(req.user.id, 'request.failed', {
        model: req.params.model,
        error: error.message,
        response_time_ms: responseTime
      });

      if (error.response) {
        res.status(error.response.status).json({
          error: 'AI service error',
          message: error.response.data?.error || error.message
        });
      } else if (error.code === 'ECONNABORTED') {
        res.status(504).json({ error: 'Request timeout' });
      } else {
        res.status(500).json({ error: 'Internal server error', message: error.message });
      }
    }
  }
);

/**
 * GET /api/models/available - Get available models for user
 */
router.get('/models/available', 
  corsMiddleware,
  authenticateToken,
  async (req, res) => {
    try {
      const userGroupId = req.user.group_id;

      if (!userGroupId) {
        return res.json({ models: [] });
      }

      const models = await db.all(
        `SELECT gm.model_alias, gm.model_name, mm.description, g.max_tokens_per_request
         FROM group_models gm
         LEFT JOIN model_mappings mm ON gm.model_alias = mm.alias
         JOIN groups g ON gm.group_id = g.id
         WHERE gm.group_id = ?
         ORDER BY gm.model_alias`,
        [userGroupId]
      );

      res.json({ models });
    } catch (error) {
      console.error('[Gateway] Get available models error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }
);

/**
 * GET /api/usage/stats - Get usage statistics for current user
 */
router.get('/usage/stats',
  authenticateToken,
  async (req, res) => {
    try {
      const { start_date, end_date, days = 30 } = req.query;

      const stats = await UsageAnalytics.getUserStats(
        req.user.id,
        start_date,
        end_date
      );

      const trends = await UsageAnalytics.getUsageTrends(
        req.user.id,
        parseInt(days)
      );

      res.json({
        stats,
        trends
      });
    } catch (error) {
      console.error('[Gateway] Get usage stats error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }
);

/**
 * GET /api/health - Health check
 */
router.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString()
  });
});

module.exports = router;
