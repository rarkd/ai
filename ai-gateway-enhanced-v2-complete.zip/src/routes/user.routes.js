const express = require('express');
const { body, validationResult } = require('express-validator');
const db = require('../database/db');
const { authenticateToken } = require('../middleware/auth.middleware');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');

const router = express.Router();

// All user routes require authentication
router.use(authenticateToken);

// ==================== USER PROFILE ====================

// Get user's available models
router.get('/models', async (req, res) => {
  try {
    if (!req.user.group_id) {
      return res.json({ 
        models: [],
        message: 'You are not assigned to any group. Please contact administrator.'
      });
    }

    const models = await db.all(
      'SELECT model_alias, model_name FROM group_models WHERE group_id = ?',
      [req.user.group_id]
    );

    res.json({ models });
  } catch (error) {
    console.error('[User] Get models error:', error);
    res.status(500).json({ error: 'Failed to get models' });
  }
});

// Get user's group info
router.get('/group', async (req, res) => {
  try {
    if (!req.user.group_id) {
      return res.json({ 
        group: null,
        message: 'You are not assigned to any group'
      });
    }

    const group = await db.get(
      'SELECT id, name, description FROM groups WHERE id = ?',
      [req.user.group_id]
    );

    const models = await db.all(
      'SELECT model_alias, model_name FROM group_models WHERE group_id = ?',
      [req.user.group_id]
    );

    res.json({ 
      group,
      models
    });
  } catch (error) {
    console.error('[User] Get group error:', error);
    res.status(500).json({ error: 'Failed to get group info' });
  }
});

// ==================== DOMAINS MANAGEMENT ====================

// Get user's domains
router.get('/domains', async (req, res) => {
  try {
    const domains = await db.all(
      'SELECT id, domain, created_at FROM user_domains WHERE user_id = ?',
      [req.user.id]
    );

    res.json({ domains });
  } catch (error) {
    console.error('[User] Get domains error:', error);
    res.status(500).json({ error: 'Failed to get domains' });
  }
});

// Add domain
router.post('/domains',
  [
    body('domain').trim().notEmpty().withMessage('Domain is required')
      .matches(/^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i).withMessage('Invalid domain format')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { domain } = req.body;

      // Check if domain already exists for this user
      const existing = await db.get(
        'SELECT id FROM user_domains WHERE user_id = ? AND domain = ?',
        [req.user.id, domain]
      );

      if (existing) {
        return res.status(400).json({ error: 'Domain already added' });
      }

      const result = await db.run(
        'INSERT INTO user_domains (user_id, domain) VALUES (?, ?)',
        [req.user.id, domain]
      );

      res.status(201).json({
        message: 'Domain added successfully',
        domain: { id: result.id, domain }
      });
    } catch (error) {
      console.error('[User] Add domain error:', error);
      res.status(500).json({ error: 'Failed to add domain' });
    }
  }
);

// Delete domain
router.delete('/domains/:id', async (req, res) => {
  try {
    const result = await db.run(
      'DELETE FROM user_domains WHERE id = ? AND user_id = ?',
      [req.params.id, req.user.id]
    );

    if (result.changes === 0) {
      return res.status(404).json({ error: 'Domain not found' });
    }

    res.json({ message: 'Domain deleted successfully' });
  } catch (error) {
    console.error('[User] Delete domain error:', error);
    res.status(500).json({ error: 'Failed to delete domain' });
  }
});

// ==================== API KEYS MANAGEMENT ====================

// Get user's API keys
router.get('/api-keys', async (req, res) => {
  try {
    const apiKeys = await db.all(
      'SELECT id, key_prefix, name, created_at, last_used FROM api_keys WHERE user_id = ?',
      [req.user.id]
    );

    res.json({ apiKeys });
  } catch (error) {
    console.error('[User] Get API keys error:', error);
    res.status(500).json({ error: 'Failed to get API keys' });
  }
});

// Create API key
router.post('/api-keys',
  [
    body('name').optional().trim().isLength({ max: 100 })
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { name } = req.body;

      // Generate API key: gw_xxxxxxxxxxxxxxxx (32 chars total)
      const randomPart = crypto.randomBytes(16).toString('hex');
      const apiKey = `gw_${randomPart}`;
      const keyPrefix = apiKey.substring(0, 10);

      // Hash the API key
      const keyHash = await bcrypt.hash(apiKey, 10);

      const result = await db.run(
        'INSERT INTO api_keys (user_id, key_hash, key_prefix, name) VALUES (?, ?, ?, ?)',
        [req.user.id, keyHash, keyPrefix, name || null]
      );

      res.status(201).json({
        message: 'API key created successfully',
        apiKey: apiKey,
        warning: 'Save this key securely. You will not be able to see it again.',
        keyInfo: {
          id: result.id,
          key_prefix: keyPrefix,
          name: name || null
        }
      });
    } catch (error) {
      console.error('[User] Create API key error:', error);
      res.status(500).json({ error: 'Failed to create API key' });
    }
  }
);

// Delete API key
router.delete('/api-keys/:id', async (req, res) => {
  try {
    const result = await db.run(
      'DELETE FROM api_keys WHERE id = ? AND user_id = ?',
      [req.params.id, req.user.id]
    );

    if (result.changes === 0) {
      return res.status(404).json({ error: 'API key not found' });
    }

    res.json({ message: 'API key deleted successfully' });
  } catch (error) {
    console.error('[User] Delete API key error:', error);
    res.status(500).json({ error: 'Failed to delete API key' });
  }
});

// ==================== USAGE STATISTICS ====================

// Get user's usage statistics
router.get('/usage', async (req, res) => {
  try {
    const { period = '7d' } = req.query;

    let dateFilter = "datetime('now', '-7 days')";
    if (period === '30d') dateFilter = "datetime('now', '-30 days')";
    if (period === '1d') dateFilter = "datetime('now', '-1 day')";

    const usageByModel = await db.all(`
      SELECT 
        model_alias,
        COUNT(*) as request_count,
        SUM(request_tokens) as total_request_tokens,
        SUM(response_tokens) as total_response_tokens
      FROM usage_logs
      WHERE user_id = ? AND created_at > ${dateFilter}
      GROUP BY model_alias
      ORDER BY request_count DESC
    `, [req.user.id]);

    const totalStats = await db.get(`
      SELECT 
        COUNT(*) as total_requests,
        SUM(request_tokens) as total_request_tokens,
        SUM(response_tokens) as total_response_tokens
      FROM usage_logs
      WHERE user_id = ? AND created_at > ${dateFilter}
    `, [req.user.id]);

    res.json({
      period,
      total: totalStats,
      by_model: usageByModel
    });
  } catch (error) {
    console.error('[User] Get usage error:', error);
    res.status(500).json({ error: 'Failed to get usage statistics' });
  }
});

module.exports = router;
