const express = require('express');
const axios = require('axios');
const db = require('../database/db');
const { authenticate, requireGroup } = require('../middleware/auth.middleware');
const { dynamicCors } = require('../middleware/cors.middleware');

const router = express.Router();

const OLLAMA_BASE_URL = process.env.OLLAMA_BASE_URL || 'https://aiapi.awwlk.my.id';
const OLLAMA_GENERATE_ENDPOINT = process.env.OLLAMA_GENERATE_ENDPOINT || '/api/generate';

// Gateway endpoint - handles AI requests
router.post('/:model', authenticate, requireGroup, dynamicCors, async (req, res) => {
  try {
    const requestedModel = req.params.model;
    const userId = req.user.id;
    const groupId = req.user.group_id;

    // Check if user has access to this model through their group
    const allowedModel = await db.get(
      'SELECT model_alias, model_name FROM group_models WHERE group_id = ? AND model_alias = ?',
      [groupId, requestedModel]
    );

    if (!allowedModel) {
      return res.status(403).json({
        error: 'Model not allowed',
        message: `You don't have access to the model '${requestedModel}'. Check your group permissions.`
      });
    }

    // Get the actual Ollama model name
    const ollamaModel = allowedModel.model_name;

    console.log(`[Gateway] User ${req.user.username} requesting ${requestedModel} -> ${ollamaModel}`);

    // Prepare request to Ollama
    const ollamaRequest = {
      model: ollamaModel,
      prompt: req.body.prompt || req.body.messages?.[0]?.content || '',
      stream: req.body.stream || false,
      ...req.body
    };

    // If messages format (OpenAI-style), convert to prompt
    if (req.body.messages && Array.isArray(req.body.messages)) {
      const messages = req.body.messages;
      const lastMessage = messages[messages.length - 1];
      ollamaRequest.prompt = lastMessage.content;
    }

    // Forward request to Ollama
    const ollamaResponse = await axios.post(
      `${OLLAMA_BASE_URL}${OLLAMA_GENERATE_ENDPOINT}`,
      ollamaRequest,
      {
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 120000 // 2 minutes timeout
      }
    );

    // Log usage
    try {
      const requestTokens = ollamaRequest.prompt?.length || 0;
      const responseTokens = ollamaResponse.data.response?.length || 0;

      await db.run(
        `INSERT INTO usage_logs (user_id, model_alias, request_tokens, response_tokens) 
         VALUES (?, ?, ?, ?)`,
        [userId, requestedModel, requestTokens, responseTokens]
      );
    } catch (logError) {
      console.error('[Gateway] Error logging usage:', logError);
      // Don't fail the request if logging fails
    }

    // Return response
    res.json(ollamaResponse.data);

  } catch (error) {
    console.error('[Gateway] Error:', error.message);
    
    if (error.response) {
      // Ollama returned an error
      return res.status(error.response.status).json({
        error: 'Ollama error',
        message: error.response.data?.error || error.message
      });
    }

    if (error.code === 'ECONNREFUSED') {
      return res.status(503).json({
        error: 'Service unavailable',
        message: 'Cannot connect to Ollama service'
      });
    }

    if (error.code === 'ETIMEDOUT') {
      return res.status(504).json({
        error: 'Gateway timeout',
        message: 'Request to Ollama timed out'
      });
    }

    res.status(500).json({
      error: 'Gateway error',
      message: error.message
    });
  }
});

// List available models for the authenticated user
router.get('/models/available', authenticate, async (req, res) => {
  try {
    if (!req.user.group_id) {
      return res.json({
        models: [],
        message: 'You are not assigned to any group. Please contact administrator.'
      });
    }

    const models = await db.all(
      'SELECT model_alias, model_name FROM group_models WHERE group_id = ?',
      [req.user.group_id]
    );

    res.json({ models });
  } catch (error) {
    console.error('[Gateway] Error getting models:', error);
    res.status(500).json({
      error: 'Failed to get models',
      message: error.message
    });
  }
});

module.exports = router;
