const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

const DB_PATH = process.env.DATABASE_PATH || './data/gateway.db';
const DATA_DIR = path.dirname(DB_PATH);

// Create data directory if it doesn't exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  console.log(`[DB Init] Created directory: ${DATA_DIR}`);
}

const db = new sqlite3.Database(DB_PATH, (err) => {
  if (err) {
    console.error('[DB Init] Error opening database:', err);
    process.exit(1);
  }
  console.log('[DB Init] Connected to SQLite database');
});

// Enable foreign keys
db.run('PRAGMA foreign_keys = ON');

// Initialize database schema
function initializeDatabase() {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      // Users table
      db.run(`
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username VARCHAR(50) UNIQUE NOT NULL,
          email VARCHAR(100) UNIQUE NOT NULL,
          password VARCHAR(255) NOT NULL,
          role VARCHAR(20) NOT NULL DEFAULT 'user',
          group_id INTEGER,
          is_banned BOOLEAN DEFAULT 0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (group_id) REFERENCES groups(id) ON DELETE SET NULL
        )
      `, (err) => {
        if (err) console.error('[DB Init] Error creating users table:', err);
        else console.log('[DB Init] ✓ Users table created');
      });

      // Groups table
      db.run(`
        CREATE TABLE IF NOT EXISTS groups (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name VARCHAR(100) UNIQUE NOT NULL,
          description TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `, (err) => {
        if (err) console.error('[DB Init] Error creating groups table:', err);
        else console.log('[DB Init] ✓ Groups table created');
      });

      // Group Models (models allowed for each group)
      db.run(`
        CREATE TABLE IF NOT EXISTS group_models (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          group_id INTEGER NOT NULL,
          model_alias VARCHAR(100) NOT NULL,
          model_name VARCHAR(100) NOT NULL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (group_id) REFERENCES groups(id) ON DELETE CASCADE,
          UNIQUE(group_id, model_alias)
        )
      `, (err) => {
        if (err) console.error('[DB Init] Error creating group_models table:', err);
        else console.log('[DB Init] ✓ Group Models table created');
      });

      // User Domains (CORS whitelist per user)
      db.run(`
        CREATE TABLE IF NOT EXISTS user_domains (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          domain VARCHAR(255) NOT NULL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
          UNIQUE(user_id, domain)
        )
      `, (err) => {
        if (err) console.error('[DB Init] Error creating user_domains table:', err);
        else console.log('[DB Init] ✓ User Domains table created');
      });

      // API Keys table (for non-browser access)
      db.run(`
        CREATE TABLE IF NOT EXISTS api_keys (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          key_hash VARCHAR(255) NOT NULL,
          key_prefix VARCHAR(20) NOT NULL,
          name VARCHAR(100),
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          last_used DATETIME,
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
      `, (err) => {
        if (err) console.error('[DB Init] Error creating api_keys table:', err);
        else console.log('[DB Init] ✓ API Keys table created');
      });

      // Model mappings (backward compatibility with old system)
      db.run(`
        CREATE TABLE IF NOT EXISTS model_mappings (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          alias VARCHAR(100) UNIQUE NOT NULL,
          model_name VARCHAR(100) NOT NULL,
          description TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `, (err) => {
        if (err) console.error('[DB Init] Error creating model_mappings table:', err);
        else console.log('[DB Init] ✓ Model Mappings table created');
      });

      // Usage logs
      db.run(`
        CREATE TABLE IF NOT EXISTS usage_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          model_alias VARCHAR(100) NOT NULL,
          request_tokens INTEGER DEFAULT 0,
          response_tokens INTEGER DEFAULT 0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
      `, (err) => {
        if (err) console.error('[DB Init] Error creating usage_logs table:', err);
        else console.log('[DB Init] ✓ Usage Logs table created');
      });

      // Create default admin user
      const adminPassword = process.env.DEFAULT_ADMIN_PASSWORD || 'admin123';
      const adminEmail = process.env.DEFAULT_ADMIN_EMAIL || 'admin@gateway.local';
      const adminUsername = process.env.DEFAULT_ADMIN_USERNAME || 'admin';
      
      bcrypt.hash(adminPassword, 10, (err, hash) => {
        if (err) {
          console.error('[DB Init] Error hashing admin password:', err);
          return;
        }

        db.run(`
          INSERT OR IGNORE INTO users (username, email, password, role)
          VALUES (?, ?, ?, 'admin')
        `, [adminUsername, adminEmail, hash], (err) => {
          if (err) {
            console.error('[DB Init] Error creating admin user:', err);
          } else {
            console.log('[DB Init] ✓ Default admin user created');
            console.log('[DB Init]   Username:', adminUsername);
            console.log('[DB Init]   Email:', adminEmail);
            console.log('[DB Init]   Password:', adminPassword);
            console.log('[DB Init]   ⚠️  CHANGE DEFAULT PASSWORD IN PRODUCTION!');
          }
        });
      });

      // Create default groups
      db.run(`
        INSERT OR IGNORE INTO groups (id, name, description)
        VALUES 
          (1, 'Basic', 'Basic tier with limited models'),
          (2, 'Pro', 'Pro tier with more models'),
          (3, 'Enterprise', 'Enterprise tier with all models')
      `, (err) => {
        if (err) console.error('[DB Init] Error creating default groups:', err);
        else console.log('[DB Init] ✓ Default groups created');
      });

      // Create some default model mappings
      const defaultModels = [
        { alias: 'gpt-3.5-turbo', model: 'llama3.2:latest', description: 'Fast general purpose model' },
        { alias: 'gpt-4', model: 'llama3.2:latest', description: 'Advanced reasoning model' },
        { alias: 'claude-3-sonnet', model: 'llama3.2:latest', description: 'Balanced model' },
        { alias: 'claude-3-opus', model: 'llama3.2:latest', description: 'Most capable model' }
      ];

      const stmt = db.prepare(`
        INSERT OR IGNORE INTO model_mappings (alias, model_name, description)
        VALUES (?, ?, ?)
      `);

      defaultModels.forEach(model => {
        stmt.run(model.alias, model.model, model.description);
      });
      stmt.finalize(() => {
        console.log('[DB Init] ✓ Default model mappings created');
      });

      // Assign models to groups
      const groupModels = [
        // Basic group
        { group_id: 1, alias: 'gpt-3.5-turbo', model: 'llama3.2:latest' },
        // Pro group
        { group_id: 2, alias: 'gpt-3.5-turbo', model: 'llama3.2:latest' },
        { group_id: 2, alias: 'gpt-4', model: 'llama3.2:latest' },
        { group_id: 2, alias: 'claude-3-sonnet', model: 'llama3.2:latest' },
        // Enterprise group
        { group_id: 3, alias: 'gpt-3.5-turbo', model: 'llama3.2:latest' },
        { group_id: 3, alias: 'gpt-4', model: 'llama3.2:latest' },
        { group_id: 3, alias: 'claude-3-sonnet', model: 'llama3.2:latest' },
        { group_id: 3, alias: 'claude-3-opus', model: 'llama3.2:latest' }
      ];

      const stmtGroupModels = db.prepare(`
        INSERT OR IGNORE INTO group_models (group_id, model_alias, model_name)
        VALUES (?, ?, ?)
      `);

      groupModels.forEach(gm => {
        stmtGroupModels.run(gm.group_id, gm.alias, gm.model);
      });
      stmtGroupModels.finalize(() => {
        console.log('[DB Init] ✓ Group models assigned');
        console.log('');
        console.log('=================================');
        console.log('✅ Database initialization complete!');
        console.log('=================================');
        resolve();
      });
    });
  });
}

// Run initialization
initializeDatabase()
  .then(() => {
    db.close((err) => {
      if (err) {
        console.error('[DB Init] Error closing database:', err);
      }
      console.log('[DB Init] Database connection closed');
      process.exit(0);
    });
  })
  .catch(err => {
    console.error('[DB Init] Initialization failed:', err);
    process.exit(1);
  });
