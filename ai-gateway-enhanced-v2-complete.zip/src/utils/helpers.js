const db = require('../database/db');
const crypto = require('crypto');
const axios = require('axios');

/**
 * Response cache utility
 */
class ResponseCache {
  /**
   * Generate cache key from request
   */
  static generateKey(modelAlias, prompt, temperature = 0.7) {
    const data = `${modelAlias}:${prompt}:${temperature}`;
    return crypto.createHash('sha256').update(data).digest('hex');
  }

  /**
   * Get cached response
   */
  static async get(cacheKey) {
    try {
      const cached = await db.get(
        `SELECT * FROM response_cache 
         WHERE cache_key = ? AND expires_at > datetime('now')`,
        [cacheKey]
      );

      if (cached) {
        // Increment hit counter
        await db.run(
          'UPDATE response_cache SET hits = hits + 1 WHERE id = ?',
          [cached.id]
        );

        return {
          response: cached.response,
          tokens_used: cached.tokens_used,
          from_cache: true
        };
      }

      return null;
    } catch (error) {
      console.error('[Cache] Get error:', error);
      return null;
    }
  }

  /**
   * Set cache entry
   */
  static async set(cacheKey, modelAlias, response, tokensUsed, ttlMinutes = 60) {
    try {
      const expiresAt = new Date();
      expiresAt.setMinutes(expiresAt.getMinutes() + ttlMinutes);

      await db.run(
        `INSERT OR REPLACE INTO response_cache 
         (cache_key, model_alias, response, tokens_used, expires_at)
         VALUES (?, ?, ?, ?, ?)`,
        [cacheKey, modelAlias, response, tokensUsed, expiresAt.toISOString()]
      );
    } catch (error) {
      console.error('[Cache] Set error:', error);
    }
  }

  /**
   * Clear expired cache entries
   */
  static async clearExpired() {
    try {
      const result = await db.run(
        `DELETE FROM response_cache WHERE expires_at <= datetime('now')`
      );
      
      console.log(`[Cache] Cleared ${result.changes} expired entries`);
      return result.changes;
    } catch (error) {
      console.error('[Cache] Clear expired error:', error);
      return 0;
    }
  }

  /**
   * Clear all cache
   */
  static async clearAll() {
    try {
      const result = await db.run('DELETE FROM response_cache');
      console.log(`[Cache] Cleared all ${result.changes} entries`);
      return result.changes;
    } catch (error) {
      console.error('[Cache] Clear all error:', error);
      return 0;
    }
  }

  /**
   * Get cache statistics
   */
  static async getStats() {
    try {
      const stats = await db.get(`
        SELECT 
          COUNT(*) as total_entries,
          SUM(hits) as total_hits,
          SUM(tokens_used) as total_tokens_saved
        FROM response_cache
        WHERE expires_at > datetime('now')
      `);

      const modelStats = await db.all(`
        SELECT 
          model_alias,
          COUNT(*) as entries,
          SUM(hits) as hits,
          SUM(tokens_used) as tokens_saved
        FROM response_cache
        WHERE expires_at > datetime('now')
        GROUP BY model_alias
      `);

      return {
        ...stats,
        by_model: modelStats
      };
    } catch (error) {
      console.error('[Cache] Get stats error:', error);
      return null;
    }
  }
}

/**
 * Webhook utility
 */
class WebhookManager {
  /**
   * Register a webhook
   */
  static async register(userId, url, events, secret = null) {
    try {
      const result = await db.run(
        `INSERT INTO webhooks (user_id, url, events, secret)
         VALUES (?, ?, ?, ?)`,
        [userId, url, JSON.stringify(events), secret]
      );

      return result.id;
    } catch (error) {
      console.error('[Webhook] Register error:', error);
      return null;
    }
  }

  /**
   * Update webhook
   */
  static async update(webhookId, updates) {
    try {
      const { url, events, secret, isActive } = updates;
      const fields = [];
      const params = [];

      if (url) {
        fields.push('url = ?');
        params.push(url);
      }
      if (events) {
        fields.push('events = ?');
        params.push(JSON.stringify(events));
      }
      if (secret !== undefined) {
        fields.push('secret = ?');
        params.push(secret);
      }
      if (isActive !== undefined) {
        fields.push('is_active = ?');
        params.push(isActive ? 1 : 0);
      }

      if (fields.length === 0) return false;

      params.push(webhookId);
      await db.run(
        `UPDATE webhooks SET ${fields.join(', ')} WHERE id = ?`,
        params
      );

      return true;
    } catch (error) {
      console.error('[Webhook] Update error:', error);
      return false;
    }
  }

  /**
   * Delete webhook
   */
  static async delete(webhookId) {
    try {
      await db.run('DELETE FROM webhooks WHERE id = ?', [webhookId]);
      return true;
    } catch (error) {
      console.error('[Webhook] Delete error:', error);
      return false;
    }
  }

  /**
   * Get user webhooks
   */
  static async getByUser(userId) {
    try {
      const webhooks = await db.all(
        'SELECT * FROM webhooks WHERE user_id = ?',
        [userId]
      );

      return webhooks.map(wh => ({
        ...wh,
        events: JSON.parse(wh.events)
      }));
    } catch (error) {
      console.error('[Webhook] Get by user error:', error);
      return [];
    }
  }

  /**
   * Trigger webhooks for an event
   */
  static async trigger(userId, eventType, data) {
    try {
      const webhooks = await db.all(
        `SELECT * FROM webhooks 
         WHERE user_id = ? AND is_active = 1`,
        [userId]
      );

      const promises = webhooks
        .filter(wh => {
          const events = JSON.parse(wh.events);
          return events.includes(eventType) || events.includes('*');
        })
        .map(wh => this.sendWebhook(wh, eventType, data));

      await Promise.allSettled(promises);
    } catch (error) {
      console.error('[Webhook] Trigger error:', error);
    }
  }

  /**
   * Send webhook HTTP request
   */
  static async sendWebhook(webhook, eventType, data) {
    try {
      const payload = {
        event: eventType,
        timestamp: new Date().toISOString(),
        data: data
      };

      const headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'AI-Gateway-Webhook/1.0'
      };

      // Add signature if secret is set
      if (webhook.secret) {
        const signature = crypto
          .createHmac('sha256', webhook.secret)
          .update(JSON.stringify(payload))
          .digest('hex');
        headers['X-Webhook-Signature'] = signature;
      }

      const response = await axios.post(webhook.url, payload, {
        headers: headers,
        timeout: 10000 // 10 seconds
      });

      // Update last triggered time
      await db.run(
        'UPDATE webhooks SET last_triggered = datetime("now") WHERE id = ?',
        [webhook.id]
      );

      console.log(`[Webhook] Sent to ${webhook.url}: ${response.status}`);
      return true;
    } catch (error) {
      console.error(`[Webhook] Send error to ${webhook.url}:`, error.message);
      return false;
    }
  }

  /**
   * Test webhook
   */
  static async test(webhookId) {
    try {
      const webhook = await db.get(
        'SELECT * FROM webhooks WHERE id = ?',
        [webhookId]
      );

      if (!webhook) return { success: false, error: 'Webhook not found' };

      const testData = {
        message: 'This is a test webhook',
        test: true
      };

      const success = await this.sendWebhook(webhook, 'test', testData);
      return { success };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }
}

/**
 * Export data utility
 */
class DataExporter {
  /**
   * Export usage logs to CSV
   */
  static async exportUsageLogsCSV(userId = null, startDate = null, endDate = null) {
    try {
      let query = 'SELECT * FROM usage_logs WHERE 1=1';
      const params = [];

      if (userId) {
        query += ' AND user_id = ?';
        params.push(userId);
      }
      if (startDate) {
        query += ' AND created_at >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND created_at <= ?';
        params.push(endDate);
      }

      query += ' ORDER BY created_at DESC';

      const logs = await db.all(query, params);

      // Generate CSV
      const headers = [
        'ID', 'User ID', 'Model', 'Request Tokens', 'Response Tokens', 
        'Total Tokens', 'Response Time (ms)', 'Status', 'IP Address', 'Created At'
      ];

      const rows = logs.map(log => [
        log.id,
        log.user_id,
        log.model_alias,
        log.request_tokens,
        log.response_tokens,
        log.total_tokens,
        log.response_time_ms,
        log.status,
        log.ip_address,
        log.created_at
      ]);

      const csv = [
        headers.join(','),
        ...rows.map(row => row.map(cell => `"${cell || ''}"`).join(','))
      ].join('\n');

      return csv;
    } catch (error) {
      console.error('[Export] CSV error:', error);
      return null;
    }
  }

  /**
   * Export data to JSON
   */
  static async exportJSON(userId = null, includeUsage = true, includeAudit = false) {
    try {
      const data = {};

      // User info
      if (userId) {
        const user = await db.get(
          'SELECT id, username, email, role, group_id, created_at FROM users WHERE id = ?',
          [userId]
        );
        data.user = user;
      }

      // Usage logs
      if (includeUsage) {
        let query = 'SELECT * FROM usage_logs WHERE 1=1';
        const params = [];
        
        if (userId) {
          query += ' AND user_id = ?';
          params.push(userId);
        }
        
        query += ' ORDER BY created_at DESC LIMIT 1000';
        data.usage_logs = await db.all(query, params);
      }

      // Audit logs
      if (includeAudit) {
        let query = 'SELECT * FROM audit_logs WHERE 1=1';
        const params = [];
        
        if (userId) {
          query += ' AND user_id = ?';
          params.push(userId);
        }
        
        query += ' ORDER BY created_at DESC LIMIT 1000';
        data.audit_logs = await db.all(query, params);
      }

      return data;
    } catch (error) {
      console.error('[Export] JSON error:', error);
      return null;
    }
  }
}

module.exports = {
  ResponseCache,
  WebhookManager,
  DataExporter
};
