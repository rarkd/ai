const db = require('../database/db');

/**
 * Audit logging utility
 */
class AuditLogger {
  /**
   * Log an audit event
   */
  static async log(data) {
    try {
      const { userId, action, entityType, entityId, details, ipAddress, userAgent } = data;
      
      await db.run(
        `INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details, ip_address, user_agent)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          userId || null,
          action,
          entityType || null,
          entityId || null,
          details ? JSON.stringify(details) : null,
          ipAddress || null,
          userAgent || null
        ]
      );
    } catch (error) {
      console.error('[Audit Log] Error:', error);
    }
  }

  /**
   * Get audit logs with filters
   */
  static async getLogs(filters = {}) {
    try {
      const { userId, action, entityType, startDate, endDate, limit = 100, offset = 0 } = filters;
      
      let query = 'SELECT * FROM audit_logs WHERE 1=1';
      const params = [];

      if (userId) {
        query += ' AND user_id = ?';
        params.push(userId);
      }
      if (action) {
        query += ' AND action = ?';
        params.push(action);
      }
      if (entityType) {
        query += ' AND entity_type = ?';
        params.push(entityType);
      }
      if (startDate) {
        query += ' AND created_at >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND created_at <= ?';
        params.push(endDate);
      }

      query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
      params.push(limit, offset);

      const logs = await db.all(query, params);
      
      // Parse details JSON
      return logs.map(log => ({
        ...log,
        details: log.details ? JSON.parse(log.details) : null
      }));
    } catch (error) {
      console.error('[Audit Log] Get logs error:', error);
      return [];
    }
  }

  /**
   * Cleanup old audit logs (older than specified days)
   */
  static async cleanup(daysToKeep = 90) {
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);
      
      const result = await db.run(
        'DELETE FROM audit_logs WHERE created_at < ?',
        [cutoffDate.toISOString()]
      );
      
      console.log(`[Audit Log] Cleaned up ${result.changes} old records`);
      return result.changes;
    } catch (error) {
      console.error('[Audit Log] Cleanup error:', error);
      return 0;
    }
  }
}

/**
 * Usage analytics utility
 */
class UsageAnalytics {
  /**
   * Log API usage
   */
  static async logUsage(data) {
    try {
      const {
        userId,
        modelAlias,
        requestTokens = 0,
        responseTokens = 0,
        totalTokens = 0,
        responseTimeMs = 0,
        status = 'success',
        errorMessage = null,
        ipAddress = null,
        userAgent = null
      } = data;

      await db.run(
        `INSERT INTO usage_logs (
          user_id, model_alias, request_tokens, response_tokens, 
          total_tokens, response_time_ms, status, error_message,
          ip_address, user_agent
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          userId,
          modelAlias,
          requestTokens,
          responseTokens,
          totalTokens,
          responseTimeMs,
          status,
          errorMessage,
          ipAddress,
          userAgent
        ]
      );
    } catch (error) {
      console.error('[Usage Analytics] Log error:', error);
    }
  }

  /**
   * Get usage statistics for a user
   */
  static async getUserStats(userId, startDate = null, endDate = null) {
    try {
      let query = `
        SELECT 
          COUNT(*) as total_requests,
          SUM(total_tokens) as total_tokens,
          AVG(response_time_ms) as avg_response_time,
          SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successful_requests,
          SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as failed_requests
        FROM usage_logs
        WHERE user_id = ?
      `;
      const params = [userId];

      if (startDate) {
        query += ' AND created_at >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND created_at <= ?';
        params.push(endDate);
      }

      const stats = await db.get(query, params);

      // Get model usage breakdown
      let modelQuery = `
        SELECT 
          model_alias,
          COUNT(*) as count,
          SUM(total_tokens) as tokens
        FROM usage_logs
        WHERE user_id = ?
      `;
      const modelParams = [userId];

      if (startDate) {
        modelQuery += ' AND created_at >= ?';
        modelParams.push(startDate);
      }
      if (endDate) {
        modelQuery += ' AND created_at <= ?';
        modelParams.push(endDate);
      }

      modelQuery += ' GROUP BY model_alias ORDER BY count DESC';
      const modelStats = await db.all(modelQuery, modelParams);

      return {
        ...stats,
        models: modelStats
      };
    } catch (error) {
      console.error('[Usage Analytics] Get user stats error:', error);
      return null;
    }
  }

  /**
   * Get system-wide statistics
   */
  static async getSystemStats(startDate = null, endDate = null) {
    try {
      let query = `
        SELECT 
          COUNT(DISTINCT user_id) as active_users,
          COUNT(*) as total_requests,
          SUM(total_tokens) as total_tokens,
          AVG(response_time_ms) as avg_response_time,
          SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successful_requests,
          SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as failed_requests
        FROM usage_logs
        WHERE 1=1
      `;
      const params = [];

      if (startDate) {
        query += ' AND created_at >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND created_at <= ?';
        params.push(endDate);
      }

      const stats = await db.get(query, params);

      // Get top users
      let topUsersQuery = `
        SELECT 
          u.id,
          u.username,
          u.email,
          COUNT(*) as request_count,
          SUM(ul.total_tokens) as total_tokens
        FROM usage_logs ul
        JOIN users u ON ul.user_id = u.id
        WHERE 1=1
      `;
      const topUsersParams = [];

      if (startDate) {
        topUsersQuery += ' AND ul.created_at >= ?';
        topUsersParams.push(startDate);
      }
      if (endDate) {
        topUsersQuery += ' AND ul.created_at <= ?';
        topUsersParams.push(endDate);
      }

      topUsersQuery += ' GROUP BY u.id ORDER BY request_count DESC LIMIT 10';
      const topUsers = await db.all(topUsersQuery, topUsersParams);

      // Get model usage
      let modelQuery = `
        SELECT 
          model_alias,
          COUNT(*) as count,
          SUM(total_tokens) as tokens
        FROM usage_logs
        WHERE 1=1
      `;
      const modelParams = [];

      if (startDate) {
        modelQuery += ' AND created_at >= ?';
        modelParams.push(startDate);
      }
      if (endDate) {
        modelQuery += ' AND created_at <= ?';
        modelParams.push(endDate);
      }

      modelQuery += ' GROUP BY model_alias ORDER BY count DESC';
      const modelStats = await db.all(modelQuery, modelParams);

      return {
        ...stats,
        top_users: topUsers,
        models: modelStats
      };
    } catch (error) {
      console.error('[Usage Analytics] Get system stats error:', error);
      return null;
    }
  }

  /**
   * Get usage trends (daily breakdown)
   */
  static async getUsageTrends(userId = null, days = 30) {
    try {
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);

      let query = `
        SELECT 
          DATE(created_at) as date,
          COUNT(*) as requests,
          SUM(total_tokens) as tokens,
          AVG(response_time_ms) as avg_response_time
        FROM usage_logs
        WHERE created_at >= ?
      `;
      const params = [startDate.toISOString()];

      if (userId) {
        query += ' AND user_id = ?';
        params.push(userId);
      }

      query += ' GROUP BY DATE(created_at) ORDER BY date ASC';

      const trends = await db.all(query, params);
      return trends;
    } catch (error) {
      console.error('[Usage Analytics] Get trends error:', error);
      return [];
    }
  }

  /**
   * Cleanup old usage logs
   */
  static async cleanup(daysToKeep = 90) {
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);
      
      const result = await db.run(
        'DELETE FROM usage_logs WHERE created_at < ?',
        [cutoffDate.toISOString()]
      );
      
      console.log(`[Usage Analytics] Cleaned up ${result.changes} old records`);
      return result.changes;
    } catch (error) {
      console.error('[Usage Analytics] Cleanup error:', error);
      return 0;
    }
  }
}

module.exports = {
  AuditLogger,
  UsageAnalytics
};
