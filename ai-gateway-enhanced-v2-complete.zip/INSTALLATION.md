# AI Gateway Enhanced - Installation & Setup Guide

## 📋 Prerequisites

- **Node.js**: v16.0.0 or higher
- **npm**: v7.0.0 or higher
- **SQLite3**: Included with Node.js sqlite3 package
- **OS**: Linux, macOS, or Windows with WSL

## 🚀 Quick Start (5 Minutes)

### 1. Extract and Navigate
```bash
cd ai-gateway-enhanced
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Setup Environment
The `.env` file is already created with a secure JWT secret. You can modify it if needed:

```bash
nano .env  # or use your favorite editor
```

Default configuration:
```env
PORT=422
JWT_SECRET=<randomly-generated-secure-key>
OLLAMA_BASE_URL=https://aiapi.awwlk.my.id
DATABASE_PATH=./data/gateway.db
```

### 4. Initialize Database
```bash
npm run init-db-enhanced
```

This creates:
- ✅ SQLite database at `./data/gateway.db`
- ✅ All necessary tables with indices
- ✅ Default admin user (username: `admin`, password: `admin123`)
- ✅ Four user groups (Free, Basic, Pro, Enterprise)
- ✅ Default model mappings
- ✅ Sample group-model assignments

### 5. Start the Server
```bash
npm start
```

Or for development with auto-reload:
```bash
npm run dev
```

### 6. Access Dashboards

Open your browser:

- **Admin Dashboard**: http://localhost:422/admin.html
  - Login: `admin@gateway.local` / `admin123`
  - ⚠️ **CHANGE THIS PASSWORD IMMEDIATELY!**

- **User Dashboard**: http://localhost:422/user.html
  - Create users via admin dashboard first

## 📦 Installation Methods

### Method 1: Standard Installation (Recommended)

```bash
# Clone or extract
cd ai-gateway-enhanced

# Install
npm install

# Initialize
npm run init-db-enhanced

# Start
npm start
```

### Method 2: Using Installation Script

```bash
chmod +x install.sh
./install.sh
```

The script will:
1. Check Node.js installation
2. Install dependencies
3. Create `.env` if needed
4. Generate random JWT secret
5. Create data directory
6. Initialize database
7. Display next steps

### Method 3: Production with PM2

```bash
# Install PM2 globally (if not installed)
npm install -g pm2

# Install dependencies
npm install

# Initialize database
npm run init-db-enhanced

# Start with PM2
npm run pm2:start

# Check status
pm2 status

# View logs
pm2 logs ai-gateway-enhanced

# Restart
npm run pm2:restart

# Stop
npm run pm2:stop
```

## 🔧 Configuration

### Environment Variables

Create or edit `.env` file:

```env
# Server Configuration
PORT=422

# Security (REQUIRED)
JWT_SECRET=your-super-secret-jwt-key-min-32-characters

# Ollama API
OLLAMA_BASE_URL=https://aiapi.awwlk.my.id

# Database
DATABASE_PATH=./data/gateway.db

# Admin Defaults (Optional)
DEFAULT_ADMIN_USERNAME=admin
DEFAULT_ADMIN_EMAIL=admin@gateway.local
DEFAULT_ADMIN_PASSWORD=admin123

# Cache Settings (Optional)
CACHE_TTL_MINUTES=60

# Cleanup Settings (Optional)
CLEANUP_USAGE_LOGS_DAYS=90
CLEANUP_AUDIT_LOGS_DAYS=90
CLEANUP_RATE_LIMITS_DAYS=2
```

### Generate Secure JWT Secret

```bash
# Linux/macOS
openssl rand -hex 32

# Windows (PowerShell)
[Convert]::ToBase64String((1..32 | %{ Get-Random -Maximum 256 }))

# Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Update `JWT_SECRET` in `.env` with the generated value.

### Database Configuration

Default location: `./data/gateway.db`

To change:
```env
DATABASE_PATH=/path/to/your/database.db
```

Ensure the directory exists and is writable.

### Port Configuration

Default port: `422`

To change:
```env
PORT=8080
```

Or use command-line:
```bash
PORT=8080 npm start
```

## 🗄️ Database Setup

### Initialize New Database

```bash
npm run init-db-enhanced
```

### What Gets Created?

**Tables:**
- `users` - User accounts
- `groups` - User groups with limits
- `group_models` - Model access per group
- `user_domains` - CORS whitelist
- `api_keys` - API authentication keys
- `model_mappings` - Model aliases
- `usage_logs` - Detailed usage tracking
- `audit_logs` - Activity audit trail
- `rate_limits` - Rate limiting data
- `webhooks` - Webhook configurations
- `password_reset_tokens` - Password reset flow
- `response_cache` - Response caching

**Indices:** (for performance)
- Usage logs: user_id, created_at
- Audit logs: user_id, created_at
- Rate limits: user_id, window_start
- Cache: cache_key, expires_at

**Default Data:**

Admin User:
- Username: `admin`
- Email: `admin@gateway.local`
- Password: `admin123`
- Role: `admin`

Groups:
| ID | Name | Req/Hour | Req/Day | Max Tokens |
|----|------|----------|---------|------------|
| 1 | Free | 10 | 100 | 2,000 |
| 2 | Basic | 50 | 500 | 4,000 |
| 3 | Pro | 200 | 2,000 | 8,000 |
| 4 | Enterprise | 1,000 | 10,000 | 16,000 |

Model Mappings:
- gpt-3.5-turbo → llama3.2:latest
- gpt-4 → llama3.2:latest
- gpt-4-turbo → llama3.2:latest
- claude-3-sonnet → llama3.2:latest
- claude-3-opus → llama3.2:latest
- claude-3-haiku → llama3.2:latest

### Reset Database

⚠️ **Warning**: This will delete all data!

```bash
rm ./data/gateway.db
npm run init-db-enhanced
```

### Backup Database

```bash
# Create backup
cp ./data/gateway.db ./data/gateway.db.backup-$(date +%Y%m%d)

# Restore from backup
cp ./data/gateway.db.backup-YYYYMMDD ./data/gateway.db
```

### Database Migration

If upgrading from basic version:

```bash
# 1. Backup existing database
cp ./data/gateway.db ./data/gateway.db.old

# 2. The enhanced init script will add new tables
npm run init-db-enhanced

# 3. Existing data remains intact
```

## 🔐 Security Setup

### 1. Change Default Admin Password

**Via Dashboard:**
1. Login to admin dashboard
2. Go to Profile/Settings
3. Change password
4. Logout and login with new password

**Via API:**
```bash
curl -X POST http://localhost:422/auth/change-password \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "old_password": "admin123",
    "new_password": "your-secure-password"
  }'
```

### 2. Setup CORS Domains

For each user that will access from browser:

```bash
curl -X POST http://localhost:422/user/domains \
  -H "Authorization: Bearer USER_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"domain": "yourdomain.com"}'
```

### 3. Generate API Keys

For programmatic access:

```bash
curl -X POST http://localhost:422/user/api-keys \
  -H "Authorization: Bearer USER_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Production Key",
    "expires_in_days": 365
  }'
```

Save the returned API key securely!

### 4. Setup HTTPS (Production)

Use nginx as reverse proxy:

```nginx
server {
    listen 443 ssl http2;
    server_name your-domain.com;

    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    location / {
        proxy_pass http://localhost:422;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## 🧪 Testing the Installation

### 1. Health Check
```bash
curl http://localhost:422/api/health
```

Expected response:
```json
{
  "status": "ok",
  "timestamp": "2026-03-01T14:30:00.000Z"
}
```

### 2. Login Test
```bash
curl -X POST http://localhost:422/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@gateway.local",
    "password": "admin123"
  }'
```

Expected: JWT token in response

### 3. AI Request Test
```bash
curl -X POST http://localhost:422/api/gpt-3.5-turbo \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Say hello!"
  }'
```

Expected: AI response

### 4. Access Dashboards

Open browser:
- http://localhost:422/admin.html
- http://localhost:422/user.html

Should see login pages.

## 📊 Monitoring Setup

### PM2 Monitoring

```bash
# Real-time monitoring
pm2 monit

# Status
pm2 status

# Logs
pm2 logs ai-gateway-enhanced

# Detailed info
pm2 info ai-gateway-enhanced
```

### Log Files

Logs are written to:
- PM2 logs: `~/.pm2/logs/`
- Console output: stdout/stderr

### Health Monitoring

Setup automated health checks:

```bash
# Cron job (every 5 minutes)
*/5 * * * * curl -f http://localhost:422/api/health || echo "Gateway down!" | mail -s "Alert" admin@example.com
```

Or use dedicated monitoring tools:
- Uptime Robot
- Pingdom
- New Relic
- DataDog

## 🐛 Troubleshooting

### Port Already in Use

```bash
# Find process using port
lsof -i :422

# Kill process
kill -9 <PID>

# Or use different port
PORT=8080 npm start
```

### Database Locked

```bash
# Check if another process is using the database
lsof ./data/gateway.db

# Stop all processes
pm2 stop all

# Restart
pm2 start ecosystem.config.js
```

### Module Not Found

```bash
# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

### Permission Denied

```bash
# Fix permissions
chmod -R 755 .
chmod 644 .env
chmod 644 ./data/gateway.db
```

### Database Corruption

```bash
# Backup
cp ./data/gateway.db ./data/gateway.db.broken

# Check integrity
sqlite3 ./data/gateway.db "PRAGMA integrity_check;"

# Restore from backup or reinitialize
```

## 🔄 Maintenance

### Regular Tasks

**Daily:**
- Monitor logs for errors
- Check rate limit hits
- Review failed requests

**Weekly:**
- Check database size
- Review cache hit rates
- Analyze usage trends

**Monthly:**
- Update dependencies: `npm update`
- Review and adjust rate limits
- Clean up old test data
- Backup database

### Database Maintenance

```bash
# Check database size
du -h ./data/gateway.db

# Optimize database (VACUUM)
sqlite3 ./data/gateway.db "VACUUM;"

# Check table sizes
sqlite3 ./data/gateway.db "
SELECT name, COUNT(*) as count 
FROM sqlite_master 
WHERE type='table' 
GROUP BY name;"
```

### Update Dependencies

```bash
# Check for updates
npm outdated

# Update all
npm update

# Update specific package
npm update express

# Audit security
npm audit
npm audit fix
```

## 🚀 Performance Tuning

### Node.js Optimization

```bash
# Increase memory limit
NODE_OPTIONS="--max-old-space-size=4096" npm start

# Enable production mode
NODE_ENV=production npm start
```

### Database Optimization

```sql
-- Run in sqlite3 CLI
.timer on
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA cache_size = 10000;
PRAGMA temp_store = MEMORY;
ANALYZE;
```

### PM2 Cluster Mode

```javascript
// ecosystem.config.js
module.exports = {
  apps: [{
    name: 'ai-gateway-enhanced',
    script: './src/server.js',
    instances: 4,  // Use 4 CPU cores
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production'
    }
  }]
};
```

## 📚 Additional Resources

- [Feature Documentation](FEATURES.md)
- [API Reference](API.md)
- [Security Best Practices](SECURITY.md)
- [Troubleshooting Guide](TROUBLESHOOTING.md)

## 🆘 Support

If you encounter issues:

1. Check this guide
2. Review error logs
3. Check database integrity
4. Test with curl commands
5. Create detailed issue report

---

**Version:** 2.0.0 Enhanced  
**Last Updated:** March 2026
