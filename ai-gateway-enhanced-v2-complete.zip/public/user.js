const API_URL = window.location.origin;
let authToken = localStorage.getItem('userToken');
let currentUser = null;

// Check authentication on page load
window.addEventListener('DOMContentLoaded', () => {
    if (authToken) {
        verifyAuth();
    }
});

// Login form submission
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (response.ok) {
            authToken = data.token;
            currentUser = data.user;
            localStorage.setItem('userToken', authToken);
            showDashboard();
        } else {
            showLoginError(data.message || 'Login failed');
        }
    } catch (error) {
        showLoginError('Connection error. Please try again.');
    }
});

async function verifyAuth() {
    try {
        const response = await fetch(`${API_URL}/auth/me`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            currentUser = data.user;
            showDashboard();
        } else {
            logout();
        }
    } catch (error) {
        console.error('Auth verification failed:', error);
        logout();
    }
}

function showDashboard() {
    document.getElementById('loginContainer').classList.add('hidden');
    document.getElementById('dashboardContainer').classList.remove('hidden');
    document.getElementById('userName').textContent = currentUser.username;
    document.getElementById('userGroup').textContent = currentUser.group_name || 'No Group';
    
    // Set API endpoint
    document.getElementById('apiEndpoint').textContent = `${API_URL}/api/{model}`;
    
    loadModels();
    loadDomains();
    loadApiKeys();
    updateExampleCode();
}

function showLoginError(message) {
    const errorDiv = document.getElementById('loginError');
    errorDiv.innerHTML = `<div class="alert alert-error">${message}</div>`;
    setTimeout(() => {
        errorDiv.innerHTML = '';
    }, 5000);
}

function logout() {
    localStorage.removeItem('userToken');
    authToken = null;
    currentUser = null;
    document.getElementById('loginContainer').classList.remove('hidden');
    document.getElementById('dashboardContainer').classList.add('hidden');
}

async function loadModels() {
    try {
        const response = await fetch(`${API_URL}/user/models`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            
            if (data.models.length === 0) {
                document.getElementById('noGroupAlert').classList.remove('hidden');
                document.getElementById('modelsGrid').innerHTML = '';
            } else {
                document.getElementById('noGroupAlert').classList.add('hidden');
                renderModels(data.models);
            }
        }
    } catch (error) {
        console.error('Failed to load models:', error);
    }
}

function renderModels(models) {
    const grid = document.getElementById('modelsGrid');
    grid.innerHTML = models.map(model => `
        <div class="model-card">
            <h3>${model.model_alias}</h3>
            <p>→ ${model.model_name}</p>
        </div>
    `).join('');
}

async function loadDomains() {
    try {
        const response = await fetch(`${API_URL}/user/domains`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            renderDomains(data.domains);
        }
    } catch (error) {
        console.error('Failed to load domains:', error);
    }
}

function renderDomains(domains) {
    const list = document.getElementById('domainsList');
    
    if (domains.length === 0) {
        list.innerHTML = '<li class="domain-item"><em>Belum ada domain yang ditambahkan</em></li>';
        return;
    }
    
    list.innerHTML = domains.map(domain => `
        <li class="domain-item">
            <code>${domain.domain}</code>
            <button class="btn btn-danger btn-small" onclick="deleteDomain(${domain.id})">Hapus</button>
        </li>
    `).join('');
}

async function loadApiKeys() {
    try {
        const response = await fetch(`${API_URL}/user/api-keys`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            renderApiKeys(data.apiKeys);
        }
    } catch (error) {
        console.error('Failed to load API keys:', error);
    }
}

function renderApiKeys(apiKeys) {
    const list = document.getElementById('apiKeysList');
    
    if (apiKeys.length === 0) {
        list.innerHTML = '<p><em>Belum ada API key. Buat API key untuk akses programmatik.</em></p>';
        return;
    }
    
    list.innerHTML = apiKeys.map(key => `
        <div class="api-key-item">
            <div class="api-key-info">
                <strong>${key.name || 'Unnamed Key'}</strong><br>
                <small>Prefix: ${key.key_prefix}... | Created: ${new Date(key.created_at).toLocaleDateString()}</small>
                ${key.last_used ? `<br><small>Last used: ${new Date(key.last_used).toLocaleString()}</small>` : ''}
            </div>
            <button class="btn btn-danger btn-small" onclick="deleteApiKey(${key.id})">Delete</button>
        </div>
    `).join('');
}

function showAddDomainForm() {
    document.getElementById('addDomainForm').classList.remove('hidden');
}

function hideAddDomainForm() {
    document.getElementById('addDomainForm').classList.add('hidden');
    document.getElementById('domainForm').reset();
}

function showCreateApiKeyForm() {
    document.getElementById('createApiKeyForm').classList.remove('hidden');
}

function hideCreateApiKeyForm() {
    document.getElementById('createApiKeyForm').classList.add('hidden');
    document.getElementById('apiKeyForm').reset();
}

// Add Domain Form
document.getElementById('domainForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());

    try {
        const response = await fetch(`${API_URL}/user/domains`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            alert('Domain berhasil ditambahkan!');
            hideAddDomainForm();
            loadDomains();
        } else {
            const error = await response.json();
            alert('Error: ' + (error.message || error.error));
        }
    } catch (error) {
        alert('Connection error');
    }
});

// Create API Key Form
document.getElementById('apiKeyForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());

    try {
        const response = await fetch(`${API_URL}/user/api-keys`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            const result = await response.json();
            
            // Show the new API key (only shown once)
            const alertDiv = document.getElementById('newApiKeyAlert');
            alertDiv.className = 'alert alert-success';
            alertDiv.innerHTML = `
                <strong>✅ API Key berhasil dibuat!</strong><br>
                <strong>⚠️ SIMPAN KEY INI SEKARANG! Anda tidak akan bisa melihatnya lagi.</strong><br>
                <code style="background: #2d2d2d; color: #4af; padding: 10px; display: block; margin-top: 10px; border-radius: 5px; font-size: 14px;">
                    ${result.apiKey}
                </code>
                <button class="btn btn-primary btn-small" style="margin-top: 10px;" 
                        onclick="navigator.clipboard.writeText('${result.apiKey}').then(() => alert('Copied to clipboard!'))">
                    Copy to Clipboard
                </button>
            `;
            alertDiv.classList.remove('hidden');
            
            setTimeout(() => {
                alertDiv.classList.add('hidden');
            }, 60000); // Hide after 1 minute
            
            hideCreateApiKeyForm();
            loadApiKeys();
        } else {
            const error = await response.json();
            alert('Error: ' + (error.message || error.error));
        }
    } catch (error) {
        alert('Connection error');
    }
});

async function deleteDomain(domainId) {
    if (!confirm('Yakin ingin menghapus domain ini?')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/user/domains/${domainId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            loadDomains();
        } else {
            alert('Failed to delete domain');
        }
    } catch (error) {
        alert('Connection error');
    }
}

async function deleteApiKey(keyId) {
    if (!confirm('Yakin ingin menghapus API key ini?')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/user/api-keys/${keyId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            loadApiKeys();
        } else {
            alert('Failed to delete API key');
        }
    } catch (error) {
        alert('Connection error');
    }
}

function updateExampleCode() {
    const exampleCode = `// Using JWT Token
fetch('${API_URL}/api/gpt-3.5-turbo', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_JWT_TOKEN'
  },
  body: JSON.stringify({
    prompt: 'Hello, how are you?',
    stream: false
  })
});

// Using API Key
fetch('${API_URL}/api/gpt-3.5-turbo', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-API-Key': 'gw_your_api_key_here'
  },
  body: JSON.stringify({
    prompt: 'Hello, how are you?',
    stream: false
  })
});`;

    document.getElementById('exampleCode').textContent = exampleCode;
}
