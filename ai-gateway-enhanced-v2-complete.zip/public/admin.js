const API_URL = window.location.origin;
let authToken = localStorage.getItem('adminToken');
let currentUser = null;

// Check authentication on page load
window.addEventListener('DOMContentLoaded', () => {
    if (authToken) {
        verifyAuth();
    }
});

// Login form submission
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (response.ok) {
            if (data.user.role !== 'admin') {
                showLoginError('Access denied. Admin privileges required.');
                return;
            }

            authToken = data.token;
            currentUser = data.user;
            localStorage.setItem('adminToken', authToken);
            showDashboard();
        } else {
            showLoginError(data.message || 'Login failed');
        }
    } catch (error) {
        showLoginError('Connection error. Please try again.');
    }
});

async function verifyAuth() {
    try {
        const response = await fetch(`${API_URL}/auth/me`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            if (data.user.role !== 'admin') {
                logout();
                return;
            }
            currentUser = data.user;
            showDashboard();
        } else {
            logout();
        }
    } catch (error) {
        console.error('Auth verification failed:', error);
        logout();
    }
}

function showDashboard() {
    document.getElementById('loginContainer').classList.add('hidden');
    document.getElementById('dashboardContainer').classList.remove('hidden');
    document.getElementById('adminName').textContent = currentUser.username;
    
    loadStats();
    loadUsers();
    loadGroups();
}

function showLoginError(message) {
    const errorDiv = document.getElementById('loginError');
    errorDiv.innerHTML = `<div class="alert alert-error">${message}</div>`;
    setTimeout(() => {
        errorDiv.innerHTML = '';
    }, 5000);
}

function logout() {
    localStorage.removeItem('adminToken');
    authToken = null;
    currentUser = null;
    document.getElementById('loginContainer').classList.remove('hidden');
    document.getElementById('dashboardContainer').classList.add('hidden');
}

function showTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    event.target.classList.add('active');

    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    document.getElementById(`${tabName}Tab`).classList.add('active');

    // Reload data for the tab
    if (tabName === 'stats') loadStats();
    if (tabName === 'users') loadUsers();
    if (tabName === 'groups') loadGroups();
}

async function loadStats() {
    try {
        const response = await fetch(`${API_URL}/admin/stats`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            document.getElementById('totalUsers').textContent = data.stats.total_users;
            document.getElementById('totalGroups').textContent = data.stats.total_groups;
            document.getElementById('bannedUsers').textContent = data.stats.banned_users;
            document.getElementById('activeUsers').textContent = data.stats.active_users_7d;
        }
    } catch (error) {
        console.error('Failed to load stats:', error);
    }
}

async function loadUsers() {
    try {
        const response = await fetch(`${API_URL}/admin/users`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            renderUsersTable(data.users);
        }
    } catch (error) {
        console.error('Failed to load users:', error);
    }
}

function renderUsersTable(users) {
    const tbody = document.querySelector('#usersTable tbody');
    tbody.innerHTML = users.map(user => `
        <tr>
            <td>${user.username}</td>
            <td>${user.email}</td>
            <td><span class="badge badge-${user.role}">${user.role}</span></td>
            <td>${user.group_name || '-'}</td>
            <td><span class="badge ${user.is_banned ? 'badge-banned' : 'badge-active'}">
                ${user.is_banned ? 'Banned' : 'Active'}
            </span></td>
            <td>
                <button class="btn btn-primary btn-small" onclick="editUser(${user.id})">Edit</button>
                <button class="btn btn-${user.is_banned ? 'success' : 'warning'} btn-small" 
                        onclick="toggleBan(${user.id}, ${!user.is_banned})">
                    ${user.is_banned ? 'Unban' : 'Ban'}
                </button>
                <button class="btn btn-danger btn-small" onclick="deleteUser(${user.id})">Delete</button>
                <button class="btn btn-small" onclick="manageUserDomains(${user.id})">Domains</button>
            </td>
        </tr>
    `).join('');
}

async function loadGroups() {
    try {
        const response = await fetch(`${API_URL}/admin/groups`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            renderGroupsTable(data.groups);
            populateGroupSelects(data.groups);
        }
    } catch (error) {
        console.error('Failed to load groups:', error);
    }
}

function renderGroupsTable(groups) {
    const tbody = document.querySelector('#groupsTable tbody');
    tbody.innerHTML = groups.map(group => `
        <tr>
            <td><strong>${group.name}</strong></td>
            <td>${group.description || '-'}</td>
            <td>${group.user_count}</td>
            <td>
                <button class="btn btn-primary btn-small" onclick="manageGroupModels(${group.id})">Models</button>
                <button class="btn btn-small" onclick="editGroup(${group.id})">Edit</button>
                <button class="btn btn-danger btn-small" onclick="deleteGroup(${group.id})">Delete</button>
            </td>
        </tr>
    `).join('');
}

function populateGroupSelects(groups) {
    const selects = [
        document.getElementById('createUserGroupSelect'),
        document.getElementById('editUserGroupSelect')
    ];

    selects.forEach(select => {
        if (select) {
            select.innerHTML = '<option value="">Tidak ada grup</option>' +
                groups.map(g => `<option value="${g.id}">${g.name}</option>`).join('');
        }
    });
}

function showCreateUserModal() {
    document.getElementById('createUserModal').classList.add('active');
}

function showCreateGroupModal() {
    document.getElementById('createGroupModal').classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

// Create User Form
document.getElementById('createUserForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());

    try {
        const response = await fetch(`${API_URL}/admin/users`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            alert('User berhasil ditambahkan!');
            closeModal('createUserModal');
            e.target.reset();
            loadUsers();
        } else {
            const error = await response.json();
            alert('Error: ' + (error.message || 'Failed to create user'));
        }
    } catch (error) {
        alert('Connection error');
    }
});

// Create Group Form
document.getElementById('createGroupForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());

    try {
        const response = await fetch(`${API_URL}/admin/groups`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            alert('Grup berhasil ditambahkan!');
            closeModal('createGroupModal');
            e.target.reset();
            loadGroups();
        } else {
            const error = await response.json();
            alert('Error: ' + (error.message || 'Failed to create group'));
        }
    } catch (error) {
        alert('Connection error');
    }
});

async function editUser(userId) {
    try {
        const response = await fetch(`${API_URL}/admin/users/${userId}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            const form = document.getElementById('editUserForm');
            form.id.value = data.user.id;
            form.username.value = data.user.username;
            form.email.value = data.user.email;
            form.role.value = data.user.role;
            form.group_id.value = data.user.group_id || '';
            document.getElementById('editUserModal').classList.add('active');
        }
    } catch (error) {
        alert('Failed to load user data');
    }
}

document.getElementById('editUserForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());
    const userId = data.id;
    delete data.id;

    try {
        const response = await fetch(`${API_URL}/admin/users/${userId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            alert('User berhasil diupdate!');
            closeModal('editUserModal');
            loadUsers();
        } else {
            alert('Failed to update user');
        }
    } catch (error) {
        alert('Connection error');
    }
});

async function toggleBan(userId, shouldBan) {
    if (!confirm(`Are you sure you want to ${shouldBan ? 'ban' : 'unban'} this user?`)) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/admin/users/${userId}/ban`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ is_banned: shouldBan })
        });

        if (response.ok) {
            loadUsers();
        } else {
            alert('Failed to update user status');
        }
    } catch (error) {
        alert('Connection error');
    }
}

async function deleteUser(userId) {
    if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/admin/users/${userId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            alert('User deleted successfully');
            loadUsers();
        } else {
            alert('Failed to delete user');
        }
    } catch (error) {
        alert('Connection error');
    }
}

async function deleteGroup(groupId) {
    if (!confirm('Are you sure you want to delete this group?')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/admin/groups/${groupId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            alert('Group deleted successfully');
            loadGroups();
        } else {
            const error = await response.json();
            alert('Error: ' + (error.message || 'Failed to delete group'));
        }
    } catch (error) {
        alert('Connection error');
    }
}

function manageUserDomains(userId) {
    alert('Domain management feature coming soon!');
    // TODO: Implement domain management modal
}

function manageGroupModels(groupId) {
    alert('Model management feature coming soon!');
    // TODO: Implement model management modal
}

function editGroup(groupId) {
    alert('Edit group feature coming soon!');
    // TODO: Implement edit group modal
}
