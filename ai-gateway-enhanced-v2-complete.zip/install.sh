#!/bin/bash

echo "=================================="
echo "AI Gateway Enhanced - Installation"
echo "=================================="
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    exit 1
fi

echo "✓ Node.js found: $(node --version)"
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
npm install
if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi
echo "✓ Dependencies installed"
echo ""

# Setup .env file
if [ ! -f .env ]; then
    echo "⚙️  Setting up environment file..."
    cp .env.example .env
    
    # Generate random JWT secret
    JWT_SECRET=$(openssl rand -hex 32 2>/dev/null || head /dev/urandom | tr -dc A-Za-z0-9 | head -c 64)
    
    # Update .env with generated secret
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        sed -i '' "s/change-this-to-a-random-secure-secret-key-in-production/$JWT_SECRET/" .env
    else
        # Linux
        sed -i "s/change-this-to-a-random-secure-secret-key-in-production/$JWT_SECRET/" .env
    fi
    
    echo "✓ Environment file created with random JWT secret"
    echo "  Please review and update .env file if needed"
else
    echo "⚠️  .env file already exists, skipping..."
fi
echo ""

# Create data directory
if [ ! -d data ]; then
    echo "📁 Creating data directory..."
    mkdir -p data
    echo "✓ Data directory created"
else
    echo "✓ Data directory exists"
fi
echo ""

# Initialize database
echo "🗄️  Initializing database..."
npm run init-db
if [ $? -ne 0 ]; then
    echo "❌ Failed to initialize database"
    exit 1
fi
echo ""

echo "=================================="
echo "✅ Installation Complete!"
echo "=================================="
echo ""
echo "Next steps:"
echo "1. Review .env file and update if needed"
echo "2. Start the server:"
echo "   - Development: npm run dev"
echo "   - Production:  npm start"
echo "   - With PM2:    npm run pm2:start"
echo ""
echo "3. Access dashboards:"
echo "   - Admin: http://localhost:422/admin.html"
echo "   - User:  http://localhost:422/user.html"
echo ""
echo "4. Default admin credentials:"
echo "   Email:    admin@gateway.local"
echo "   Password: admin123"
echo "   ⚠️  CHANGE THIS PASSWORD AFTER FIRST LOGIN!"
echo ""
echo "=================================="
