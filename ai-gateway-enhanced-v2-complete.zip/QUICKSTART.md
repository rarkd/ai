# 🚀 Quick Start Guide - AI Gateway Enhanced v2.0

Get started in **5 minutes**!

## Step 1: Install Dependencies (1 min)

```bash
cd ai-gateway-enhanced
npm install
```

## Step 2: Initialize Database (30 seconds)

```bash
npm run init-db-enhanced
```

This creates:
- ✅ SQLite database with all tables
- ✅ Admin user (admin@gateway.local / admin123)
- ✅ 4 user groups (Free, Basic, Pro, Enterprise)
- ✅ 6 model mappings
- ✅ Performance indices

## Step 3: Start Server (10 seconds)

```bash
npm start
```

You should see:
```
=================================
🚀 AI Gateway Enhanced Started
=================================
📡 Server running on: http://localhost:422
🌐 Admin Dashboard: http://localhost:422/admin.html
👤 User Dashboard: http://localhost:422/user.html
=================================
```

## Step 4: Login to Admin Dashboard (30 seconds)

1. Open browser: http://localhost:422/admin.html
2. Login with:
   - Email: `admin@gateway.local`
   - Password: `admin123`
3. **CHANGE PASSWORD IMMEDIATELY!**

## Step 5: Create Your First User (1 min)

1. In admin dashboard, go to "Users"
2. Click "Create User"
3. Fill in:
   - Username: `testuser`
   - Email: `test@example.com`
   - Password: `Test123!`
   - Group: `Pro`
4. Click "Create"

## Step 6: Make Your First AI Request (1 min)

### Using cURL:

```bash
# 1. Login as testuser
curl -X POST http://localhost:422/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "Test123!"
  }'

# Copy the "token" from response

# 2. Make AI request
curl -X POST http://localhost:422/api/gpt-3.5-turbo \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Say hello!",
    "temperature": 0.7
  }'
```

### Using JavaScript:

```javascript
// 1. Login
const loginResponse = await fetch('http://localhost:422/auth/login', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({
    email: 'test@example.com',
    password: 'Test123!'
  })
});
const { token } = await loginResponse.json();

// 2. Make AI request
const aiResponse = await fetch('http://localhost:422/api/gpt-3.5-turbo', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    prompt: 'Say hello!',
    temperature: 0.7
  })
});
const data = await aiResponse.json();
console.log(data.response);
```

## ✅ You're Done!

You now have a fully functional AI Gateway with:
- ✅ User authentication
- ✅ Rate limiting
- ✅ Response caching
- ✅ Usage analytics
- ✅ Audit logging
- ✅ Webhook support

## 🎯 Next Steps

### Explore Features:

1. **Check Usage Stats**
   - Login to user dashboard: http://localhost:422/user.html
   - View your usage statistics

2. **Setup Webhooks**
   - Go to "Webhooks" section
   - Add webhook URL
   - Test webhook delivery

3. **Generate API Key**
   - Go to "API Keys" section
   - Click "Generate New Key"
   - Save the key securely

4. **Add CORS Domain**
   - Go to "Domains" section
   - Add your website domain
   - Enable browser access

5. **View Analytics**
   - Admin dashboard → "Analytics"
   - See system-wide usage
   - Check top users and models

### Try Advanced Features:

1. **Caching**
   ```bash
   # Same request twice with low temperature
   curl -X POST http://localhost:422/api/gpt-4 \
     -H "Authorization: Bearer $TOKEN" \
     -d '{"prompt": "2+2=?", "temperature": 0.1}'
   
   # Second request returns from cache (instant!)
   ```

2. **Streaming**
   ```javascript
   const response = await fetch('http://localhost:422/api/gpt-4', {
     method: 'POST',
     headers: {
       'Authorization': `Bearer ${token}`,
       'Content-Type': 'application/json'
     },
     body: JSON.stringify({
       prompt: 'Tell me a story',
       stream: true
     })
   });
   
   // Read stream token by token
   ```

3. **Export Data**
   ```bash
   # Export as CSV
   curl "http://localhost:422/user/export/usage?format=csv" \
     -H "Authorization: Bearer $TOKEN" \
     -o usage.csv
   ```

4. **Check Rate Limits**
   ```bash
   curl http://localhost:422/user/profile \
     -H "Authorization: Bearer $TOKEN"
   # Shows remaining requests
   ```

## 📚 Learn More

- **Full Installation Guide**: [INSTALLATION.md](INSTALLATION.md)
- **Complete Features**: [FEATURES.md](FEATURES.md)
- **API Reference**: [README.md](README.md)

## 🆘 Troubleshooting

### Port Already in Use?
```bash
PORT=8080 npm start
```

### Can't Connect?
```bash
# Check if server is running
curl http://localhost:422/api/health

# Should return: {"status":"ok","timestamp":"..."}
```

### Login Not Working?
1. Check email/password spelling
2. Make sure you initialized database
3. Check server logs for errors

### AI Requests Failing?
1. Check if OLLAMA_BASE_URL is correct in `.env`
2. Test the Ollama endpoint directly
3. Check rate limits in response headers

## 💡 Pro Tips

1. **Development**: Use `npm run dev` for auto-reload
2. **Production**: Use `npm run pm2:start` for process management
3. **Monitoring**: Use `pm2 monit` to watch server status
4. **Logs**: Check `pm2 logs ai-gateway-enhanced`
5. **Backup**: Regularly backup `./data/gateway.db`

## 🎉 Success!

You're now ready to build amazing AI-powered applications!

---

**Need help?** Check the full documentation or review error logs.
**Found a bug?** Create an issue with details.
**Love it?** Star ⭐ the repository!
