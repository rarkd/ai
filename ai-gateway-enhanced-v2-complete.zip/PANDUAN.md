# Panduan Cepat AI Gateway Enhanced

## 🚀 Instalasi Cepat

```bash
# 1. Install dependencies dan setup
./install.sh

# atau manual:
npm install
npm run init-db

# 2. Jalankan server
npm start

# atau dengan PM2 (production)
npm run pm2:start
```

## 🎯 Fitur-Fitur Utama

### 1️⃣ Sistem Autentikasi & User Management
- Login dengan email & password
- JWT token untuk web apps
- API Key untuk server/script
- Role admin dan user

### 2️⃣ Admin Dashboard
Akses: `http://localhost:422/admin.html`

**Kredensial default:**
- Email: `admin@gateway.local`
- Password: `admin123`

**Fitur admin:**
- ✅ Kelola user (create, edit, delete, ban)
- ✅ Kelola grup (Basic, Pro, Enterprise, dll)
- ✅ Atur model per grup
- ✅ Atur domain CORS per user
- ✅ Reset password user
- ✅ Lihat statistik penggunaan

### 3️⃣ User Dashboard
Akses: `http://localhost:422/user.html`

**Fitur user:**
- ✅ Lihat model yang tersedia
- ✅ Kelola domain CORS
- ✅ Generate API key
- ✅ Lihat dokumentasi API
- ✅ Statistik penggunaan

### 4️⃣ CORS Management
- Setiap user bisa menambahkan domain yang diperbolehkan
- Request hanya berhasil jika dari domain yang terdaftar
- Keamanan cross-origin terjamin

### 5️⃣ Group System
- Admin bisa buat grup (misal: Basic, Pro, Enterprise)
- Setiap grup punya daftar model yang berbeda
- User ditambahkan ke grup tertentu
- User hanya bisa pakai model sesuai grupnya

## 📖 Cara Pakai

### Untuk Admin

#### 1. Login ke Admin Dashboard
```
URL: http://localhost:422/admin.html
Email: admin@gateway.local
Password: admin123
```

#### 2. Buat User Baru
1. Klik tab "Kelola User"
2. Klik "+ Tambah User"
3. Isi form:
   - Username
   - Email
   - Password
   - Role (user/admin)
   - Grup (pilih grup yang sesuai)
4. Klik "Simpan"

#### 3. Buat Grup Baru
1. Klik tab "Kelola Grup"
2. Klik "+ Tambah Grup"
3. Isi nama dan deskripsi grup
4. Klik "Simpan"
5. Klik "Models" untuk menambahkan model ke grup

#### 4. Tambahkan Domain untuk User
1. Klik tab "Kelola User"
2. Klik "Domains" pada user yang diinginkan
3. Tambahkan domain (format: example.com)

### Untuk User

#### 1. Login ke User Dashboard
```
URL: http://localhost:422/user.html
Email: [email yang dibuat admin]
Password: [password yang dibuat admin]
```

#### 2. Lihat Model yang Tersedia
Model ditampilkan otomatis sesuai grup Anda

#### 3. Tambah Domain CORS
1. Scroll ke bagian "Domain yang Diperbolehkan"
2. Klik "+ Tambah Domain"
3. Masukkan domain (contoh: mywebsite.com)
4. Domain ini akan dipakai untuk CORS check

#### 4. Generate API Key
1. Scroll ke bagian "API Keys"
2. Klik "+ Buat API Key"
3. Opsional: beri nama (misal: "Production Server")
4. Klik "Generate API Key"
5. **PENTING:** Copy API key dan simpan. Tidak bisa dilihat lagi!

## 🔗 Cara Menggunakan API

### Opsi 1: Menggunakan JWT Token (untuk Web App)

```javascript
// Login dulu untuk dapat token
const loginResponse = await fetch('http://localhost:422/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: 'user@example.com',
    password: 'password123'
  })
});

const { token } = await loginResponse.json();

// Gunakan token untuk request AI
const response = await fetch('http://localhost:422/api/gpt-3.5-turbo', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  },
  body: JSON.stringify({
    prompt: 'Hello, how are you?',
    stream: false
  })
});

const data = await response.json();
console.log(data.response);
```

### Opsi 2: Menggunakan API Key (untuk Server/Script)

```javascript
const response = await fetch('http://localhost:422/api/gpt-3.5-turbo', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-API-Key': 'gw_your_api_key_here'
  },
  body: JSON.stringify({
    prompt: 'Hello, how are you?',
    stream: false
  })
});

const data = await response.json();
console.log(data.response);
```

### Contoh dengan Python

```python
import requests

# Menggunakan API Key
headers = {
    'Content-Type': 'application/json',
    'X-API-Key': 'gw_your_api_key_here'
}

data = {
    'prompt': 'Hello, how are you?',
    'stream': False
}

response = requests.post(
    'http://localhost:422/api/gpt-3.5-turbo',
    headers=headers,
    json=data
)

result = response.json()
print(result['response'])
```

### Contoh dengan cURL

```bash
# Menggunakan JWT Token
curl -X POST http://localhost:422/api/gpt-3.5-turbo \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{"prompt": "Hello", "stream": false}'

# Menggunakan API Key
curl -X POST http://localhost:422/api/gpt-3.5-turbo \
  -H "Content-Type: application/json" \
  -H "X-API-Key: gw_your_api_key_here" \
  -d '{"prompt": "Hello", "stream": false}'
```

## 🎨 Contoh Workflow Lengkap

### Scenario: Setup untuk Tim Development

#### 1. Admin Setup (5 menit)
```
1. Login ke admin dashboard
2. Buat 3 grup:
   - "Frontend Team" dengan model: gpt-3.5-turbo
   - "Backend Team" dengan model: gpt-3.5-turbo, gpt-4
   - "Full Stack Team" dengan semua model

3. Buat user untuk setiap developer:
   - john@company.com → Frontend Team
   - jane@company.com → Backend Team
   - bob@company.com → Full Stack Team

4. Kirim credentials ke masing-masing developer
```

#### 2. Developer Setup (2 menit per orang)
```
1. Login ke user dashboard dengan credentials yang diterima
2. Tambahkan domain development (localhost, dev.company.com)
3. Generate API key untuk project
4. Copy API key dan simpan di .env project
```

#### 3. Mulai Development
```javascript
// .env file
VITE_API_URL=http://localhost:422
VITE_API_KEY=gw_abc123...

// Di code
const AI_API_URL = import.meta.env.VITE_API_URL;
const AI_API_KEY = import.meta.env.VITE_API_KEY;

async function askAI(prompt) {
  const response = await fetch(`${AI_API_URL}/api/gpt-3.5-turbo`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': AI_API_KEY
    },
    body: JSON.stringify({ prompt, stream: false })
  });
  
  return await response.json();
}
```

## 🔒 Tips Keamanan

1. **Ganti Password Admin**
   - Segera ganti password default admin!
   - Gunakan password yang kuat

2. **JWT Secret**
   - Jangan pakai default JWT_SECRET
   - Generate random string di .env

3. **API Keys**
   - Simpan API key dengan aman
   - Jangan commit ke git
   - Gunakan environment variables

4. **Domain CORS**
   - Hanya tambahkan domain yang diperlukan
   - Jangan gunakan wildcard

5. **Database Backup**
   ```bash
   # Backup database secara berkala
   cp ./data/gateway.db ./data/gateway.db.backup-$(date +%Y%m%d)
   ```

## 🐛 Troubleshooting

### Error: "CORS not allowed"
**Solusi:** Pastikan domain sudah ditambahkan di User Dashboard

### Error: "Model not allowed"
**Solusi:** Pastikan model sudah di-assign ke grup user Anda

### Error: "User account is banned"
**Solusi:** Hubungi admin untuk unban account

### Error: "Invalid token"
**Solusi:** Token expired, login ulang untuk dapat token baru

### Database locked
```bash
# Stop semua instance
pkill -f "node.*server.js"

# Restart
npm start
```

## 📞 Support

Jika ada pertanyaan atau masalah:
1. Cek file README.md untuk dokumentasi lengkap
2. Cek logs: `npm run pm2:logs`
3. Hubungi administrator sistem

## 📝 Changelog

### Version 2.0.0
- ✅ Sistem autentikasi lengkap (JWT + API Key)
- ✅ Admin dashboard untuk management
- ✅ User dashboard untuk self-service
- ✅ CORS management per user
- ✅ Group system untuk kontrol akses
- ✅ Usage logging dan statistik
- ✅ Ban/unban system

---

**Selamat menggunakan AI Gateway Enhanced! 🚀**
