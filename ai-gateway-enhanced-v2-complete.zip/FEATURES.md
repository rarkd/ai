# AI Gateway Enhanced - Complete Feature Documentation

## 🎉 New Features Added

### 1. **Rate Limiting System** ✅
- **Per-user rate limiting** based on group membership
- Separate hourly and daily limits
- Automatic tracking and reset
- Rate limit headers in API responses
- Configurable limits per group

**Usage:**
```bash
# Automatically applied to all API requests
# Headers returned:
X-RateLimit-Limit-Hour: 100
X-RateLimit-Remaining-Hour: 95
X-RateLimit-Limit-Day: 1000
X-RateLimit-Remaining-Day: 950
```

### 2. **Response Caching** ✅
- Intelligent caching for deterministic requests (low temperature)
- Automatic cache key generation
- Configurable TTL (Time To Live)
- Cache hit tracking
- Token savings tracking
- Per-model cache statistics

**Features:**
- Caches responses when `temperature ≤ 0.3`
- 60-minute default TTL
- Automatic cache cleanup
- Cache statistics endpoint

### 3. **Advanced Analytics & Usage Tracking** ✅
- **Detailed usage logs** with:
  - Token consumption (request + response)
  - Response times
  - Success/error rates
  - IP addresses and user agents
  - Model usage breakdown

- **Statistics endpoints**:
  - User-specific stats
  - System-wide statistics
  - Usage trends (daily breakdown)
  - Top users ranking
  - Model popularity metrics

**API Endpoints:**
```bash
GET /user/usage?days=30           # User usage stats
GET /api/usage/stats              # Same data via gateway
GET /admin/analytics/system       # System-wide stats
GET /admin/analytics/users/:id    # Specific user stats
```

### 4. **Audit Logging** ✅
- Comprehensive activity tracking
- Logs all critical actions:
  - User management (create, update, delete, ban)
  - API key creation/deletion
  - Domain management
  - Webhook operations
  - Data exports
  - Login/logout events

**Logged Information:**
- User ID
- Action performed
- Entity type and ID
- Detailed changes (JSON)
- IP address
- User agent
- Timestamp

**API Endpoints:**
```bash
GET /user/audit-logs?limit=50&offset=0      # User's own logs
GET /admin/audit-logs?user_id=123           # Admin view all logs
```

### 5. **Webhook System** ✅
- Real-time event notifications
- Customizable event subscriptions
- HMAC signature verification
- Multiple webhooks per user
- Webhook testing endpoint

**Supported Events:**
- `request.completed` - AI request finished successfully
- `request.failed` - AI request failed
- `*` - All events (wildcard)

**Webhook Payload:**
```json
{
  "event": "request.completed",
  "timestamp": "2026-03-01T14:30:00Z",
  "data": {
    "model": "gpt-4",
    "tokens": 150,
    "response_time_ms": 1234
  }
}
```

**API Endpoints:**
```bash
GET    /user/webhooks              # List webhooks
POST   /user/webhooks              # Create webhook
PUT    /user/webhooks/:id          # Update webhook
DELETE /user/webhooks/:id          # Delete webhook
POST   /user/webhooks/:id/test     # Test webhook
```

### 6. **Data Export** ✅
- Export usage data in multiple formats
- CSV for spreadsheet analysis
- JSON for programmatic access
- Filtered by date range
- Include/exclude audit logs

**API Endpoints:**
```bash
GET /user/export/usage?format=csv&start_date=2026-01-01
GET /user/export/usage?format=json
GET /admin/export/all?format=csv    # Admin: all users
```

### 7. **Enhanced API Keys** ✅
- Secure key generation (`gw_` prefix + 64 chars)
- SHA-256 hashing
- Key expiration support
- Last used tracking
- Active/inactive status
- Named keys for organization

**Features:**
- Keys are shown only once at creation
- Automatic cleanup of expired keys
- Support for both JWT and API key authentication

### 8. **Enhanced Group System** ✅
Four default tiers with different limits:

| Group | Models | Req/Hour | Req/Day | Max Tokens |
|-------|--------|----------|---------|------------|
| Free | 1 | 10 | 100 | 2,000 |
| Basic | 2 | 50 | 500 | 4,000 |
| Pro | 4 | 200 | 2,000 | 8,000 |
| Enterprise | 6+ | 1,000 | 10,000 | 16,000 |

### 9. **Performance Optimizations** ✅
- Database indices for faster queries:
  - Usage logs by user_id and created_at
  - Audit logs by user_id and created_at
  - Rate limits by user and window
  - Cache by key and expiration

- Automatic cleanup jobs:
  - Old rate limit records (2+ days)
  - Expired cache entries
  - Old usage logs (90+ days, configurable)
  - Old audit logs (90+ days, configurable)

### 10. **Streaming Support** ✅
- Server-Sent Events (SSE) for real-time streaming
- Token-by-token delivery
- Proper connection handling
- Usage tracking for streamed responses

**Usage:**
```javascript
// Request with streaming
const response = await fetch('/api/gpt-4', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_JWT_TOKEN',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    prompt: 'Tell me a story',
    stream: true
  })
});

const reader = response.body.getReader();
// Read stream...
```

## 📊 Enhanced Dashboard Features

### Admin Dashboard
- Real-time system statistics
- User activity monitoring
- Model usage analytics
- Cache performance metrics
- Audit log viewer
- Export capabilities
- Rate limit overview

### User Dashboard
- Personal usage statistics
- Available models display
- Domain management UI
- API key management
- Webhook configuration
- Usage trends graphs
- Export data buttons

## 🔒 Security Enhancements

1. **API Key Security**
   - SHA-256 hashing (never store plain keys)
   - Secure generation (crypto.randomBytes)
   - Key prefix for identification
   - Expiration support

2. **Webhook Security**
   - HMAC signature verification
   - Secret key support
   - HTTPS enforcement (recommended)
   - Timeout protection (10s)

3. **Rate Limiting**
   - Per-user limits
   - Multiple time windows (hour, day)
   - Graceful limit exceeded responses
   - Header-based limit communication

4. **Audit Trail**
   - All administrative actions logged
   - IP address tracking
   - User agent logging
   - Detailed change records

## 🛠️ Database Schema Updates

### New Tables
1. **rate_limits** - Track rate limiting windows
2. **audit_logs** - Comprehensive activity logging
3. **webhooks** - Webhook configurations
4. **password_reset_tokens** - Password reset flow
5. **response_cache** - AI response caching

### Enhanced Tables
1. **users** - Added `last_login` field
2. **groups** - Added rate limit fields
3. **api_keys** - Added `expires_at`, `is_active`
4. **usage_logs** - Added detailed tracking fields

## 📡 API Endpoints Summary

### Authentication
- `POST /auth/login` - User login
- `POST /auth/register` - Register (admin only)
- `POST /auth/change-password` - Change password
- `GET /auth/me` - Get current user

### User Endpoints
- `GET /user/profile` - Get profile with rate limits
- `GET /user/models` - Available models
- `GET /user/domains` - CORS domains
- `POST /user/domains` - Add domain
- `DELETE /user/domains/:id` - Remove domain
- `GET /user/api-keys` - List API keys
- `POST /user/api-keys` - Create API key
- `DELETE /user/api-keys/:id` - Delete API key
- `GET /user/usage` - Usage statistics
- `GET /user/webhooks` - List webhooks
- `POST /user/webhooks` - Create webhook
- `PUT /user/webhooks/:id` - Update webhook
- `DELETE /user/webhooks/:id` - Delete webhook
- `POST /user/webhooks/:id/test` - Test webhook
- `GET /user/export/usage` - Export data
- `GET /user/audit-logs` - View audit logs

### Gateway Endpoints
- `POST /api/:model` - AI request (with caching & rate limiting)
- `GET /api/models/available` - Available models
- `GET /api/usage/stats` - Usage statistics
- `GET /api/health` - Health check

### Admin Endpoints
- `GET /admin/users` - List users
- `POST /admin/users` - Create user
- `PUT /admin/users/:id` - Update user
- `DELETE /admin/users/:id` - Delete user
- `PATCH /admin/users/:id/ban` - Ban/unban user
- `GET /admin/groups` - List groups
- `POST /admin/groups` - Create group
- `PUT /admin/groups/:id` - Update group
- `GET /admin/stats` - Dashboard statistics
- `GET /admin/analytics/system` - System analytics
- `GET /admin/analytics/users/:id` - User analytics
- `GET /admin/audit-logs` - View all audit logs
- `GET /admin/cache/stats` - Cache statistics
- `POST /admin/cache/clear` - Clear cache
- `GET /admin/export/all` - Export all data

## 🚀 Usage Examples

### 1. Make an AI Request with Caching
```bash
curl -X POST http://localhost:422/api/gpt-4 \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "What is the capital of France?",
    "temperature": 0.2
  }'
```

Response includes cache status:
```json
{
  "response": "The capital of France is Paris.",
  "model": "gpt-4",
  "tokens": 12,
  "response_time_ms": 856,
  "from_cache": false
}
```

### 2. Create a Webhook
```bash
curl -X POST http://localhost:422/user/webhooks \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://your-domain.com/webhook",
    "events": ["request.completed", "request.failed"],
    "secret": "your-webhook-secret"
  }'
```

### 3. Get Usage Statistics
```bash
curl http://localhost:422/user/usage?days=30 \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

Response:
```json
{
  "statistics": {
    "total_requests": 150,
    "total_tokens": 45000,
    "avg_response_time": 1234,
    "successful_requests": 148,
    "failed_requests": 2,
    "models": [
      {
        "model_alias": "gpt-4",
        "count": 100,
        "tokens": 30000
      }
    ]
  },
  "trends": [
    {
      "date": "2026-02-01",
      "requests": 5,
      "tokens": 1500,
      "avg_response_time": 1200
    }
  ]
}
```

### 4. Export Data as CSV
```bash
curl "http://localhost:422/user/export/usage?format=csv" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -o usage_export.csv
```

## 🔧 Configuration

### Environment Variables (.env)
```env
# Server
PORT=422

# Security
JWT_SECRET=your-secure-secret-key

# API
OLLAMA_BASE_URL=https://aiapi.awwlk.my.id

# Database
DATABASE_PATH=./data/gateway.db

# Cache (optional)
CACHE_TTL_MINUTES=60

# Cleanup (optional)
CLEANUP_USAGE_LOGS_DAYS=90
CLEANUP_AUDIT_LOGS_DAYS=90
CLEANUP_RATE_LIMITS_DAYS=2
```

## 📈 Performance Tips

1. **Enable Caching**
   - Use `temperature ≤ 0.3` for cacheable requests
   - Great for FAQs, documentation queries, and repetitive tasks

2. **Monitor Rate Limits**
   - Check `X-RateLimit-*` headers
   - Implement backoff strategies

3. **Use Webhooks**
   - Avoid polling for updates
   - Get real-time notifications

4. **Regular Cleanup**
   - Old logs automatically cleaned after 90 days
   - Can be configured via environment variables

5. **Database Optimization**
   - Indices automatically created
   - Regular VACUUM recommended for SQLite

## 🐛 Troubleshooting

### High Memory Usage
- Reduce cache TTL
- Decrease log retention period
- Enable automatic cleanup

### Slow Queries
- Ensure indices are created
- Check database size
- Run `VACUUM` on SQLite database

### Webhook Failures
- Check URL accessibility
- Verify SSL certificates
- Test with `/test` endpoint
- Check webhook logs in audit_logs

### Rate Limit Issues
- Check group configuration
- Monitor rate limit tables
- Adjust limits if needed

## 📝 Migration Notes

If upgrading from basic version:
1. Backup your database
2. Run `npm run init-db-enhanced` (new script)
3. Existing data will be preserved
4. New tables will be created
5. Existing tables will be enhanced

## 🔮 Future Enhancements

Planned features:
- [ ] 2FA authentication
- [ ] Email notifications
- [ ] Advanced model routing
- [ ] Cost tracking and budgets
- [ ] Team collaboration features
- [ ] API versioning
- [ ] GraphQL endpoint
- [ ] Prometheus metrics export
- [ ] Slack/Discord integrations

## 📚 Additional Resources

- [Rate Limiting Best Practices](docs/rate-limiting.md)
- [Webhook Security Guide](docs/webhooks.md)
- [Analytics API Reference](docs/analytics-api.md)
- [Caching Strategy Guide](docs/caching.md)

## 🤝 Support

For issues or questions:
1. Check the documentation
2. Review audit logs
3. Test with health endpoint
4. Check database integrity

---

**Version:** 2.0.0 (Enhanced)  
**Last Updated:** March 2026  
**Author:** AI Gateway Team
